# Lab Assignment 7 - Multiobjective Optimization (37 algorithms)
Manavaditya Rajesh, reg. no. 241070040 (R = 40; deep dives: Benson 3, NSGA-III 15, MODE 27)

Python 3, NumPy + Matplotlib only (scipy only inside algorithms 1-7; scikit-learn only to load the Wisconsin data; reportlab only to typeset the PDF).

## Layout
- moo/  moo_utils.py (toolkit), problems.py (P1-P14), ops.py, base.py, a01..a36 algorithm modules grouped by family
- tests/test_all.py  40 unit tests (toolkit + one key-rule test per algorithm)
- experiments/  run_task_a.py, run_task_c.py, run_task_d.py, run_extras.py, make_figures.py, build_report.py
- Lab7_Manavaditya_Rajesh_241070040.ipynb  condensed re-run (executed)

## Run
pip install numpy matplotlib scipy scikit-learn reportlab
python tests/test_all.py
cd experiments; python run_task_a.py; python run_task_c.py; python run_task_d.py; python run_extras.py; python make_figures.py; python build_report.py
(Task D is resumable; results go to ../outputs/data, figures to ../outputs/figures.)
Seeds: Task A seed 1; Tasks C/D seeds 1-10; P8 uses numpy.random.seed(7).
