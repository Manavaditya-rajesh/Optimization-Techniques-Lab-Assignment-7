"""Unit tests: shared toolkit + one key-rule test per algorithm (1-37).  Run: python tests/test_all.py"""
import sys, os, json, itertools
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from moo import moo_utils as U, problems as P
from moo.a01_classical import *
from moo.a08_mcdm import *
from moo.a10_noneelitist import *
from moo.a14_elitist import *
from moo.a18_decomposition import *
from moo.a22_swarm import *
from moo.a26_misc import *
from moo.a31_indicator import *
from moo.a36_gradient import *

T = {}
def test(name):
    def d(f): T[name] = f; return f
    return d

# ------------------------------------------------------------------ toolkit
@test("utils: car Pareto-front example")
def _():
    cars = np.array([[10, 8], [15, 6], [20, 5], [18, 7], [25, 5.5]], float)   # (price k$, L/100km)
    fr = U.fast_nondominated_sort(cars)
    assert sorted(fr[0].tolist()) == [0, 1, 2] and sorted(fr[1].tolist()) == [3, 4]
    assert U.dominates(cars[1], cars[3]) and not U.dominates(cars[0], cars[1])
@test("utils: Deb constrained-dominance table")
def _():
    f = np.array([[1, 5], [2, 2], [0, 0], [0, 0]], float); cv = np.array([0, 0, 3, 1.0])
    cd = U.constrained_dominates
    assert cd(f[0], cv[0], f[2], cv[2])            # rule 1: feasible beats infeasible
    assert cd(f[3], cv[3], f[2], cv[2])            # rule 2: smaller violation wins
    assert not cd(f[0], 0, f[1], 0) and not cd(f[1], 0, f[0], 0)     # rule 3: Pareto, incomparable
    assert U.fast_nondominated_sort(f, cv)[0].tolist() == [0, 1] or sorted(U.fast_nondominated_sort(f, cv)[0].tolist()) == [0, 1]
@test("utils: crowding distance, HV, IGD, spacing")
def _():
    F = np.array([[0, 4], [1, 2], [2, 1], [4, 0]], float)
    cd = U.crowding_distance(F); assert np.isinf(cd[0]) and np.isinf(cd[3]) and abs(cd[1] - 1.25) < 1e-12
    assert abs(U.hypervolume_2d(np.array([[1, 3], [2, 2], [3, 1.]]), np.array([4, 4.])) - 6.0) < 1e-12
    assert abs(U.igd(np.array([[0, 0.], [1, 1.]]), np.array([[0, 0.]])) - np.sqrt(2) / 2) < 1e-12
    assert U.spacing(np.array([[0, 0], [1, 0], [2, 0], [3, 0.]])) < 1e-12
    assert abs(U.hv_mc(np.array([[0.5, 0.5, 0.5]]), np.ones(3), n=200000) - 0.125) < 0.005

# ------------------------------------------------------------------ classical 1-7
@test("01 Weighted Sum: convex w=(.5,.5)->x=5; never the middle of the non-convex ZDT2 front")
def _():
    r = weighted_sum(P.P1(), n_w=3); assert abs(r[1][1][0] - 5) < 0.05
    r = weighted_sum(P.P3(), n_w=11); assert all(f[0] < 0.05 or f[0] > 0.95 for _, _, f in r)
@test("02 eps-Constraint: f2<=eps holds and the point is non-dominated")
def _():
    p = P.P1(); r = eps_constraint(p, n_eps=5)
    S = p.norm(p.evaluate(np.random.default_rng(0).uniform(1, 10, (3000, 1)))[0])
    for e, x, f in r:
        assert f[1] <= e + 1e-6 and not any(U.dominates(s, f - 1e-6) for s in S)
@test("03 Benson: f + l = z, l >= 0, solution non-dominated")
def _():
    p = P.P1(); r = benson(p, [np.array([0.65, 0.65])])
    z, x, f, l = r[0]; assert np.allclose(f + l, z, atol=1e-5) and (l >= -1e-9).all() and abs(x[0] - 5) < 0.05
@test("04 Weight metric: p=inf reaches the ZDT2 middle, p=1 does not")
def _():
    mid = lambda r: any(0.2 < f[0] < 0.8 for _, _, f in r)
    assert mid(weight_metric(P.P3(), n_w=7, pnorm=np.inf)) and not mid(weight_metric(P.P3(), n_w=7, pnorm=1))
@test("05 Value function: result maximises the DM utility among random portfolios")
def _():
    p = P.P4(); a = np.array([1.0, 1.0]); r = value_function(p, [a])[0]
    V = lambda f: np.prod(np.maximum(1.05 - f, 1e-9) ** a, axis=-1)
    S = p.norm(p.evaluate(np.random.default_rng(0).random((4000, 4)))[0])
    assert V(r[2]) >= V(S).max() - 1e-6
@test("06 Goal programming: P11 units goal leaves shortfall 100, profit goal met")
def _():
    x, dm, dp, obj = goal_programming(np.array([2400., 600.]), np.zeros(2), np.ones(2))
    assert abs(dm[1] - 100) < 1e-6 and dm[0] < 1e-6 and np.allclose(x, [300, 200], atol=1e-6)
@test("07 Lexicographic: profit first (2400, tie) then units -> (300,200)")
def _():
    x, log = lexicographic(); assert abs(log[0][1] - 2400) < 1e-6 and np.allclose(x, [300, 200], atol=1e-6)
@test("08 TOPSIS: dominant alternative has closeness 1, anti-ideal has 0")
def _():
    C2, _, _ = topsis(np.array([[1, 9], [5, 5], [9, 1.]]), np.array([.5, .5]), np.array([False, True])); assert 0 <= C2.min() and C2.max() <= 1
    C3, _, _ = topsis(np.array([[1, 9], [5, 5.]]), np.array([.5, .5]), np.array([False, True])); assert abs(C3[0] - 1) < 1e-12
@test("09 VIKOR: dominant alternative has S=R=Q=0")
def _():
    Q3, S3, R3, _ = vikor(np.array([[1, 9], [5, 5.]]), np.array([.5, .5]), np.array([False, True]), 0.5)
    assert S3[0] == 0 and R3[0] == 0 and Q3[0] == 0 and Q3[1] == 1

# ------------------------------------------------------------------ non-elitist 10-13
@test("10 VEGA: sub-population m is selected on objective m only")
def _():
    a = VEGA(P.P3(), seed=0); r = np.random.default_rng(1); F = r.random((100, 2)); F[:, 1] = 1 - F[:, 0]
    p0, p1 = a.parts(F); assert F[p0, 0].mean() < 0.4 and F[p1, 1].mean() < 0.4 and len(p0) == len(p1) == 50
@test("11 MOGA: rank = 1 + number of dominators")
def _():
    F = np.array([[1, 5], [2, 4], [3, 3], [4, 4], [5, 5.]]); assert MOGA.ranks(F).tolist() == [1, 1, 1, 3, 5]
@test("12 NSGA: every member of front k has higher dummy fitness than every member of front k+1")
def _():
    a = NSGA(P.P3(), seed=0); F = np.random.default_rng(0).random((60, 2)); fit = a.fitness(F)
    fr = U.fast_nondominated_sort(F)
    for k in range(len(fr) - 1):
        assert fit[fr[k]].min() > fit[fr[k + 1]].max()
@test("13 NPGA: candidate dominated by the comparison set loses")
def _():
    a = NPGA(P.P3(), seed=0); F = np.array([[0.5, 0.5], [0.1, 0.1], [0.05, 0.9], [0.9, 0.2]])
    assert a.pareto_tournament(F, 0, 2, np.array([1])) == 2

# ------------------------------------------------------------------ elitist 14-17, 21
@test("14 NSGA-II: elitism - hypervolume of the non-dominated set never decreases; boundary crowding = inf")
def _():
    a = NSGA2(P.P3(), seed=3); a.initialize(); hv = []
    for _ in range(12):
        a.iterate(); hv.append(U.hypervolume_2d(a.F[U.nondominated_mask(a.F)], np.array([1.1, 1.1])))
    assert all(hv[i + 1] >= hv[i] - 1e-12 for i in range(len(hv) - 1))
    assert np.isinf(U.crowding_distance(np.array([[0, 1], [.5, .5], [1, 0.]]))[[0, 2]]).all()
@test("15 NSGA-III: association = nearest reference line; intercept normalisation maps extremes to 1")
def _():
    Z = U.das_dennis(3, 4); Fn = np.random.default_rng(0).random((30, 3))
    j, d = associate(Fn, Z)
    Zn = Z / np.linalg.norm(Z, axis=1, keepdims=True)
    for i in range(30):
        dist = [np.linalg.norm(Fn[i] - (Fn[i] @ z) * z) for z in Zn]; assert j[i] == int(np.argmin(dist)) and abs(d[i] - min(dist)) < 1e-9
    F = np.array([[2, 0, 0], [0, 2, 0], [0, 0, 2], [1, 1, 0.5]], float); N_ = nsga3_normalize(F)
    assert np.allclose(N_[:3].max(1), 1.0, atol=1e-6)
@test("16 SPEA2: raw fitness 0 <=> non-dominated; archive size stays fixed")
def _():
    F = np.array([[1, 3], [2, 2], [3, 1], [3, 3], [4, 4.]]); fit, R = spea2_fitness(F)
    assert (R[:3] == 0).all() and (R[3:] > 0).all() and (fit[:3] < 1).all() and (fit[3:] >= 1).all()
    a = SPEA2(P.P3(), pop=40, seed=0); a.initialize(); a.iterate(); a.iterate(); assert len(a.AX) == 40
@test("17 PESA-II: archive non-dominated; region tournament favours the less crowded box")
def _():
    a = PESA2(P.P3(), seed=0); a.initialize()
    for _ in range(20): a.iterate()
    assert U.nondominated_mask(a.arc.F).all()
    F = np.vstack([np.random.default_rng(0).random((30, 2)) * 0.1, [[0.9, 0.9]]]); arc = Archive(100, "grid", 10)
    inv, cnt = arc.cells(F); assert cnt[inv[-1]] == 1 and cnt[inv[0]] > 1
@test("18 MOEA/D: neighbourhoods are the T nearest weight vectors; Tchebycheff g")
def _():
    a = MOEAD(P.P3(), pop=50, T=5, seed=0)
    for i in range(50):
        d = np.linalg.norm(a.W - a.W[i], axis=1); assert set(a.B[i]) == set(np.argsort(d)[:5]) and i in a.B[i]
    assert abs(tcheb(np.array([0.5, 0.2]), np.array([0.5, 0.5]), np.array([0.1, 0.1])) - 0.2) < 1e-12
@test("19 MOEA/D-DE: trial = x_r1 + F (x_r2 - x_r3) when CR=1 and mutation off")
def _():
    a = MOEADDE(P.P3(), pop=20, seed=0, Fscale=0.5, CR=1.0); a.initialize(); a.ops.mutate = lambda X, rng, scale=None: X
    pool = np.array([0, 1, 2]); u = a.make_child(5, pool)[0]
    ok = any(np.allclose(np.clip(a.X[p[0]] + 0.5 * (a.X[p[1]] - a.X[p[2]]), 0, 1), u) for p in itertools.permutations([0, 1, 2]))
    assert ok
@test("20 MOEA/D-ACO: constructed tours are permutations; deposit raises pheromone on used edges")
def _():
    a = MOEADACO(P.P8(), pop=10, seed=0); t = a.construct(3); assert sorted(t.tolist()) == list(range(15))
    before = a.tau[3][t[0], t[1]]; a.deposit(3, t, 1.0); assert a.tau[3][t[0], t[1]] > before * (1 - a.rho)
@test("21 Constrained NSGA-II: Deb's rules rank feasible above infeasible")
def _():
    p = P.P5(); a = ConstrainedNSGA2(p, pop=60, seed=0); a.run(6000)
    assert a.cmode == "deb" and (a.CV <= 0).mean() > 0.9
    assert U.constrained_dominates(np.array([9., 9]), 0, np.array([0., 0]), 0.5)

# ------------------------------------------------------------------ swarm / others 22-30
@test("22 MOPSO: velocity rule v' = w v + c1 r1 (pbest-x) + c2 r2 (leader-x); archive non-dominated")
def _():
    a = MOPSO(P.P3(), seed=0); V = np.ones((3, 2)); z = np.zeros((3, 2))
    assert np.allclose(a.velocity(V, z, z + 1, z + 2, 0 * V, 0 * V), 0.4 * V)
    assert np.allclose(a.velocity(0 * V, z, z + 1, z + 2, V, V), 1.5 * 1 + 1.5 * 2)
    a.run(3000); assert U.nondominated_mask(a.arc.F).all()
@test("23 MOGWO: alpha/beta/delta are archive members; wolves stay inside the bounds")
def _():
    a = MOGWO(P.P3(), seed=0); a.initialize(); a.iterate(); L = a.leaders()
    assert all(any(np.allclose(l, r) for r in a.arc.X) for l in L)
    assert (a.X >= 0).all() and (a.X <= 1).all()
@test("24 MOABC: greedy selection by dominance (+1 / 0 / -1)")
def _():
    assert abc_greedy(np.array([1, 1.]), np.array([2, 2.])) == 1 and abc_greedy(np.array([2, 2.]), np.array([1, 1.])) == -1
    assert abc_greedy(np.array([1, 3.]), np.array([3, 1.])) == 0
@test("25 MOACO: transition probabilities sum to 1 and exclude visited cities")
def _():
    a = MOACO(P.P8(), pop=5, seed=0); vis = np.zeros(15, bool); vis[[0, 4]] = True
    p = a.probs(0, vis, 0.3); assert abs(p.sum() - 1) < 1e-12 and p[0] == 0 and p[4] == 0
@test("26 MOSA: dominating move accepted (p=1); worse move accepted with exp(-w.dF/T)")
def _():
    assert sa_accept_prob(np.array([-.1, -.2]), np.array([.5, .5]), 0.1) == 1.0
    assert abs(sa_accept_prob(np.array([.1, .3]), np.array([.5, .5]), 0.2) - np.exp(-0.2 / 0.2)) < 1e-12
@test("27 MODE: trial replaces target only if it dominates")
def _():
    assert mode_replace(np.array([1, 1.]), np.array([2, 2.])) and not mode_replace(np.array([1, 3.]), np.array([3, 1.])) \
        and not mode_replace(np.array([2, 2.]), np.array([1, 1.])) and not mode_replace(np.array([1, 1.]), np.array([1, 1.]))
@test("28 MO-TLBO: teaching factor shrinks monotonically from 2 to 1")
def _():
    a = MOTLBO(P.P3(), seed=0); a.max_iters = 10; v = []
    for t in range(11): a.t = t; v.append(a.tf())
    assert v[0] == 2.0 and abs(v[-1] - 1.0) < 1e-12 and all(v[i] >= v[i + 1] for i in range(10))
@test("29 MOBA: loudness decreases, pulse rate increases")
def _():
    a = MOBA(P.P3(), seed=0); a.initialize(); A0, r0 = a.A.copy(), a.r.copy(); a.t = 5; a.schedules()
    assert (a.A < A0).all() and (a.r > r0).all()
@test("30 MOMA: hill-climbing local search never worsens the scalarised objective")
def _():
    a = MOMA(P.P3(), seed=0); a.initialize(); X, F, CV = a.X.copy(), a.F.copy(), a.CV.copy()
    L = np.arange(20); w = np.tile([.5, .5], (20, 1)); X2, F2, CV2 = a.local_search(X.copy(), F.copy(), CV.copy(), w=w, L=L)
    assert ((w * F2[L]).sum(1) <= (w * F[L]).sum(1) + 1e-12).all() and (F2[L] != F[L]).any()

# ------------------------------------------------------------------ many-objective / indicator / preference 31-35
@test("31 RVEA: every solution is assigned to the reference vector with the smallest angle")
def _():
    a = RVEA(P.P10(3), seed=0, H=4); F = np.random.default_rng(0).random((40, 3)); keep, j = apd_select(F, a.V, a.gamma, 3, 1, 10)
    Fp = F - F.min(0)
    for i in range(40):
        cos = [Fp[i] @ v / np.linalg.norm(Fp[i]) for v in a.V]; assert j[i] == int(np.argmax(cos))
    assert len(set(keep.tolist())) == len(keep)
@test("32 IBEA: a dominated point has lower fitness; selection keeps exactly N")
def _():
    F = np.array([[0.1, 0.1], [0.5, 0.5], [0.0, 1.0], [1.0, 0.0]]); f = ibea_fitness(F)
    assert f[0] > f[1]
    a = IBEA(P.P3(), pop=20, seed=0); assert len(a.select(np.random.default_rng(0).random((40, 2)), 20)) == 20
@test("33 SMS-EMOA: hypervolume contributions identify the point to discard")
def _():
    F = np.array([[1, 3], [2, 2.5], [3, 1.]]); c = hv_contributions(F, np.array([4, 4.]))
    assert np.allclose(c, [1.0, 0.5, 1.5]) and int(np.argmin(c)) == 1
@test("34 HypE: Monte-Carlo k=1 fitness approximates the exact exclusive contribution")
def _():
    F = np.array([[1, 3], [2, 2.5], [3, 1.]]); ref = np.array([4, 4.]); est = hype_fitness(F, 1, ref, np.random.default_rng(0), S=200000)
    assert np.allclose(est, hv_contributions(F, ref), atol=0.05)
@test("35 R-NSGA-II: the selected set is closer to the reference point than the rest")
def _():
    r = np.random.default_rng(0); t = r.random(80); F = np.c_[t, 1 - t] + 0.0
    sel = rnsga2_select(F, 20, np.array([[0.3, 0.7]]), 0.01, r)
    d = np.linalg.norm(F - [0.3, 0.7], axis=1); assert d[sel].mean() < d.mean()
@test("36 MGDA: <d*,g_i> >= ||d*||^2 for all tasks; opposite equal gradients give d*=0")
def _():
    G = np.random.default_rng(0).normal(size=(3, 6)); d, a = mgda_direction(G)
    assert abs(a.sum() - 1) < 1e-9 and (G @ d >= d @ d - 1e-6).all()
    d0, _ = mgda_direction(np.array([[1., 2.], [-1., -2.]])); assert np.linalg.norm(d0) < 1e-9
@test("37 GradNorm: weights stay positive and sum to T; the slower-learning task gets more weight")
def _():
    h = run_toy("gradnorm", steps=30); w = h[-1][2]; assert abs(w.sum() - 2.0) < 1e-9 and (w > 0).all()
    hist, L0 = run_net("gradnorm", steps=50); assert abs(hist[-1][1].sum() - 2.0) < 1e-9

def main():
    res = []
    for k, f in T.items():
        try:
            f(); res.append((k, "PASS", ""))
        except Exception as e:
            res.append((k, "FAIL", repr(e)))
    for r in res:
        print("%-5s %s %s" % (r[1], r[0], r[2]))
    os.makedirs(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "data"), exist_ok=True)
    json.dump(res, open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "data", "unit_tests.json"), "w"), indent=1)
    print("passed %d / %d" % (sum(r[1] == "PASS" for r in res), len(res)))

if __name__ == "__main__":
    main()
