"""Algorithms 36-37: MGDA and GradNorm, plus P13 (toy problem and a hand-written two-head network).

MGDA (Desideri 2012; Sener & Koltun 2018): d* = argmin_{a in simplex} || sum a_i g_i ||^2 ; if d*=0 the point is
Pareto-stationary, else -d* is a descent direction for every task (<d*, g_i> >= ||d*||^2).  Frank-Wolfe solver
(exact 2-point line search) for M tasks.
GradNorm (Chen 2018): weights w_i (sum = T) adapted so that G_i = w_i ||grad_W L_i|| follows
Gbar * r_i^alpha, r_i = (L_i/L_i(0)) / mean_j(L_j/L_j(0)); loss_grad = sum |G_i - target_i| is differentiated w.r.t. w only.
P13(a): f1=||x-a||^2, f2=||x-b||^2, a=(3,3), b=(-3,-3), start (0,5).
P13(b): shared tanh layer (10->16) + classification head (sigmoid/BCE) + regression head (linear/MSE); hand backprop.
"""
import numpy as np

A_PT = np.array([3.0, 3.0]); B_PT = np.array([-3.0, -3.0]); X0 = np.array([0.0, 5.0])


def toy_losses(x):
    return np.array([np.sum((x - A_PT) ** 2), np.sum((x - B_PT) ** 2)])


def toy_grads(x):
    return np.array([2 * (x - A_PT), 2 * (x - B_PT)])


def min_norm_element(G, iters=250, tol=1e-12):
    """alpha on the simplex minimising ||alpha^T G||^2 (Frank-Wolfe)."""
    G = np.asarray(G, float); M = len(G); K = G @ G.T
    a = np.full(M, 1.0 / M)
    for _ in range(iters):
        grad = K @ a; t = int(np.argmin(grad))
        e = np.zeros(M); e[t] = 1.0
        d = e - a
        den = d @ K @ d
        if den <= tol:
            break
        gamma = float(np.clip(-(a @ K @ d) / den, 0.0, 1.0))
        if gamma < 1e-10:
            break
        a = a + gamma * d
    return a


def mgda_direction(G):
    a = min_norm_element(G)
    return a @ np.asarray(G), a


def run_toy(method, steps=200, lr=0.05, x0=X0, T=2.0, alpha=1.5, lr_w=0.025):
    x = x0.astype(float).copy(); w = np.ones(2); L0 = toy_losses(x)
    hist = []
    for t in range(steps):
        L = toy_losses(x); G = toy_grads(x)
        hist.append((x.copy(), L.copy(), w.copy()))
        if method == "equal":
            d = G.sum(0) * 0.5
        elif method == "mgda":
            d, _ = mgda_direction(G)
        elif method == "gradnorm":
            gn = np.linalg.norm(G, axis=1); Gi = w * gn; r = (L / L0) / np.mean(L / L0)
            tgt = Gi.mean() * r ** alpha
            w = np.maximum(w - lr_w * np.sign(Gi - tgt) * gn, 0.01); w = T * w / w.sum()
            d = (w[:, None] * G).sum(0) * 0.5
        x = x - lr * d
    hist.append((x.copy(), toy_losses(x), w.copy()))
    return hist


# --------------------------------------------------------------------------- network (13b)
def make_data(n=400, d=10, scale_reg=10.0, seed=0):
    r = np.random.default_rng(seed)
    X = r.normal(size=(n, d)); w1 = r.normal(size=d); w2 = r.normal(size=d)
    yc = (X @ w1 + 0.3 * r.normal(size=n) > 0).astype(float)
    yr = scale_reg * (np.tanh(X @ w2 * 0.7) + 0.1 * r.normal(size=n))
    return X, yc, yr


class TwoHeadNet:
    def __init__(self, d=10, h=16, seed=0):
        r = np.random.default_rng(seed)
        self.W1 = r.normal(0, 0.4, (d, h)); self.b1 = np.zeros(h)
        self.Wc = r.normal(0, 0.4, (h, 1)); self.bc = np.zeros(1)
        self.Wr = r.normal(0, 0.4, (h, 1)); self.br = np.zeros(1)

    def forward(self, X):
        H = np.tanh(X @ self.W1 + self.b1)
        zc = (H @ self.Wc + self.bc)[:, 0]; pr = 1 / (1 + np.exp(-zc)); yr = (H @ self.Wr + self.br)[:, 0]
        return H, pr, yr

    def losses(self, X, yc, yr_t):
        H, pr, yr = self.forward(X)
        eps = 1e-12
        Lc = -np.mean(yc * np.log(pr + eps) + (1 - yc) * np.log(1 - pr + eps))
        Lr = np.mean((yr - yr_t) ** 2)
        return np.array([Lc, Lr])

    def grads(self, X, yc, yr_t):
        """Per-task gradients: dict of arrays for shared (W1,b1) and the heads."""
        n = len(X); H, pr, yr = self.forward(X)
        # task 1 (classification)
        dzc = (pr - yc) / n
        gWc = H.T @ dzc[:, None]; gbc = dzc.sum(keepdims=True)
        dH1 = dzc[:, None] @ self.Wc.T
        # task 2 (regression)
        dyr = 2 * (yr - yr_t) / n
        gWr = H.T @ dyr[:, None]; gbr = dyr.sum(keepdims=True)
        dH2 = dyr[:, None] @ self.Wr.T
        out = []
        for dH in (dH1, dH2):
            dpre = dH * (1 - H ** 2)
            out.append((X.T @ dpre, dpre.sum(0)))
        return out, (gWc, gbc), (gWr, gbr)


def run_net(method, steps=600, lr=0.01, T=2.0, alpha=1.5, lr_w=0.025, seed=0, scale_reg=10.0):
    X, yc, yr = make_data(scale_reg=scale_reg); net = TwoHeadNet(seed=seed)
    L0 = net.losses(X, yc, yr); w = np.ones(2); hist = []
    for t in range(steps):
        L = net.losses(X, yc, yr); hist.append((L.copy(), w.copy()))
        sh, hc, hr = net.grads(X, yc, yr)
        gW = [s[0].ravel() for s in sh]; gb = [s[1] for s in sh]
        flat = np.array([np.r_[sh[i][0].ravel(), sh[i][1]] for i in range(2)])
        if method == "equal":
            ws = np.array([1.0, 1.0])
            dsh = ws[0] * flat[0] + ws[1] * flat[1]; wc = wr = 1.0
        elif method == "mgda":
            nf = flat / np.maximum(np.linalg.norm(flat, axis=1, keepdims=True), 1e-12)   # normalised gradients (Sener-Koltun 'l2')
            d, a = mgda_direction(nf)
            dsh = d * np.mean(np.linalg.norm(flat, axis=1)); wc = wr = 1.0
            w = a * T
        elif method == "gradnorm":
            gn = np.linalg.norm(flat, axis=1); Gi = w * gn; r = (L / L0) / np.mean(L / L0)
            tgt = Gi.mean() * r ** alpha
            w = np.maximum(w - lr_w * np.sign(Gi - tgt) * gn, 0.01); w = T * w / w.sum()
            dsh = w[0] * flat[0] + w[1] * flat[1]; wc, wr = w[0], w[1]
        nW = net.W1.size
        net.W1 -= lr * dsh[:nW].reshape(net.W1.shape); net.b1 -= lr * dsh[nW:]
        net.Wc -= lr * wc * hc[0]; net.bc -= lr * wc * hc[1]
        net.Wr -= lr * wr * hr[0]; net.br -= lr * wr * hr[1]
    hist.append((net.losses(X, yc, yr), w.copy()))
    return hist, L0
