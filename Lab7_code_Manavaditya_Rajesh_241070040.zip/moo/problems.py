"""Problem bank P1-P14 (P11-P13 are data/gradient problems used by classical/MCDM/gradient modules).

Every problem exposes   evaluate(X) -> (F, CV)
  F  : (N, M) objectives in MINIMISATION form (Max f is stored as -f)
  CV : (N,)  total normalised constraint violation (0 = feasible)
plus lb, ub, ideal, nadir (used for a common normalisation of every metric),
true_front(n) (raw objective units, minimisation form) where known.
"""
import os
import numpy as np
from . import moo_utils as U

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs", "data")


class Problem:
    kind = "real"
    name = "problem"
    n_obj = 2
    maximise = ()           # indices of objectives that are maximised in the natural statement
    pref_point = None       # decision-maker reference point (min form, raw units)

    def evaluate(self, X):
        raise NotImplementedError

    def true_front(self, n=300):
        return None

    def norm(self, F):
        return (np.asarray(F, float) - self.ideal) / (self.nadir - self.ideal)

    def denorm(self, Fn):
        return np.asarray(Fn, float) * (self.nadir - self.ideal) + self.ideal

    @property
    def ref_hv(self):
        return np.full(self.n_obj, 1.1)


def _arr(*a):
    return np.array(a, float)


# ---------------------------------------------------------------- P1
class P1(Problem):
    name = "P1 factory speed"; n_var = 1; n_obj = 2
    lb = _arr(1); ub = _arr(10); ideal = _arr(0, 0); nadir = _arr(16, 16)

    def evaluate(self, X):
        x = X[:, 0]
        return np.c_[(x - 3) ** 2, (x - 7) ** 2], np.zeros(len(X))

    def true_front(self, n=300):
        x = np.linspace(3, 7, n)
        return np.c_[(x - 3) ** 2, (x - 7) ** 2]


# ---------------------------------------------------------------- P2
class P2(Problem):
    n_var = 1; n_obj = 2
    lb = _arr(1); ub = _arr(10); ideal = _arr(10, 1); nadir = _arr(100, 100)

    def __init__(self, integer=False):
        self.integer = integer
        self.name = "P2 fleet sizing (%s)" % ("integer" if integer else "real")

    def evaluate(self, X):
        x = X[:, 0]
        if self.integer:
            x = np.clip(np.round(x), 1, 10)
        return np.c_[100.0 / x, x ** 2], np.zeros(len(X))

    def true_front(self, n=300):
        x = np.arange(1, 11, dtype=float) if self.integer else np.linspace(1, 10, n)
        return np.c_[100.0 / x, x ** 2]


# ---------------------------------------------------------------- P3 (ZDT2)
class P3(Problem):
    name = "P3 ZDT2 (n=10)"; n_var = 10; n_obj = 2
    lb = np.zeros(10); ub = np.ones(10); ideal = _arr(0, 0); nadir = _arr(1, 1)

    def evaluate(self, X):
        f1 = X[:, 0]
        g = 1 + X[:, 1:].sum(1)
        return np.c_[f1, g * (1 - (f1 / g) ** 2)], np.zeros(len(X))

    def true_front(self, n=300):
        f1 = np.linspace(0, 1, n)
        return np.c_[f1, 1 - f1 ** 2]


# ---------------------------------------------------------------- P4 portfolio
MU = _arr(0.08, 0.12, 0.15, 0.10)
SIG = np.array([[0.010, 0.002, 0.001, 0.003], [0.002, 0.040, 0.006, 0.004],
                [0.001, 0.006, 0.090, 0.005], [0.003, 0.004, 0.005, 0.020]])


class P4(Problem):
    n_var = 4; n_obj = 2; lb = np.zeros(4); ub = np.ones(4)
    _cache = {}

    def __init__(self, mode="repair"):
        self.mode = mode
        self.name = "P4 portfolio (%s)" % mode
        ref = self._reference()
        self.ideal = _arr(ref[:, 0].min(), -0.15)
        self.nadir = _arr(0.09, ref[:, 1].max())

    def evaluate(self, X):
        X = np.asarray(X, float)
        s = X.sum(1, keepdims=True)
        if self.mode == "repair":
            W = X / np.where(s <= 1e-12, 1.0, s)
            W = np.where(s <= 1e-12, 0.25, W)
            cv = np.zeros(len(X))
        else:                                   # penalty: raw weights, violation |sum-1|
            W = X
            cv = np.maximum(0.0, np.abs(s[:, 0] - 1) - 0.01)
        risk = np.einsum("ni,ij,nj->n", W, SIG, W)
        ret = W @ MU
        return np.c_[risk, -ret], cv

    @classmethod
    def _reference(cls):
        """Reference front: epsilon-constraint on return (own sweep, SLSQP sub-solver)."""
        if "ref" in cls._cache:
            return cls._cache["ref"]
        from scipy.optimize import minimize
        pts = []
        w0 = np.full(4, .25)
        # minimum-risk end first
        for r in np.linspace(0.0, 1, 1):  # placeholder to keep structure simple
            pass
        res0 = minimize(lambda w: w @ SIG @ w, w0, bounds=[(0, 1)] * 4,
                        constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1}], method="SLSQP")
        rmin = float(res0.x @ MU)
        for r in np.linspace(rmin, 0.15, 120):
            res = minimize(lambda w: w @ SIG @ w, w0, bounds=[(0, 1)] * 4, method="SLSQP",
                           constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1},
                                        {"type": "ineq", "fun": lambda w, r=r: w @ MU - r}])
            pts.append([res.x @ SIG @ res.x, -(res.x @ MU)])
        cls._cache["ref"] = np.array(pts)
        return cls._cache["ref"]

    def true_front(self, n=300):
        return self._reference()


# ---------------------------------------------------------------- P5 cantilever
class P5(Problem):
    name = "P5 cantilever beam"; n_var = 2; n_obj = 2
    lb = _arr(0.01, 0.02); ub = _arr(0.10, 0.20)
    L, P, E, RHO = 1.0, 1000.0, 200e9, 7850.0
    nadir = _arr(157.0, 0.017010)
    ideal = _arr(3.8457, 2.5e-5)

    def evaluate(self, X):
        b, h = X[:, 0], X[:, 1]
        m = self.RHO * self.L * b * h
        d = 4 * self.P * self.L ** 3 / (self.E * b * h ** 3)
        cv = np.maximum(0.0, 2.4e-5 - b * h ** 2) / 2.4e-5
        return np.c_[m, d], cv

    def true_front(self, n=300):
        A = np.linspace(np.sqrt(2.4e-7), 0.02, n)
        h = np.minimum(0.2, 100 * A); b = A / h
        F, _ = self.evaluate(np.c_[b, h])
        return F


# ---------------------------------------------------------------- P6 Binh-Korn
class P6(Problem):
    name = "P6 Binh-Korn"; n_var = 2; n_obj = 2
    lb = _arr(0, 0); ub = _arr(5, 3); ideal = _arr(0, 4); nadir = _arr(136, 50)

    def evaluate(self, X):
        x1, x2 = X[:, 0], X[:, 1]
        f = np.c_[4 * x1 ** 2 + 4 * x2 ** 2, (x1 - 5) ** 2 + (x2 - 5) ** 2]
        c1 = np.maximum(0, (x1 - 5) ** 2 + x2 ** 2 - 25) / 25
        c2 = np.maximum(0, 7.7 - ((x1 - 8) ** 2 + (x2 + 3) ** 2)) / 7.7
        return f, c1 + c2

    def true_front(self, n=300):
        a = np.linspace(0, 3, n // 2 + 1)
        s1 = np.c_[a, a]
        x1 = np.linspace(3, 5, n // 2 + 1)
        s2 = np.c_[x1, np.full_like(x1, 3.0)]
        S = np.vstack([s1, s2])
        return self.evaluate(S)[0]


# ---------------------------------------------------------------- P7 water allocation
class P7(Problem):
    name = "P7 water allocation"; n_var = 2; n_obj = 2
    lb = _arr(0, 0); ub = _arr(100, 100)
    ideal = _arr(-56, -96); nadir = _arr(-8, -24)
    pref_point = _arr(-0.8 * 40, -1.2 * 50)       # decision maker (40, 50) in min form

    def evaluate(self, X):
        x1, x2 = X[:, 0], X[:, 1]
        cv = np.maximum(0, x1 + x2 - 90) / 90 + np.maximum(0, 10 - x1) / 10 + np.maximum(0, 20 - x2) / 20
        return np.c_[-0.8 * x1, -1.2 * x2], cv

    def true_front(self, n=300):
        x1 = np.linspace(10, 70, n)
        return np.c_[-0.8 * x1, -1.2 * (90 - x1)]


# ---------------------------------------------------------------- P8 bi-objective TSP
class P8(Problem):
    kind = "perm"; name = "P8 bi-objective TSP (15 cities)"; n_obj = 2; n_var = 15

    def __init__(self):
        np.random.seed(7)
        self.xy = np.random.uniform(0, 100, (15, 2))
        d = np.sqrt(((self.xy[:, None] - self.xy[None]) ** 2).sum(2))
        u = np.random.uniform(0.5, 2.0, (15, 15))
        u = np.triu(u, 1); u = u + u.T
        self.D = d; self.T = d * u
        self.lb = np.zeros(15); self.ub = np.ones(15)
        # ideal / nadir from my own 2-opt on each single objective
        td = self.two_opt(self.D, restarts=30); tt = self.two_opt(self.T, restarts=30)
        self.tour_d, self.tour_t = td, tt
        self.ideal = _arr(self.length(self.D, td), self.length(self.T, tt))
        self.nadir = _arr(self.length(self.D, tt), self.length(self.T, td))

    @staticmethod
    def length(C, t):
        return float(C[t, np.roll(t, -1)].sum())

    def two_opt(self, C, restarts=10, seed=0):
        r = np.random.default_rng(seed); best = None; bl = 1e18
        n = len(C)
        for _ in range(restarts):
            t = r.permutation(n); imp = True
            while imp:
                imp = False
                for i in range(n - 1):
                    for j in range(i + 2, n):
                        a, b, c, d = t[i], t[i + 1], t[j], t[(j + 1) % n]
                        if a == d:
                            continue
                        if C[a, c] + C[b, d] < C[a, b] + C[c, d] - 1e-12:
                            t[i + 1:j + 1] = t[i + 1:j + 1][::-1]; imp = True
            l = self.length(C, t)
            if l < bl:
                bl, best = l, t.copy()
        return best

    def nearest_neighbour(self, C, start=0):
        n = len(C); t = [start]; left = set(range(n)) - {start}
        while left:
            nxt = min(left, key=lambda j: C[t[-1], j]); t.append(nxt); left.remove(nxt)
        return np.array(t)

    def evaluate(self, X):
        X = np.asarray(X, int)
        nx = np.roll(X, -1, axis=1)
        return np.c_[self.D[X, nx].sum(1), self.T[X, nx].sum(1)], np.zeros(len(X))


# ---------------------------------------------------------------- P9 feature selection
class P9(Problem):
    kind = "binary"; name = "P9 feature selection (Wisconsin)"; n_obj = 2; n_var = 30
    lb = np.zeros(30); ub = np.ones(30); ideal = _arr(0.0, 1.0); nadir = _arr(0.40, 30.0)

    def __init__(self):
        from sklearn.datasets import load_breast_cancer      # data loading only
        d = load_breast_cancer()
        X = d.data.astype(float)
        X = (X - X.mean(0)) / X.std(0)                        # my own z-score
        self.X = X; self.y = d.target.astype(int); self.names = list(d.feature_names)
        n = len(self.y)
        self.D2 = ((X[:, None, :] - X[None, :, :]) ** 2).astype(np.float32)   # (n, n, 30)
        r = np.random.default_rng(0)
        self.folds = np.array_split(r.permutation(n), 5)
        self._cache = {}

    def knn_cv_error(self, mask):
        key = mask.tobytes()
        if key in self._cache:
            return self._cache[key]
        dist = self.D2 @ mask.astype(np.float32)               # (n, n) masked squared distances
        n = len(self.y); correct = 0
        for k in range(5):
            te = self.folds[k]; tr = np.concatenate([self.folds[j] for j in range(5) if j != k])
            Dm = dist[np.ix_(te, tr)]
            nn = np.argpartition(Dm, 5, axis=1)[:, :5]
            votes = self.y[tr][nn].sum(1)
            pred = (votes >= 3).astype(int)
            correct += (pred == self.y[te]).sum()
        err = 1.0 - correct / n
        self._cache[key] = err
        return err

    def evaluate(self, X):
        M = (np.asarray(X) > 0.5).astype(int) if np.asarray(X).dtype != int else np.asarray(X)
        F = np.zeros((len(M), 2)); cv = np.zeros(len(M))
        for i, m in enumerate(M):
            if m.sum() == 0:
                F[i] = (1.0, 0.0); cv[i] = 1.0
            else:
                F[i] = (self.knn_cv_error(m), m.sum())
        return F, cv


# ---------------------------------------------------------------- P10 DTLZ2
class P10(Problem):
    def __init__(self, M=3):
        self.n_obj = M; self.n_var = M + 9; self.name = "P10 DTLZ2 (M=%d)" % M
        self.lb = np.zeros(self.n_var); self.ub = np.ones(self.n_var)
        self.ideal = np.zeros(M); self.nadir = np.ones(M)

    def evaluate(self, X):
        M = self.n_obj
        g = ((X[:, M - 1:] - 0.5) ** 2).sum(1)
        F = np.zeros((len(X), M))
        c = np.cos(X[:, :M - 1] * np.pi / 2); s = np.sin(X[:, :M - 1] * np.pi / 2)
        for m in range(1, M + 1):
            f = (1 + g)
            k = M - m
            if k > 0:
                f = f * np.prod(c[:, :k], axis=1)
            if m > 1:
                f = f * s[:, M - m]
            F[:, m - 1] = f
        return F, np.zeros(len(X))

    def true_front(self, n=None):
        H = 30 if self.n_obj == 3 else 8
        Z = U.das_dennis(self.n_obj, H)
        return Z / np.linalg.norm(Z, axis=1, keepdims=True)


# ---------------------------------------------------------------- P14 laptop
class P14(Problem):
    name = "P14 laptop design"; n_var = 2; n_obj = 2
    lb = _arr(13, 40); ub = _arr(17, 90)
    ideal = _arr(1.53, -20.2247); nadir = _arr(2.13, -8.9888)
    pref_point = _arr(1.8, -12.0)

    def evaluate(self, X):
        x1, x2 = X[:, 0], X[:, 1]
        return np.c_[0.4 + 0.05 * x1 + 0.012 * x2, -(0.2 * x2 / (0.5 + 0.03 * x1))], np.zeros(len(X))

    def true_front(self, n=300):
        x2 = np.linspace(40, 90, n)
        return self.evaluate(np.c_[np.full(n, 13.0), x2])[0]


class RealWrap(Problem):
    """Random-key / threshold wrapper so real-coded algorithms can run on P8 / P9."""
    kind = "real"

    def __init__(self, p):
        self.p = p; self.n_var = p.n_var; self.n_obj = p.n_obj
        self.lb = np.zeros(p.n_var); self.ub = np.ones(p.n_var)
        self.ideal, self.nadir = p.ideal, p.nadir; self.name = p.name + " [real-coded]"

    def evaluate(self, X):
        if self.p.kind == "perm":
            return self.p.evaluate(np.argsort(X, axis=1))
        return self.p.evaluate((X > 0.5).astype(int))

    def true_front(self, n=300):
        return self.p.true_front(n)


def get_problem(name, **kw):
    return {"P1": P1, "P2": P2, "P3": P3, "P4": P4, "P5": P5, "P6": P6, "P7": P7, "P8": P8,
            "P9": P9, "P10": P10, "P14": P14}[name](**kw)
