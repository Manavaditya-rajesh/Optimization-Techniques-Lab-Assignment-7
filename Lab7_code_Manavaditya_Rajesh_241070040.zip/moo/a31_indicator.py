"""Algorithms 31-35: RVEA, IBEA, SMS-EMOA, HypE, R-NSGA-II.

RVEA (Cheng 2016): reference vectors; angle-penalised distance APD = (1 + M (t/tmax)^a theta/gamma_v) ||f'||;
each vector keeps its min-APD member; vectors re-scaled to the current objective range every fr*tmax gens.
IBEA (Zitzler & Kuenzli 2004): additive eps-indicator I(x,y)=max_i(f_i(x)-f_i(y)); F(x)=sum_y -exp(-I(y,x)/(c kappa));
remove the worst repeatedly and update the others; binary tournament on F.
SMS-EMOA (Beume 2007): steady state (mu+1); last non-dominated front loses the point with least exclusive hypervolume.
HypE (Bader & Zitzler 2011): Monte-Carlo hypervolume contribution with the k-weights alpha_i = prod_{j<i}(k-j)/(m-j)/i.
R-NSGA-II (Deb & Sundar 2006): NSGA-II whose last front is ordered by distance to the decision-maker's reference
points, with epsilon-clearing to keep a spread around them.
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA


# ------------------------------------------------------------------------- RVEA
def apd_select(F, V, gamma, M, t, tmax, alpha=2.0):
    Fp = F - F.min(0)
    nrm = np.linalg.norm(Fp, axis=1); nrm = np.where(nrm < 1e-12, 1e-12, nrm)
    cos = np.clip((Fp / nrm[:, None]) @ V.T, -1, 1)
    j = cos.argmax(1); theta = np.arccos(cos[np.arange(len(F)), j])
    apd = (1 + M * (t / tmax) ** alpha * theta / gamma[j]) * nrm
    keep = []
    for v in range(len(V)):
        m = np.where(j == v)[0]
        if len(m):
            keep.append(int(m[np.argmin(apd[m])]))
    return np.array(keep, int), j


class RVEA(MOEA):
    name = "RVEA"

    def __init__(self, problem, pop=None, seed=0, cmode="penalty", H=12, alpha=2.0, fr=0.1, **kw):
        from .a18_decomposition import weights_for
        M = problem.n_obj
        V0 = U.das_dennis(M, H); self.V0 = V0 / np.linalg.norm(V0, axis=1, keepdims=True)
        super().__init__(problem, pop or len(V0), seed, cmode, **kw)
        self.alpha, self.fr = alpha, fr; self.t = 0; self.V = self.V0.copy(); self.set_gamma()

    def set_gamma(self):
        c = np.clip(self.V @ self.V.T, -1, 1); np.fill_diagonal(c, -1)
        self.gamma = np.maximum(np.arccos(c.max(1)), 1e-6)

    def iterate(self):
        self.t += 1; M = self.prob.n_obj
        idx = self.rng.integers(len(self.X), size=self.N)
        Xo = self.ops.variate(self.X[idx], self.rng); Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        keep, _ = apd_select(F, self.V, self.gamma, M, self.t, self.max_iters, self.alpha)
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]
        if self.t % max(1, int(self.fr * self.max_iters)) == 0:           # reference-vector adaptation
            rngv = self.F.max(0) - self.F.min(0); rngv = np.where(rngv < 1e-9, 1.0, rngv)
            V = self.V0 * rngv; self.V = V / np.linalg.norm(V, axis=1, keepdims=True); self.set_gamma()


# ------------------------------------------------------------------------- IBEA
def ibea_matrix(F, kappa):
    I = (F[:, None, :] - F[None, :, :]).max(2)               # I[i,j] = I(i, j)
    c = max(np.abs(I).max(), 1e-12)
    return np.exp(-I / (c * kappa))


def ibea_fitness(F, kappa=0.05):
    Mx = ibea_matrix(F, kappa)
    return -(Mx.sum(0) - 1.0)                                # F(x) = -sum_{y!=x} exp(-I(y,x)/(c k))


class IBEA(MOEA):
    name = "IBEA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", kappa=0.05, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.kappa = kappa

    def select(self, F, N):
        Mx = ibea_matrix(F, self.kappa); alive = np.ones(len(F), bool); fit = -(Mx.sum(0) - 1.0)
        while alive.sum() > N:
            w = np.where(alive)[0][np.argmin(fit[alive])]
            alive[w] = False; fit = fit + Mx[w]               # remove w: others lose its (negative) contribution
        return np.where(alive)[0]

    def iterate(self):
        fit = ibea_fitness(self.F, self.kappa)
        a = self.rng.integers(self.N, size=self.N); b = self.rng.integers(self.N, size=self.N)
        idx = np.where(fit[a] >= fit[b], a, b)
        Xo = self.ops.variate(self.X[idx], self.rng); Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        k = self.select(F, self.N)
        self.X, self.F, self.CV = X[k], F[k], CV[k]


# ------------------------------------------------------------------------- SMS-EMOA
def hv_contributions(F, ref, seed=0):
    n, M = F.shape
    if M == 2:
        o = np.argsort(F[:, 0]); Fs = F[o]; c = np.zeros(n)
        for k in range(n):
            right = Fs[k + 1, 0] if k + 1 < n else ref[0]
            up = Fs[k - 1, 1] if k > 0 else ref[1]
            c[o[k]] = max(0.0, (min(right, ref[0]) - Fs[k, 0])) * max(0.0, (min(up, ref[1]) - Fs[k, 1]))
        return c
    tot = U.hv_mc(F, ref, n=20000, seed=seed)
    return np.array([tot - U.hv_mc(np.delete(F, i, 0), ref, n=20000, seed=seed) for i in range(n)])


class SMSEMOA(MOEA):
    name = "SMS-EMOA"
    step_cost = 1

    def iterate(self):
        i, j = self.rng.integers(self.N, size=2)
        child = self.ops.variate(self.X[[i, j]], self.rng)[:1]
        Fc, CVc = self.evaluate(child)
        X = np.concatenate([self.X, child]); F = np.concatenate([self.F, Fc]); CV = np.concatenate([self.CV, CVc])
        fronts = U.fast_nondominated_sort(F)
        last = fronts[-1]
        if len(last) == 1:
            drop = last[0]
        else:
            ref = np.full(F.shape[1], 1.1)
            drop = last[np.argmin(hv_contributions(F[last], ref))]
        keep = np.ones(len(X), bool); keep[drop] = False
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]


# ------------------------------------------------------------------------- HypE
def hype_alpha(m, k):
    """alpha_c for c = 1..m (c dominating solutions): prod_{j=1}^{c-1} (k-j)/(m-j) / c."""
    al = np.zeros(m + 1); prod = 1.0
    for c in range(1, m + 1):
        if c > 1:
            prod *= (k - (c - 1)) / (m - (c - 1))
        al[c] = prod / c
    return al


def hype_fitness(F, k, ref, rng, S=3000):
    lo = F.min(0); M = F.shape[1]
    samp = lo + rng.random((S, M)) * (ref - lo)
    dom = (F[None, :, :] <= samp[:, None, :]).all(2)
    cnt = dom.sum(1)
    al = hype_alpha(len(F), k)
    fit = (dom * al[cnt][:, None]).sum(0) * np.prod(ref - lo) / S
    return fit


class HypE(MOEA):
    name = "HypE"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", S=3000, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.S = S

    def reduce(self, F, n_remove):
        ref = np.full(F.shape[1], 1.1); alive = list(range(len(F)))
        for step in range(n_remove):
            k = n_remove - step
            fit = hype_fitness(F[alive], min(k, len(alive)), ref, self.rng, self.S)
            alive.pop(int(np.argmin(fit)))
        return np.array(alive, int)

    def iterate(self):
        rank, _ = self.rank_crowd(self.F, self.CV)
        a = self.rng.integers(self.N, size=self.N); b = self.rng.integers(self.N, size=self.N)
        idx = np.where(rank[a] <= rank[b], a, b)
        Xo = self.ops.variate(self.X[idx], self.rng); Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        chosen = []
        for fr in U.fast_nondominated_sort(F):
            if len(chosen) + len(fr) <= self.N:
                chosen += fr.tolist()
            else:
                need = self.N - len(chosen); fr = np.array(fr)
                chosen += fr[self.reduce(F[fr], len(fr) - need)].tolist(); break
        k = np.array(chosen)
        self.X, self.F, self.CV = X[k], F[k], CV[k]


# ------------------------------------------------------------------------- R-NSGA-II
def rnsga2_select(F, N, refs, eps, rng, CV=None):
    chosen = []
    span = np.maximum(F.max(0) - F.min(0), 1e-12)
    for fr in U.fast_nondominated_sort(F, CV):
        if len(chosen) + len(fr) <= N:
            chosen += fr.tolist(); continue
        Fn = F[fr] / span
        pref = np.full(len(fr), np.inf)
        for r in refs:
            d = np.linalg.norm(Fn - r / span, axis=1)
            rk = np.empty(len(fr)); rk[np.argsort(d)] = np.arange(1, len(fr) + 1)
            pref = np.minimum(pref, rk)
        order = list(np.argsort(pref + 1e-6 * rng.random(len(fr))))
        taken, deferred = [], []
        pool = order[:]
        while pool:                                         # epsilon-clearing
            c = pool.pop(0); taken.append(c)
            near = [q for q in pool if np.linalg.norm(Fn[q] - Fn[c]) < eps]
            deferred += near; pool = [q for q in pool if q not in near]
        seq = taken + deferred
        chosen += [int(fr[q]) for q in seq[:N - len(chosen)]]
        break
    return np.array(chosen, int)


class RNSGA2(MOEA):
    name = "R-NSGA-II"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", refs=None, eps=0.01, **kw):
        super().__init__(problem, pop, seed, cmode, **kw)
        self.refs = np.atleast_2d(refs if refs is not None else problem.norm(problem.pref_point)); self.eps = eps

    def iterate(self):
        rank, crowd = self.rank_crowd(self.F, self.CV)
        idx = self.tournament(rank, crowd, self.N)
        Xo = self.ops.variate(self.X[idx], self.rng); Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        keep = rnsga2_select(F, self.N, self.refs, self.eps, self.rng, self.cvd(CV))
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]
