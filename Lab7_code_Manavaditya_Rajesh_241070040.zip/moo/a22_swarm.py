"""Algorithms 22-25: MOPSO, MOGWO, MOABC, MOACO.

MOPSO (Coello 2004): v = w v + c1 r1 (pbest-x) + c2 r2 (leader-x); leader drawn from an external grid archive
(roulette on 1/cell-count^2); pbest updated by dominance; turbulence mutation.  w=0.4, c1=c2=1.5, archive 100.
MOGWO (Mirjalili 2016): alpha/beta/delta leaders = 3 archive members from least crowded hyper-cubes;
X = (X1+X2+X3)/3 with X_k = L_k - A_k |C_k L_k - X|, a: 2 -> 0; archive pruning from the most crowded cell.
MOABC (Akbari 2012): employed bees v = x + phi (x - x_k) on one dimension, greedy by dominance; onlookers
choose sources by rank-based probability; scouts re-initialise sources whose trial > limit; archive keeps the front.
MOACO (Iredi 2001 style, two pheromone matrices): p_ij ~ (tau1^l tau2^(1-l))^alpha (eta1^l eta2^(1-l))^beta with a
different lambda per ant; non-dominated ants deposit on both matrices; evaporation rho.
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA, Archive


class MOPSO(MOEA):
    name = "MOPSO"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", w=0.4, c1=1.5, c2=1.5, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.w, self.c1, self.c2 = w, c1, c2
        self.arc = Archive(100, "grid", 20); self.t = 0

    def initialize(self):
        super().initialize()
        self.V = np.zeros_like(self.X, float); self.PX = self.X.copy(); self.PF = self.F.copy()
        self.arc.add(self.X, self.F, self.CV, self.rng)

    def velocity(self, V, X, PX, L, r1, r2):
        return self.w * V + self.c1 * r1 * (PX - X) + self.c2 * r2 * (L - X)

    def iterate(self):
        self.t += 1; p = self.prob
        L = self.arc.X[self.arc.pick(self.rng, self.N)]
        r1 = self.rng.random(self.X.shape); r2 = self.rng.random(self.X.shape)
        self.V = self.velocity(self.V, self.X, self.PX, L, r1, r2)
        X = np.clip(self.X + self.V, p.lb, p.ub)
        out = (X <= p.lb) | (X >= p.ub); self.V = np.where(out, -self.V, self.V)
        # turbulence mutation (probability decays with iterations)
        pm = (1 - self.t / max(1, 10000 // self.N)) ** 1.5
        mm = self.rng.random(len(X)) < 0.5 * max(pm, 0)
        if mm.any():
            X[mm] = self.ops.mutate(X[mm], self.rng)
        F, CV = self.evaluate(X)
        self.X, self.F, self.CV = X, F, CV
        dom = np.array([U.dominates(F[i], self.PF[i]) for i in range(self.N)])
        nd = np.array([(not dom[i]) and (not U.dominates(self.PF[i], F[i])) for i in range(self.N)])
        up = dom | (nd & (self.rng.random(self.N) < 0.5))
        self.PX[up] = X[up]; self.PF[up] = F[up]
        self.arc.add(X, F, CV, self.rng)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


class MOGWO(MOEA):
    name = "MOGWO"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", iters=None, **kw):
        super().__init__(problem, pop, seed, cmode, **kw)
        self.arc = Archive(100, "grid", 20); self.t = 0; self.iters = iters or 99

    def initialize(self):
        super().initialize(); self.arc.add(self.X, self.F, self.CV, self.rng)

    def leaders(self):
        ids = self.arc.pick(self.rng, 3)
        if len(self.arc.X) >= 3:
            ids = np.array(self.rng.choice(len(self.arc.X), 3, replace=False,
                                           p=self._probs()))
        return self.arc.X[ids]

    def _probs(self):
        inv, cnt = self.arc.cells(self.arc.F); w = 1.0 / cnt[inv] ** 2
        return w / w.sum()

    def iterate(self):
        self.t += 1; p = self.prob
        a = 2.0 * (1 - self.t / self.iters); a = max(a, 0.0)
        Lead = self.leaders(); Xn = np.zeros_like(self.X, float)
        for L in Lead:
            r1 = self.rng.random(self.X.shape); r2 = self.rng.random(self.X.shape)
            A = 2 * a * r1 - a; C = 2 * r2
            Xn += (L - A * np.abs(C * L - self.X)) / 3.0
        # out-of-range coordinates are re-sampled uniformly: clipping piles the pack onto the bounds
        bad = (Xn < p.lb) | (Xn > p.ub)
        X = np.where(bad, p.lb + self.rng.random(Xn.shape) * (p.ub - p.lb), Xn)
        F, CV = self.evaluate(X)
        self.X, self.F, self.CV = X, F, CV
        self.arc.add(X, F, CV, self.rng)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


def abc_greedy(Fnew, Fold):
    """+1 replace (new dominates), 0 mutually non-dominated, -1 keep (old dominates/equal)."""
    if U.dominates(Fnew, Fold):
        return 1
    if U.dominates(Fold, Fnew):
        return -1
    return 0


class MOABC(MOEA):
    name = "MOABC"

    def __init__(self, problem, pop=50, seed=0, cmode="penalty", limit=20, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.limit = limit
        self.arc = Archive(100, "crowding")

    def initialize(self):
        super().initialize(); self.trial = np.zeros(self.N, int)
        self.arc.add(self.X, self.F, self.CV, self.rng)

    def cost(self):
        return 2 * self.N

    def neighbour(self, idx):
        p = self.prob; n = self.X.shape[1]
        k = np.array([self.rng.choice([j for j in range(self.N) if j != i]) for i in idx])
        j = self.rng.integers(n, size=len(idx)); phi = self.rng.uniform(-1, 1, len(idx))
        V = self.X[idx].astype(float).copy()
        V[np.arange(len(idx)), j] += phi * (self.X[idx, j] - self.X[k, j])
        return np.clip(V, p.lb, p.ub)

    def _phase(self, idx):
        V = self.neighbour(idx)
        Fv, CVv = self.evaluate(V)
        for q, i in enumerate(idx):
            r = abc_greedy(Fv[q], self.F[i])
            if self.cmode == "deb" and (CVv[q] > 0 or self.CV[i] > 0):
                r = 1 if CVv[q] < self.CV[i] else -1
            if r == 1 or (r == 0 and self.rng.random() < 0.5):
                self.X[i], self.F[i], self.CV[i] = V[q], Fv[q], CVv[q]; self.trial[i] = 0
            else:
                self.trial[i] += 1
        self.arc.add(V, Fv, CVv, self.rng)

    def iterate(self):
        self._phase(np.arange(self.N))                                   # employed bees
        rank, _ = U.rank_and_crowding(self.F)
        prob = 1.0 / (1.0 + rank); prob /= prob.sum()
        self._phase(self.rng.choice(self.N, self.N, p=prob))             # onlookers
        scouts = np.where(self.trial > self.limit)[0]
        if len(scouts):                                                  # scouts re-initialise (no extra budget counted beyond 1 eval each)
            Xs = self.ops.init(len(scouts), self.rng); Fs, CVs = self.evaluate(Xs)
            self.X[scouts], self.F[scouts], self.CV[scouts] = Xs, Fs, CVs; self.trial[scouts] = 0
            self.arc.add(Xs, Fs, CVs, self.rng)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


class MOACO(MOEA):
    name = "MOACO"

    def __init__(self, problem, pop=20, seed=0, cmode="penalty", alpha=1.0, beta=2.0, rho=0.1, **kw):
        super().__init__(problem, pop, seed, cmode, **kw)
        n = problem.n_var; self.n = n
        self.tau1 = np.ones((n, n)); self.tau2 = np.ones((n, n)); self.alpha, self.beta, self.rho = alpha, beta, rho
        self.eta1 = 1.0 / (problem.D + np.eye(n)); self.eta2 = 1.0 / (problem.T + np.eye(n))
        self.arc = Archive(100, "crowding")

    def initialize(self):
        self.X = np.array([self.build(k / max(1, self.N - 1)) for k in range(self.N)])
        self.F, self.CV = self.evaluate(self.X); self.arc.add(self.X, self.F, self.CV)

    def probs(self, cur, vis, lam):
        w = ((self.tau1[cur] ** lam) * (self.tau2[cur] ** (1 - lam))) ** self.alpha * \
            ((self.eta1[cur] ** lam) * (self.eta2[cur] ** (1 - lam))) ** self.beta
        w = w.copy(); w[vis] = 0
        return w / w.sum()

    def build(self, lam):
        cur = int(self.rng.integers(self.n)); tour = [cur]; vis = np.zeros(self.n, bool); vis[cur] = True
        for _ in range(self.n - 1):
            nxt = int(self.rng.choice(self.n, p=self.probs(cur, vis, lam)))
            tour.append(nxt); vis[nxt] = True; cur = nxt
        return np.array(tour)

    def iterate(self):
        X = np.array([self.build(k / max(1, self.N - 1)) for k in range(self.N)])
        F, CV = self.evaluate(X)
        self.X, self.F, self.CV = X, F, CV
        self.arc.add(X, F, CV)
        self.tau1 *= (1 - self.rho); self.tau2 *= (1 - self.rho)
        sel = self.rng.choice(len(self.arc.X), min(10, len(self.arc.X)), replace=False)
        for s in sel:
            t = self.arc.X[s]; nx = np.roll(t, -1)
            d = self.prob.norm(np.zeros((1, 2)) + self.arc.F[s] * (self.prob.nadir - self.prob.ideal) + self.prob.ideal)[0]
            self.tau1[t, nx] += 1.0 / (1 + self.arc.F[s][0]); self.tau1[nx, t] += 1.0 / (1 + self.arc.F[s][0])
            self.tau2[t, nx] += 1.0 / (1 + self.arc.F[s][1]); self.tau2[nx, t] += 1.0 / (1 + self.arc.F[s][1])
        np.clip(self.tau1, 0.01, 20, out=self.tau1); np.clip(self.tau2, 0.01, 20, out=self.tau2)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))
