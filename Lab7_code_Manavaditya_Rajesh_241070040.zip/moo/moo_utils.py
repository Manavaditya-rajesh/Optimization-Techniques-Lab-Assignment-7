"""moo_utils - shared multiobjective toolkit (hand-written, NumPy only).

Contents: dominance test, Deb's constrained dominance, fast non-dominated sorting,
crowding distance, rank+crowding survivor selection, 2-D exact hypervolume,
Monte-Carlo hypervolume (M>=3), IGD, Spacing, objective normalisation and
Das-Dennis reference points.  All objectives are MINIMISED (Max f == Min -f).
"""
import numpy as np


# ------------------------------------------------------------------ dominance
def dominates(a, b):
    """a dominates b: a<=b in every objective and a<b in at least one."""
    a = np.asarray(a); b = np.asarray(b)
    return bool(np.all(a <= b) and np.any(a < b))


def constrained_dominates(fa, cva, fb, cvb):
    """Deb's three rules. cv = total constraint violation (<=0 or 0 means feasible).
    1) feasible beats infeasible 2) both infeasible: smaller violation wins
    3) both feasible: ordinary Pareto dominance."""
    if cva <= 0 and cvb > 0:
        return True
    if cva > 0 and cvb <= 0:
        return False
    if cva > 0 and cvb > 0:
        return cva < cvb
    return dominates(fa, fb)


def dominance_matrix(F, CV=None):
    """D[i, j] == True  <=>  i dominates j (with Deb's rules when CV is given)."""
    F = np.asarray(F, float)
    D = (F[:, None, :] <= F[None, :, :]).all(2) & (F[:, None, :] < F[None, :, :]).any(2)
    if CV is not None:
        CV = np.asarray(CV, float)
        fe = CV <= 0
        D = (D & fe[:, None] & fe[None, :]) | (fe[:, None] & ~fe[None, :]) | \
            (~fe[:, None] & ~fe[None, :] & (CV[:, None] < CV[None, :]))
    return D


def fast_nondominated_sort(F, CV=None):
    """Deb's fast non-dominated sorting. Returns a list of index arrays (fronts)."""
    n = len(F)
    if n == 0:
        return []
    D = dominance_matrix(F, CV)
    cnt = D.sum(0).astype(int)          # number of solutions dominating j
    remaining = np.ones(n, bool)
    fronts = []
    while remaining.any():
        cur = np.where(remaining & (cnt == 0))[0]
        if len(cur) == 0:               # safety (cannot happen for a strict partial order)
            cur = np.where(remaining)[0]
        fronts.append(cur)
        remaining[cur] = False
        cnt = cnt - D[cur].sum(0)
    return fronts


def nondominated_mask(F, CV=None, feasible_only=True):
    """Mask of feasible, non-dominated rows."""
    F = np.asarray(F, float)
    if len(F) == 0:
        return np.zeros(0, bool)
    m = np.zeros(len(F), bool)
    idx = np.arange(len(F))
    if CV is not None and feasible_only:
        idx = idx[np.asarray(CV) <= 0]
    if len(idx) == 0:
        return m
    D = dominance_matrix(F[idx])
    m[idx[~D.any(0)]] = True
    # drop exact duplicates (keep first)
    keep = np.zeros(len(F), bool)
    seen = set()
    for i in np.where(m)[0]:
        key = tuple(np.round(F[i], 12))
        if key not in seen:
            seen.add(key); keep[i] = True
    return keep


def crowding_distance(F):
    """Crowding distance of one front (boundary points get inf)."""
    F = np.asarray(F, float)
    n, M = F.shape
    d = np.zeros(n)
    if n <= 2:
        d[:] = np.inf
        return d
    for m in range(M):
        o = np.argsort(F[:, m], kind="stable")
        rng_ = F[o[-1], m] - F[o[0], m]
        d[o[0]] = d[o[-1]] = np.inf
        if rng_ <= 0:
            continue
        d[o[1:-1]] += (F[o[2:], m] - F[o[:-2], m]) / rng_
    return d


def rank_and_crowding(F, CV=None):
    """Rank (0 = best front) and crowding distance (computed inside each front)."""
    n = len(F)
    rank = np.zeros(n, int); crowd = np.zeros(n)
    for r, fr in enumerate(fast_nondominated_sort(F, CV)):
        rank[fr] = r
        crowd[fr] = crowding_distance(F[fr])
    return rank, crowd


def nsga2_survivors(F, CV, N):
    """Fill N slots front by front; the last front is cut by crowding distance."""
    chosen = []
    for fr in fast_nondominated_sort(F, CV):
        if len(chosen) + len(fr) <= N:
            chosen.extend(fr.tolist())
        else:
            cd = crowding_distance(F[fr])
            o = np.argsort(-cd, kind="stable")
            chosen.extend(fr[o[:N - len(chosen)]].tolist())
            break
    return np.array(chosen, int)


# ------------------------------------------------------------------ indicators
def hypervolume_2d(F, ref):
    """Exact 2-D hypervolume (minimisation) w.r.t. reference point ref."""
    F = np.asarray(F, float); ref = np.asarray(ref, float)
    if len(F) == 0:
        return 0.0
    F = F[(F < ref).all(1)]
    if len(F) == 0:
        return 0.0
    F = F[np.argsort(F[:, 0], kind="stable")]
    hv = 0.0; best_f2 = ref[1]
    for f1, f2 in F:
        if f2 < best_f2:
            hv += (ref[0] - f1) * (best_f2 - f2)
            best_f2 = f2
    return float(hv)


def hv_mc(F, ref, lo=None, n=40000, seed=12345):
    """Monte-Carlo hypervolume for M>=3 inside box [lo, ref] (common random numbers)."""
    F = np.asarray(F, float); ref = np.asarray(ref, float)
    M = len(ref)
    lo = np.zeros(M) if lo is None else np.asarray(lo, float)
    F = F[(F < ref).all(1)]
    if len(F) == 0:
        return 0.0
    r = np.random.default_rng(seed)
    S = lo + r.random((n, M)) * (ref - lo)
    dom = np.zeros(n, bool)
    for i in range(0, len(F), 64):
        dom |= (F[i:i + 64][None, :, :] <= S[:, None, :]).all(2).any(1)
    return float(dom.mean() * np.prod(ref - lo))


def hypervolume(F, ref, lo=None):
    return hypervolume_2d(F, ref) if len(ref) == 2 else hv_mc(F, ref, lo)


def igd(true_front, F):
    """Mean distance from every true-front point to the nearest obtained point."""
    if len(F) == 0:
        return np.inf
    d = np.sqrt(((true_front[:, None, :] - F[None, :, :]) ** 2).sum(2))
    return float(d.min(1).mean())


def spacing(F):
    """Schott-style spacing: std of nearest-neighbour distances (smaller = more even)."""
    F = np.asarray(F, float)
    if len(F) < 3:
        return 0.0
    d = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(2))
    np.fill_diagonal(d, np.inf)
    nn = d.min(1)
    return float(nn.std())


def normalize(F, ideal, nadir):
    return (np.asarray(F, float) - ideal) / (nadir - ideal)


# ------------------------------------------------------------------ reference points
def das_dennis(M, H):
    """Das-Dennis simplex-lattice reference points with H divisions."""
    out = []
    def rec(prefix, left, k):
        if k == 1:
            out.append(prefix + [left]); return
        for i in range(left + 1):
            rec(prefix + [i], left - i, k - 1)
    rec([], H, M)
    return np.array(out, float) / H


def pareto_filter(F):
    """Return a non-dominated copy of F (used to build reference fronts)."""
    return F[nondominated_mask(F)]
