"""Algorithms 10-13: VEGA, MOGA, NSGA, NPGA (non-elitist, final population is the result).

VEGA (Schaffer 1985): M sub-populations of size N/M, each filled by selection on ONE objective; shuffle;
crossover+mutation.   MOGA (Fonseca & Fleming 1993): rank = 1 + #dominators, linear fitness by rank,
fitness sharing (sigma_share) among equal ranks.   NSGA (Srinivas & Deb 1994): successive fronts get
a dummy fitness; sharing inside each front; stochastic remainder -> roulette here.
NPGA (Horn 1994): Pareto tournament between 2 candidates against a random comparison set of size t_dom;
niche count (sharing) breaks ties.
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA


def sharing_counts(F, sigma):
    d = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(2))
    sh = np.where(d < sigma, 1.0 - d / sigma, 0.0)
    return sh.sum(1)


def roulette(fit, n, rng):
    p = np.maximum(fit, 1e-12); p = p / p.sum()
    return rng.choice(len(fit), size=n, p=p)


class VEGA(MOEA):
    name = "VEGA"

    def parts(self, F):
        """Sub-population m (size N/M) is filled by tournament on objective m ONLY."""
        M = F.shape[1]; per = self.N // M; out = []
        for m in range(M):
            a = self.rng.integers(len(F), size=per); b = self.rng.integers(len(F), size=per)
            out.append(np.where(F[a, m] <= F[b, m], a, b))
        return out

    def subpop_select(self, F):
        idx = np.concatenate(self.parts(F))
        if len(idx) < self.N:
            idx = np.concatenate([idx, self.rng.integers(len(F), size=self.N - len(idx))])
        return self.rng.permutation(idx)

    def iterate(self):
        idx = self.subpop_select(self.F)
        self.X = self.ops.variate(self.X[idx], self.rng)
        self.F, self.CV = self.evaluate(self.X)


class MOGA(MOEA):
    name = "MOGA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", sigma=0.1, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.sigma = sigma

    @staticmethod
    def ranks(F):
        D = U.dominance_matrix(F)
        return 1 + D.sum(0)

    def fitness(self, F):
        r = self.ranks(F); n = len(F)
        order = np.argsort(r, kind="stable")
        raw = np.empty(n); raw[order] = n - np.arange(n)        # best rank -> highest raw fitness
        out = np.zeros(n)
        for rk in np.unique(r):                                  # average raw fitness of each rank, then share
            m = r == rk
            avg = raw[m].mean(); nc = sharing_counts(F[m], self.sigma)
            sh = avg / nc; out[m] = sh * avg * m.sum() / sh.sum()
        return out

    def iterate(self):
        fit = self.fitness(self.F)
        idx = roulette(fit, self.N, self.rng)
        self.X = self.ops.variate(self.X[idx], self.rng)
        self.F, self.CV = self.evaluate(self.X)


class NSGA(MOEA):
    name = "NSGA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", sigma=0.1, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.sigma = sigma

    def fitness(self, F):
        fit = np.zeros(len(F)); dummy = float(len(F))
        for fr in U.fast_nondominated_sort(F):
            nc = sharing_counts(F[fr], self.sigma)
            fit[fr] = dummy / nc
            dummy = fit[fr].min() * 0.9                 # next front always gets lower dummy fitness
        return fit

    def iterate(self):
        idx = roulette(self.fitness(self.F), self.N, self.rng)
        self.X = self.ops.variate(self.X[idx], self.rng)
        self.F, self.CV = self.evaluate(self.X)


class NPGA(MOEA):
    name = "NPGA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", sigma=0.1, tdom=0.1, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.sigma = sigma; self.tdom = tdom

    def pareto_tournament(self, F, i, j, comp):
        """Return the winner index; ties -> smaller niche count."""
        di = any(U.dominates(F[c], F[i]) for c in comp)
        dj = any(U.dominates(F[c], F[j]) for c in comp)
        if di and not dj:
            return j
        if dj and not di:
            return i
        pool = np.unique(np.concatenate([comp, [i, j]]))
        nc = sharing_counts(F[pool], self.sigma)
        ni = nc[np.where(pool == i)[0][0]]; nj = nc[np.where(pool == j)[0][0]]
        return i if ni <= nj else j

    def iterate(self):
        n = len(self.F); t = max(2, int(self.tdom * n)); idx = np.empty(self.N, int)
        for k in range(self.N):
            i, j = self.rng.integers(n, size=2)
            comp = self.rng.choice(n, t, replace=False)
            idx[k] = self.pareto_tournament(self.F, i, j, comp)
        self.X = self.ops.variate(self.X[idx], self.rng)
        self.F, self.CV = self.evaluate(self.X)
