"""Algorithms 14-17, 21: NSGA-II, NSGA-III, SPEA2, PESA-II, Constrained NSGA-II.

NSGA-II (Deb 2002) steps: 1 random P0 | 2 binary tournament by crowded comparison (rank, then crowding)
| 3 SBX + polynomial mutation -> Q | 4 R=P u Q, fast non-dominated sort | 5 fill next P front by front,
last front cut by crowding distance (elitism).  Defaults: N=100, pc=0.9, eta_c=15, eta_m=20, pm=1/n.
NSGA-III (Deb & Jain 2014): Das-Dennis reference points replace crowding: ideal translation, ASF extreme
points, hyperplane intercepts, perpendicular association, niche-count based filling of the last front.
SPEA2 (Zitzler 2001): strength S(i), raw fitness R(i)=sum S(dominators), density 1/(sigma_k+2),
archive truncation by nearest-neighbour distance.   PESA-II (Corne 2001): grid hyper-boxes of the archive,
region-based selection (less crowded box wins), small internal population (20), archive 100.
Constrained NSGA-II = NSGA-II with Deb's constrained-dominance (cmode='deb').
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA, Archive


class NSGA2(MOEA):
    name = "NSGA-II"

    def __init__(self, problem, pop=100, seed=0, cmode="ignore", **kw):
        super().__init__(problem, pop, seed, cmode, **kw)

    def iterate(self):
        rank, crowd = self.rank_crowd(self.F, self.CV)
        idx = self.tournament(rank, crowd, self.N)
        Xo = self.ops.variate(self.X[idx], self.rng)
        Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        keep = U.nsga2_survivors(F, self.cvd(CV), self.N)
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]


class ConstrainedNSGA2(NSGA2):
    name = "Constrained NSGA-II"

    def __init__(self, problem, pop=100, seed=0, cmode="deb", **kw):
        super().__init__(problem, pop, seed, cmode, **kw)


# ----------------------------------------------------------------------------- NSGA-III
def nsga3_normalize(F):
    ideal = F.min(0); Ft = F - ideal; M = F.shape[1]
    ext = []
    for i in range(M):
        w = np.full(M, 1e-6); w[i] = 1.0
        ext.append(int(np.argmin((Ft / w).max(1))))
    E = Ft[ext]
    try:
        a = np.linalg.solve(E, np.ones(M)); icpt = 1.0 / a
        if np.any(a <= 1e-9) or not np.all(np.isfinite(icpt)):
            raise np.linalg.LinAlgError
    except np.linalg.LinAlgError:
        icpt = Ft.max(0)
    icpt = np.where(icpt < 1e-8, 1.0, icpt)
    return Ft / icpt


def associate(Fn, Z):
    Zn = Z / np.linalg.norm(Z, axis=1, keepdims=True)
    proj = Fn @ Zn.T
    d = np.sqrt(np.maximum((Fn ** 2).sum(1)[:, None] - proj ** 2, 0.0))
    j = d.argmin(1)
    return j, d[np.arange(len(Fn)), j]


def nsga3_select(F, N, Z, rng, CV=None):
    fronts = U.fast_nondominated_sort(F, CV)
    chosen, last = [], None
    for fr in fronts:
        if len(chosen) + len(fr) <= N:
            chosen += fr.tolist()
        else:
            last = fr; break
    if len(chosen) >= N or last is None:
        return np.array(chosen[:N], int)
    St = np.array(chosen + last.tolist())
    j, d = associate(nsga3_normalize(F[St]), Z)
    nc = len(chosen)
    rho = np.bincount(j[:nc], minlength=len(Z)).astype(int)
    cand = {q: [] for q in range(len(Z))}
    for c in range(len(last)):
        cand[j[nc + c]].append(c)
    picked = []
    while len(picked) < N - nc:
        live = [q for q in cand if cand[q]]
        mn = min(rho[q] for q in live)
        q = int(rng.choice([q for q in live if rho[q] == mn]))
        if rho[q] == 0:
            c = min(cand[q], key=lambda c: d[nc + c])
        else:
            c = int(rng.choice(cand[q]))
        cand[q].remove(c); picked.append(c); rho[q] += 1
    return np.array(chosen + [int(last[c]) for c in picked], int)


class NSGA3(MOEA):
    name = "NSGA-III"

    def __init__(self, problem, pop=None, seed=0, cmode="penalty", H=12, **kw):
        M = problem.n_obj
        self.Z = U.das_dennis(M, H)
        n = len(self.Z); pop = pop or int(np.ceil(n / 4.0) * 4)
        super().__init__(problem, pop, seed, cmode, **kw)

    def iterate(self):
        idx = self.rng.integers(self.N, size=self.N)         # random mating (as in the paper)
        Xo = self.ops.variate(self.X[idx], self.rng)
        Fo, CVo = self.evaluate(Xo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        keep = nsga3_select(F, self.N, self.Z, self.rng, self.cvd(CV))
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]


# ----------------------------------------------------------------------------- SPEA2
def spea2_fitness(F):
    n = len(F)
    D = U.dominance_matrix(F)
    S = D.sum(1)
    R = (D * S[:, None]).sum(0).astype(float)
    dist = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(2))
    np.fill_diagonal(dist, np.inf)
    k = max(1, min(int(np.sqrt(n)), n - 1))
    sig = np.sort(dist, axis=1)[:, k - 1]
    return R + 1.0 / (sig + 2.0), R


def spea2_truncate(F, size):
    keep = list(range(len(F)))
    dist = np.sqrt(((F[:, None, :] - F[None, :, :]) ** 2).sum(2)); np.fill_diagonal(dist, np.inf)
    while len(keep) > size:
        sub = dist[np.ix_(keep, keep)]
        srt = np.sort(sub, axis=1)
        order = np.lexsort(srt.T[::-1])
        keep.pop(int(order[0]))
    return np.array(keep, int)


class SPEA2(MOEA):
    name = "SPEA2"

    def initialize(self):
        super().initialize()
        self.AX = self.X[:0]; self.AF = self.F[:0]; self.ACV = self.CV[:0]; self._update()

    def _update(self):
        X = np.concatenate([self.AX, self.X]); F = np.concatenate([self.AF, self.F]); CV = np.concatenate([self.ACV, self.CV])
        fit, R = spea2_fitness(F)
        nd = np.where(fit < 1)[0]
        if len(nd) > self.N:
            sel = nd[spea2_truncate(F[nd], self.N)]
        elif len(nd) < self.N:
            rest = np.where(fit >= 1)[0]; rest = rest[np.argsort(fit[rest])]
            sel = np.concatenate([nd, rest[:self.N - len(nd)]])
        else:
            sel = nd
        self.AX, self.AF, self.ACV = X[sel], F[sel], CV[sel]
        self.Afit = fit[sel]

    def iterate(self):
        a = self.rng.integers(len(self.AX), size=self.N); b = self.rng.integers(len(self.AX), size=self.N)
        idx = np.where(self.Afit[a] <= self.Afit[b], a, b)
        Xo = self.ops.variate(self.AX[idx], self.rng)
        self.X = Xo; self.F, self.CV = self.evaluate(Xo)
        self._update()

    def final_set(self):
        return self.AX, self.AF, self.ACV


# ----------------------------------------------------------------------------- PESA-II
class PESA2(MOEA):
    name = "PESA-II"

    def __init__(self, problem, pop=20, seed=0, cmode="penalty", archive=100, divs=10, **kw):
        super().__init__(problem, pop, seed, cmode, **kw)
        self.arc = Archive(archive, "grid", divs)

    def initialize(self):
        super().initialize()
        self.arc.add(self.X, self.F, self.CV, self.rng)

    def iterate(self):
        inv, cnt = self.arc.cells(self.arc.F)
        regions = np.unique(inv)
        parents = []
        for _ in range(self.N):
            r1, r2 = self.rng.choice(regions, 2) if len(regions) > 1 else (regions[0], regions[0])
            r = r1 if cnt[r1] <= cnt[r2] else r2
            parents.append(int(self.rng.choice(np.where(inv == r)[0])))
        Xo = self.ops.variate(self.arc.X[parents], self.rng)
        Fo, CVo = self.evaluate(Xo)
        self.arc.add(Xo, Fo, CVo, self.rng)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))
