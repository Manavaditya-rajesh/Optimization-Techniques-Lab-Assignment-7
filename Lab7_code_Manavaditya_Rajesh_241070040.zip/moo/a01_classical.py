"""Algorithms 1-7: classical scalarisation methods.
(scipy.optimize / linprog only solve the single-objective or LP sub-problem, as allowed in Section 2A;
 scalarisation, sweeps, deviation variables and priority logic are my own code.)

1 Weighted Sum   : min sum w_i f~_i over a sweep of w (multi-start).
2 eps-Constraint : min f_1 s.t. f_i <= eps_i, eps swept between ideal and nadir.
3 Benson         : for a reference point z (feasible-dominated) maximise sum w_i l_i s.t. f_i(x)+l_i = z_i, l_i>=0.
4 Weight metric  : min (sum w_i |f~_i|^p)^(1/p), p = 1, 2, inf (Tchebycheff via an epigraph variable).
5 Value function : maximise a decision-maker utility V(f~)=prod (1.05-f~_i)^a_i.
6 Goal programming: min sum (w+ d+ + w- d-) with f_i + d-_i - d+_i = target_i (LP).
7 Lexicographic  : optimise priority 1, fix it within a tolerance, optimise priority 2, ...
All objective values are normalised f~=(f-ideal)/(nadir-ideal); x is searched in u in [0,1]^n.
"""
import numpy as np
from scipy.optimize import minimize, linprog


def _setup(p):
    lb, ub = p.lb, p.ub
    to_x = lambda u: lb + np.asarray(u) * (ub - lb)
    def fn(u):
        F, CV = p.evaluate(to_x(u)[None, :]); return p.norm(F)[0], CV[0]
    return to_x, fn


def _cons_list(p, fn):
    cons = []
    if p.name.startswith("P4"):
        cons.append({"type": "eq", "fun": lambda u: np.sum(u) - 1})
    elif hasattr(p, "evaluate"):
        cons.append({"type": "ineq", "fun": lambda u: -fn(u)[1] + 1e-9})   # CV <= 0 (feasible)
    return cons


def _solve(obj, u0s, bounds, cons):
    best = None
    for u0 in u0s:
        r = minimize(obj, u0, bounds=bounds, constraints=cons, method="SLSQP", options={"maxiter": 300, "ftol": 1e-10})
        if r.success or best is None:
            if best is None or r.fun < best.fun:
                best = r
    return best


def _starts(n, k, rng):
    return [rng.random(n) for _ in range(k)]


def weighted_sum(p, n_w=21, starts=6, seed=0):
    rng = np.random.default_rng(seed); to_x, fn = _setup(p); out = []
    cons = _cons_list(p, fn); bnd = [(0, 1)] * p.n_var
    for t in np.linspace(0, 1, n_w):
        w = np.array([t, 1 - t]) if p.n_obj == 2 else None
        r = _solve(lambda u: float(w @ fn(u)[0]), _starts(p.n_var, starts, rng), bnd, cons)
        out.append((w, to_x(r.x), fn(r.x)[0]))
    return out


def eps_constraint(p, n_eps=21, starts=6, seed=0, primary=0):
    rng = np.random.default_rng(seed); to_x, fn = _setup(p); out = []
    other = 1 - primary; base = _cons_list(p, fn); bnd = [(0, 1)] * p.n_var
    for e in np.linspace(0, 1, n_eps):
        cons = base + [{"type": "ineq", "fun": lambda u, e=e: e - fn(u)[0][other]}]
        r = _solve(lambda u: fn(u)[0][primary], _starts(p.n_var, starts, rng), bnd, cons)
        if r is not None and (fn(r.x)[0][other] <= e + 1e-6) and fn(r.x)[1] <= 1e-9:
            out.append((e, to_x(r.x), fn(r.x)[0]))
    return out


def benson(p, zs, w=(1.0, 1.0), starts=6, seed=0):
    """zs: list of reference points z~ (normalised). Variables v=[u, l]."""
    rng = np.random.default_rng(seed); to_x, fn = _setup(p); out = []; n = p.n_var; M = p.n_obj
    w = np.asarray(w, float)
    for z in zs:
        cons = [{"type": "eq", "fun": lambda v, z=z: fn(v[:n])[0] + v[n:] - z}]
        if not p.name.startswith("P4"):
            cons.append({"type": "ineq", "fun": lambda v: -fn(v[:n])[1] + 1e-9})
        bnd = [(0, 1)] * n + [(0, None)] * M
        best = None
        for _ in range(starts):
            u0 = rng.random(n); l0 = np.maximum(z - fn(u0)[0], 0)
            r = minimize(lambda v: -float(w @ v[n:]), np.r_[u0, l0], bounds=bnd, constraints=cons, method="SLSQP",
                         options={"maxiter": 300, "ftol": 1e-10})
            ok = np.all(np.abs(fn(r.x[:n])[0] + r.x[n:] - z) < 1e-5)
            if ok and (best is None or r.fun < best.fun):
                best = r
        if best is not None:
            out.append((z, to_x(best.x[:n]), fn(best.x[:n])[0], best.x[n:]))
    return out


def weight_metric(p, n_w=11, pnorm=2, starts=6, seed=0):
    rng = np.random.default_rng(seed); to_x, fn = _setup(p); out = []; n = p.n_var
    cons0 = _cons_list(p, fn)
    for t in np.linspace(0.02, 0.98, n_w):
        w = np.array([t, 1 - t])
        if np.isinf(pnorm):
            cons = [{"type": "ineq", "fun": (lambda v, i=i: v[n] - w[i] * fn(v[:n])[0][i])} for i in range(p.n_obj)]
            cons += [{"type": "ineq", "fun": c["fun"] if False else (lambda v, c=c: c["fun"](v[:n]))} for c in cons0 if c["type"] == "ineq"]
            cons += [{"type": "eq", "fun": (lambda v, c=c: c["fun"](v[:n]))} for c in cons0 if c["type"] == "eq"]
            best = None
            for _ in range(starts):
                u0 = rng.random(n); t0 = (w * fn(u0)[0]).max()
                r = minimize(lambda v: v[n], np.r_[u0, t0], bounds=[(0, 1)] * n + [(0, None)], constraints=cons, method="SLSQP",
                             options={"maxiter": 300, "ftol": 1e-10})
                if best is None or r.fun < best.fun:
                    best = r
            u = best.x[:n]
        else:
            r = _solve(lambda u: float((w * np.abs(fn(u)[0]) ** pnorm).sum() ** (1.0 / pnorm)),
                       _starts(n, starts, rng), [(0, 1)] * n, cons0)
            u = r.x
        out.append((w, to_x(u), fn(u)[0]))
    return out


def value_function(p, alphas, starts=6, seed=0):
    rng = np.random.default_rng(seed); to_x, fn = _setup(p); out = []; cons = _cons_list(p, fn)
    for a in alphas:
        a = np.asarray(a, float)
        V = lambda u: -float(np.prod(np.maximum(1.05 - fn(u)[0], 1e-9) ** a))
        r = _solve(V, _starts(p.n_var, starts, rng), [(0, 1)] * p.n_var, cons)
        out.append((a, to_x(r.x), fn(r.x)[0]))
    return out


# ---------------------------------------------------------------- LP based (P11)
P11_A = np.array([[2.0, 3.0], [4.0, 2.0]]); P11_b = np.array([1200.0, 1600.0])
P11_C = np.array([[4.0, 6.0], [1.0, 1.0]])           # profit, units (to maximise)


def goal_programming(targets, w_plus, w_minus, C=P11_C, A=P11_A, b=P11_b, lb=None):
    """Variables [x(2), d-(M), d+(M)]; rows: C x + d- - d+ = target; min w+.d+ + w-.d-.
    For 'at least' goals only the shortfall d- is penalised (w_plus = 0)."""
    M = len(targets); n = C.shape[1]
    lb = np.zeros(n) if lb is None else np.asarray(lb, float)
    c = np.r_[np.zeros(n), w_minus, w_plus]
    Aeq = np.hstack([C, np.eye(M), -np.eye(M)])
    Aub = np.hstack([A, np.zeros((A.shape[0], 2 * M))])
    r = linprog(c, A_ub=Aub, b_ub=b, A_eq=Aeq, b_eq=targets, bounds=[(l, None) for l in lb] + [(0, None)] * (2 * M), method="highs")
    return r.x[:n], r.x[n:n + M], r.x[n + M:], r.fun


def lexicographic(C=P11_C, A=P11_A, b=P11_b, tol=0.0, order=(0, 1), lb=None):
    """Maximise objective order[0]; add C[o] x >= opt*(1-tol); maximise next; ..."""
    n = C.shape[1]; Aub = A.copy(); bub = b.copy(); log = []
    lb = np.zeros(n) if lb is None else np.asarray(lb, float)
    for o in order:
        r = linprog(-C[o], A_ub=Aub, b_ub=bub, bounds=[(l, None) for l in lb], method="highs")
        opt = -r.fun; log.append((o, opt, r.x.copy()))
        Aub = np.vstack([Aub, -C[o]]); bub = np.r_[bub, -opt * (1 - tol)]
    return r.x, log
