"""Common MOEA skeleton: initialize / evaluate / iterate / run + evaluation budget + archives."""
import numpy as np
from . import moo_utils as U
from .ops import make_ops


class MOEA:
    """Interface shared by every population-based algorithm (funcs: initialize, evaluate, iterate, run).
    Objectives are internally normalised with the problem's ideal/nadir so every metric is comparable.
    cmode: 'penalty' (default; infeasible points get F+1+10*CV), 'deb' (constrained dominance), 'ignore'."""
    name = "MOEA"
    step_cost = None

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", **params):
        self.prob = problem; self.N = pop; self.seed = seed; self.cmode = cmode
        self.rng = np.random.default_rng(seed); self.ops = make_ops(problem)
        self.nfe = 0; self.p = params
        self.X = self.F = self.CV = None

    # -- evaluation (counted) ---------------------------------------------------
    def evaluate(self, X):
        F, CV = self.prob.evaluate(X)
        self.nfe += len(X)
        Fn = self.prob.norm(F)
        if self.cmode == "penalty":
            Fn = Fn + ((CV > 0) * (1.0 + 10.0 * CV))[:, None]
        return Fn, CV

    def cvd(self, CV):
        """CV array to pass to dominance routines (None unless Deb's rules are active)."""
        return CV if self.cmode == "deb" else None

    def sort(self, F, CV):
        return U.fast_nondominated_sort(F, self.cvd(CV))

    def rank_crowd(self, F, CV):
        return U.rank_and_crowding(F, self.cvd(CV))

    def tournament(self, rank, crowd, n):
        a = self.rng.integers(len(rank), size=n); b = self.rng.integers(len(rank), size=n)
        win = (rank[a] < rank[b]) | ((rank[a] == rank[b]) & (crowd[a] >= crowd[b]))
        return np.where(win, a, b)

    # -- interface -----------------------------------------------------------------
    def initialize(self):
        self.X = self.ops.init(self.N, self.rng)
        self.F, self.CV = self.evaluate(self.X)

    def iterate(self):
        raise NotImplementedError

    def cost(self):
        return self.step_cost or self.N

    def run(self, max_evals):
        self.initialize()
        self.max_evals = max_evals
        self.max_iters = max(1, max_evals // self.cost() - 1)      # used by schedules (RVEA, TLBO, SA ...)
        while self.nfe + self.cost() <= max_evals:
            self.iterate()
        return self.result()

    def final_set(self):
        return self.X, self.F, self.CV

    def result(self):
        """Feasible non-dominated set (X, normalised F)."""
        X, F, CV = self.final_set()
        m = U.nondominated_mask(F, CV)
        return X[m], F[m]


class Archive:
    """External non-dominated archive with crowding-distance or grid truncation."""

    def __init__(self, size, mode="crowding", divs=20):
        self.size, self.mode, self.divs = size, mode, divs
        self.X = None; self.F = None

    def add(self, X, F, CV=None, rng=None):
        if CV is not None:
            ok = CV <= 0; X, F = X[ok], F[ok]
        if len(X) == 0:
            return
        if self.X is not None:
            X = np.concatenate([self.X, X]); F = np.concatenate([self.F, F])
        m = U.nondominated_mask(F)
        X, F = X[m], F[m]
        while len(X) > self.size:
            drop = self._victim(F, rng)
            keep = np.ones(len(X), bool); keep[drop] = False
            X, F = X[keep], F[keep]
        self.X, self.F = X, F

    def _victim(self, F, rng):
        if self.mode == "crowding":
            cd = U.crowding_distance(F); cd2 = np.where(np.isinf(cd), 1e18, cd)
            return int(np.argmin(cd2))
        cells, cnt = self.cells(F)
        worst = np.where(cnt[cells] == cnt.max())[0]
        return int(rng.choice(worst)) if rng is not None else int(worst[0])

    def cells(self, F):
        lo, hi = F.min(0), F.max(0); span = np.where(hi > lo, hi - lo, 1.0)
        g = np.minimum(((F - lo) / span * self.divs).astype(int), self.divs - 1)
        key = np.zeros(len(F), np.int64)
        for k in range(F.shape[1]):
            key = key * self.divs + g[:, k]
        u, inv = np.unique(key, return_inverse=True)
        return inv, np.bincount(inv)

    def pick(self, rng, k=1, least_crowded=True):
        """Roulette on 1/count of the grid cell (least crowded cells favoured)."""
        if len(self.X) == 1:
            return np.zeros(k, int)
        inv, cnt = self.cells(self.F)
        w = 1.0 / cnt[inv] ** 2 if least_crowded else np.ones(len(inv))
        return rng.choice(len(self.X), size=k, p=w / w.sum())
