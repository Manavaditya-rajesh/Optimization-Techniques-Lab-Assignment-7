"""Algorithms 26-30: MOSA, MODE, MO-TLBO, MOBA, MOMA.

MOSA (Ulungu/Suppapitnarm style): N parallel chains, neighbour = Gaussian move whose size shrinks with T; a chain
accepts a dominating neighbour always, otherwise with Boltzmann probability exp(-w.dF/T) (random weights w per chain);
geometric cooling T <- alpha T; every visited non-dominated point goes to an archive.
MODE (Xue 2003 / Storn DE): DE/rand/1/bin, F=0.5, CR=0.9; the trial replaces its target ONLY if it dominates it;
archive of non-dominated points returned.
MO-TLBO (Rao 2011): teacher = a non-dominated member, teaching phase X' = X + r (T - TF*mean), TF shrinking 2 -> 1;
learner phase: move toward the dominating partner; greedy-by-dominance acceptance; archive.
MOBA (Yang 2011): f = fmin+(fmax-fmin)beta, v += (x - best) f, x += v; local walk around a archive-picked best with
prob 1-r_i; accept if rand<A_i and not dominated; A_i <- alpha A_i, r_i <- r0 (1-exp(-gamma t)).
MOMA: NSGA-II global search + hill-climbing local search (random-weight scalarisation) on a fraction of offspring.
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA, Archive
from .a14_elitist import NSGA2
from .a22_swarm import abc_greedy


def sa_accept_prob(dF, w, T):
    """dF = F_new - F_old. Dominating neighbour -> 1; else Boltzmann on the weighted scalar change."""
    if np.all(dF <= 0):
        return 1.0
    d = float(np.dot(w, dF))
    return 1.0 if d <= 0 else float(np.exp(-d / T))


class MOSA(MOEA):
    name = "MOSA"

    def __init__(self, problem, pop=20, seed=0, cmode="penalty", T0=0.3, Tend=1e-3, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.T0, self.Tend = T0, Tend
        self.arc = Archive(100, "crowding"); self.T = T0

    def initialize(self):
        super().initialize()
        w = self.rng.random((self.N, self.prob.n_obj)); self.w = w / w.sum(1, keepdims=True)
        self.arc.add(self.X, self.F, self.CV)

    def iterate(self):
        p = self.prob
        alpha = (self.Tend / self.T0) ** (1.0 / max(1, self.max_iters))
        if p.kind == "real":
            sig = (0.02 + 0.3 * np.sqrt(self.T / self.T0)) * (p.ub - p.lb)
            Xn = np.clip(self.X + self.rng.normal(0, 1, self.X.shape) * sig, p.lb, p.ub)
        else:
            Xn = self.ops.mutate(self.X, self.rng)
        Fn, CVn = self.evaluate(Xn)
        for i in range(self.N):
            if self.rng.random() < sa_accept_prob(Fn[i] - self.F[i], self.w[i], self.T):
                self.X[i], self.F[i], self.CV[i] = Xn[i], Fn[i], CVn[i]
        self.arc.add(Xn, Fn, CVn)
        self.T *= alpha

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


def mode_replace(Ft, Fx):
    """Key MODE rule: trial replaces target only if it dominates it."""
    return U.dominates(Ft, Fx)


class MODE(MOEA):
    name = "MODE"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", Fscale=0.5, CR=0.9, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.Fs, self.CR = Fscale, CR
        self.arc = Archive(100, "crowding")

    def initialize(self):
        super().initialize(); self.arc.add(self.X, self.F, self.CV)

    def trial_vectors(self):
        N, n = self.X.shape; p = self.prob
        R = np.array([self.rng.choice([j for j in range(N) if j != i], 3, replace=False) for i in range(N)])
        V = self.X[R[:, 0]] + self.Fs * (self.X[R[:, 1]] - self.X[R[:, 2]])
        mask = self.rng.random((N, n)) < self.CR; mask[np.arange(N), self.rng.integers(n, size=N)] = True
        return np.clip(np.where(mask, V, self.X), p.lb, p.ub)

    def iterate(self):
        U_ = self.trial_vectors(); Ft, CVt = self.evaluate(U_)
        for i in range(self.N):
            if mode_replace(Ft[i], self.F[i]):
                self.X[i], self.F[i], self.CV[i] = U_[i], Ft[i], CVt[i]
        self.arc.add(U_, Ft, CVt)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


class MOTLBO(MOEA):
    name = "MO-TLBO"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.arc = Archive(100, "crowding"); self.t = 0

    def initialize(self):
        super().initialize(); self.arc.add(self.X, self.F, self.CV)

    def cost(self):
        return 2 * self.N

    def tf(self):
        """Shrinking teaching factor 2 -> 1."""
        return 2.0 - self.t / max(1, self.max_iters)

    def _accept(self, Xn, Fn, CVn):
        for i in range(self.N):
            r = abc_greedy(Fn[i], self.F[i])
            if r == 1 or (r == 0 and self.rng.random() < 0.5):
                self.X[i], self.F[i], self.CV[i] = Xn[i], Fn[i], CVn[i]
        self.arc.add(Xn, Fn, CVn)

    def iterate(self):
        p = self.prob; self.t += 1
        nd = np.where(U.nondominated_mask(self.F))[0]
        teacher = self.X[self.rng.choice(nd)] if len(nd) else self.X[0]
        mean = self.X.mean(0)
        Xn = np.clip(self.X + self.rng.random(self.X.shape) * (teacher - self.tf() * mean), p.lb, p.ub)
        Fn, CVn = self.evaluate(Xn); self._accept(Xn, Fn, CVn)
        j = np.array([self.rng.choice([k for k in range(self.N) if k != i]) for i in range(self.N)])
        better = np.array([U.dominates(self.F[i], self.F[j[i]]) for i in range(self.N)])[:, None]
        r = self.rng.random(self.X.shape)
        Xn = np.where(better, self.X + r * (self.X - self.X[j]), self.X + r * (self.X[j] - self.X))
        Xn = np.clip(Xn, p.lb, p.ub)
        Fn, CVn = self.evaluate(Xn); self._accept(Xn, Fn, CVn)

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


class MOBA(MOEA):
    name = "MOBA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", fmin=0.0, fmax=2.0, alpha=0.97, gamma=0.9, r0=0.5, **kw):
        super().__init__(problem, pop, seed, cmode, **kw)
        self.fmin, self.fmax, self.alpha, self.gamma, self.r0 = fmin, fmax, alpha, gamma, r0
        self.arc = Archive(100, "grid", 20); self.t = 0

    def initialize(self):
        super().initialize(); self.V = np.zeros_like(self.X, float)
        self.A = np.ones(self.N) * 1.0; self.r = np.full(self.N, self.r0 * 0.1)
        self.arc.add(self.X, self.F, self.CV, self.rng)

    def schedules(self):
        """Loudness decreases, pulse rate increases (the two MOBA schedules)."""
        self.A = self.alpha * self.A
        self.r = self.r0 * (1 - np.exp(-self.gamma * self.t))

    def iterate(self):
        p = self.prob; self.t += 1
        best = self.arc.X[self.arc.pick(self.rng, self.N)]
        f = self.fmin + (self.fmax - self.fmin) * self.rng.random((self.N, 1))
        self.V = self.V + (self.X - best) * f
        Xn = np.clip(self.X + self.V, p.lb, p.ub)
        walk = self.rng.random(self.N) > self.r
        Xw = np.clip(best + 0.1 * self.rng.normal(0, 1, self.X.shape) * (p.ub - p.lb) * max(self.A.mean(), 0.02), p.lb, p.ub)
        Xn = np.where(walk[:, None], Xw, Xn)
        Fn, CVn = self.evaluate(Xn)
        for i in range(self.N):
            r = abc_greedy(Fn[i], self.F[i])
            if (r >= 0) and self.rng.random() < self.A[i] and (r == 1 or self.rng.random() < 0.5):
                self.X[i], self.F[i], self.CV[i] = Xn[i], Fn[i], CVn[i]
        self.arc.add(Xn, Fn, CVn, self.rng)
        self.schedules()

    def final_set(self):
        return self.arc.X, self.arc.F, np.zeros(len(self.arc.X))


class MOMA(NSGA2):
    name = "MOMA"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", pls=0.2, steps=3, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.pls, self.steps = pls, steps

    def cost(self):
        return int(self.N + np.ceil(self.pls * self.N) * self.steps + 5)

    def local_search(self, X, F, CV, w=None, L=None):
        """Hill climbing on a random-weight scalarisation for a fraction pls of the offspring."""
        if L is None:
            L = np.where(self.rng.random(len(X)) < self.pls)[0]
        if len(L) == 0:
            return X, F, CV
        if w is None:
            w = self.rng.random((len(L), F.shape[1])); w /= w.sum(1, keepdims=True)
        for _ in range(self.steps):
            Xp = self.ops.mutate(X[L], self.rng); Fp, CVp = self.evaluate(Xp)
            imp = (w * Fp).sum(1) < (w * F[L]).sum(1)
            X[L[imp]], F[L[imp]], CV[L[imp]] = Xp[imp], Fp[imp], CVp[imp]
        return X, F, CV

    def iterate(self):
        rank, crowd = self.rank_crowd(self.F, self.CV)
        idx = self.tournament(rank, crowd, self.N)
        Xo = self.ops.variate(self.X[idx], self.rng)
        Fo, CVo = self.evaluate(Xo)
        Xo, Fo, CVo = self.local_search(Xo, Fo, CVo)
        X = np.concatenate([self.X, Xo]); F = np.concatenate([self.F, Fo]); CV = np.concatenate([self.CV, CVo])
        keep = U.nsga2_survivors(F, self.cvd(CV), self.N)
        self.X, self.F, self.CV = X[keep], F[keep], CV[keep]
