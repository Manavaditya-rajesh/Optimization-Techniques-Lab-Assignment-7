"""Algorithms 8-9: TOPSIS and VIKOR (rankers, not optimisers) + P12 supplier data.

TOPSIS : vector-normalise, weight, ideal/anti-ideal, C_i = D-/(D+ + D-) (higher better).
VIKOR  : f*_j / f^-_j best/worst, S_i = sum w (f*-f)/(f*-f-), R_i = max, Q = v (S-S*)/(S^- - S*) + (1-v)(R-R*)/(R^- - R*)
         (lower Q better); acceptable-advantage check Q(2nd)-Q(1st) >= 1/(m-1).
benefit[j]=True means larger is better.
"""
import numpy as np

SUPPLIERS = ["S1", "S2", "S3", "S4", "S5"]
P12_DATA = np.array([[120, 8, 10, 92], [100, 7, 14, 88], [140, 9, 7, 95], [90, 6, 18, 80], [130, 8, 9, 90]], float)
P12_BENEFIT = np.array([False, True, False, True])
P12_W = np.array([0.3, 0.3, 0.2, 0.2])


def topsis(D, w, benefit):
    D = np.asarray(D, float)
    R = D / np.sqrt((D ** 2).sum(0)); V = R * w
    best = np.where(benefit, V.max(0), V.min(0)); worst = np.where(benefit, V.min(0), V.max(0))
    dp = np.sqrt(((V - best) ** 2).sum(1)); dm = np.sqrt(((V - worst) ** 2).sum(1))
    return dm / (dp + dm), dp, dm


def vikor(D, w, benefit, v=0.5):
    D = np.asarray(D, float)
    fs = np.where(benefit, D.max(0), D.min(0)); fw = np.where(benefit, D.min(0), D.max(0))
    span = np.where(fs == fw, 1.0, fs - fw)
    T = w * (fs - D) / span
    S = T.sum(1); R = T.max(1)
    def nz(a):
        d = a.max() - a.min(); return (a - a.min()) / (d if d > 0 else 1.0)
    Q = v * nz(S) + (1 - v) * nz(R)
    o = np.argsort(Q)
    adv = (Q[o[1]] - Q[o[0]]) >= 1.0 / (len(D) - 1)
    return Q, S, R, bool(adv)
