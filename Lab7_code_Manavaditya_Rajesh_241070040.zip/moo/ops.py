"""Variation operators for real / binary / permutation encodings (hand-written)."""
import numpy as np


def sbx(P1, P2, lb, ub, rng, eta=15.0, pc=0.9):
    N, n = P1.shape
    u = rng.random((N, n))
    beta = np.where(u <= .5, (2 * u) ** (1 / (eta + 1)), (1 / (2 * (1 - u))) ** (1 / (eta + 1)))
    c1 = .5 * ((1 + beta) * P1 + (1 - beta) * P2)
    c2 = .5 * ((1 - beta) * P1 + (1 + beta) * P2)
    m = (rng.random((N, 1)) < pc) & (rng.random((N, n)) < .5)
    c1 = np.where(m, c1, P1); c2 = np.where(m, c2, P2)
    return np.clip(c1, lb, ub), np.clip(c2, lb, ub)


def poly_mut(X, lb, ub, rng, eta=20.0, pm=None):
    N, n = X.shape
    pm = 1.0 / n if pm is None else pm
    u = rng.random((N, n)); mut = rng.random((N, n)) < pm
    span = np.where(ub > lb, ub - lb, 1.0)
    d1 = (X - lb) / span; d2 = (ub - X) / span
    lo = (2 * u + (1 - 2 * u) * (1 - d1) ** (eta + 1)) ** (1 / (eta + 1)) - 1
    hi = 1 - (2 * (1 - u) + 2 * (u - .5) * (1 - d2) ** (eta + 1)) ** (1 / (eta + 1))
    return np.clip(X + mut * np.where(u < .5, lo, hi) * span, lb, ub)


def order_crossover(a, b, rng):
    n = len(a)
    i, j = sorted(rng.choice(n, 2, replace=False))
    child = -np.ones(n, int); child[i:j + 1] = a[i:j + 1]
    used = set(child[i:j + 1].tolist())
    fill = [g for g in np.concatenate([b[j + 1:], b[:j + 1]]) if g not in used]
    pos = [(j + 1 + k) % n for k in range(n - (j - i + 1))]
    for p, g in zip(pos, fill):
        child[p] = g
    return child


def inversion_swap_mut(t, rng, pm=0.3):
    t = t.copy(); n = len(t)
    if rng.random() < pm:
        if rng.random() < .5:
            i, j = sorted(rng.choice(n, 2, replace=False)); t[i:j + 1] = t[i:j + 1][::-1]
        else:
            i, j = rng.choice(n, 2, replace=False); t[i], t[j] = t[j], t[i]
    return t


class RealOps:
    kind = "real"

    def __init__(self, p, eta_c=15.0, eta_m=20.0, pc=0.9):
        self.lb, self.ub, self.n = p.lb, p.ub, p.n_var; self.eta_c, self.eta_m, self.pc = eta_c, eta_m, pc

    def init(self, N, rng):
        return self.lb + rng.random((N, self.n)) * (self.ub - self.lb)

    def variate(self, P, rng):
        """P holds parents; consecutive rows are mated -> same number of offspring."""
        N = len(P)
        if N % 2:
            P = np.vstack([P, P[:1]])
        c1, c2 = sbx(P[0::2], P[1::2], self.lb, self.ub, rng, self.eta_c, self.pc)
        C = np.empty((len(P), self.n)); C[0::2] = c1; C[1::2] = c2
        return poly_mut(C, self.lb, self.ub, rng, self.eta_m)[:N]

    def mutate(self, X, rng, scale=None):
        return poly_mut(X, self.lb, self.ub, rng, self.eta_m)


class BinOps:
    kind = "binary"

    def __init__(self, p):
        self.n = p.n_var

    def init(self, N, rng):
        X = (rng.random((N, self.n)) < .5).astype(int)
        X[X.sum(1) == 0, rng.integers(self.n)] = 1
        return X

    def variate(self, P, rng):
        N = len(P)
        if N % 2:
            P = np.vstack([P, P[:1]])
        a, b = P[0::2], P[1::2]
        m = rng.random(a.shape) < .5
        C = np.empty_like(P); C[0::2] = np.where(m, a, b); C[1::2] = np.where(m, b, a)
        return self.mutate(C, rng)[:N]

    def mutate(self, X, rng, scale=None):
        flip = rng.random(X.shape) < 1.0 / self.n
        Y = np.where(flip, 1 - X, X)
        Y[Y.sum(1) == 0, rng.integers(self.n)] = 1
        return Y


class PermOps:
    kind = "perm"

    def __init__(self, p):
        self.n = p.n_var

    def init(self, N, rng):
        return np.array([rng.permutation(self.n) for _ in range(N)])

    def variate(self, P, rng):
        N = len(P)
        if N % 2:
            P = np.vstack([P, P[:1]])
        C = np.empty_like(P)
        for k in range(0, len(P), 2):
            C[k] = order_crossover(P[k], P[k + 1], rng)
            C[k + 1] = order_crossover(P[k + 1], P[k], rng)
        return self.mutate(C, rng)[:N]

    def mutate(self, X, rng, scale=None):
        return np.array([inversion_swap_mut(t, rng) for t in X])


def make_ops(p):
    return {"real": RealOps, "binary": BinOps, "perm": PermOps}[p.kind](p)
