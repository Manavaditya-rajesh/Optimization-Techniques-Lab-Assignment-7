"""Algorithms 18-20: MOEA/D, MOEA/D-DE, MOEA/D-ACO.

MOEA/D (Zhang & Li 2007): 1 N weight vectors (uniform / Das-Dennis) + T nearest neighbours B(i)
2 population x_i per sub-problem, ideal point z* 3 for each i: pick 2 parents from B(i) (prob delta) or whole
population, SBX+mutation -> y, update z*, replace up to nr neighbours j with g_te(y|w_j) <= g_te(x_j|w_j)
(Tchebycheff g = max_i w_i |f_i - z_i|).  Defaults N=100(2-obj), T=20, delta=0.9, nr=2.
MOEA/D-DE (Li & Zhang 2009): same but DE/rand/1 (F=0.5, CR=1) + polynomial mutation to make y.
MOEA/D-ACO (Ke, Zhang, Battiti 2013): each sub-problem owns a pheromone matrix; an ant builds a tour with
p_ij ~ tau^alpha * eta_lambda^beta, eta_lambda = (1/d)^l1 * (1/t)^l2; neighbour replacement as in MOEA/D;
pheromone of sub-problem i is evaporated and reinforced by its current solution.
"""
import numpy as np
from . import moo_utils as U
from .base import MOEA


def weights_for(M, N):
    if M == 2:
        w = np.linspace(0, 1, N); return np.c_[w, 1 - w]
    H = 1
    while True:
        W = U.das_dennis(M, H)
        if len(W) >= N or H > 60:
            return W
        H += 1


def tcheb(F, W, z):
    return (np.maximum(W, 1e-6) * np.abs(F - z)).max(-1)


class MOEAD(MOEA):
    name = "MOEA/D"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", T=20, delta=0.9, nr=2, H=None, **kw):
        W = U.das_dennis(problem.n_obj, H) if H else weights_for(problem.n_obj, pop)
        super().__init__(problem, len(W), seed, cmode, **kw)
        self.W = W; self.T = min(T, len(W)); self.delta = delta; self.nr = nr
        d = np.sqrt(((W[:, None] - W[None]) ** 2).sum(2))
        self.B = np.argsort(d, axis=1)[:, :self.T]

    def initialize(self):
        super().initialize(); self.z = self.F.min(0).copy()

    def make_child(self, i, pool):
        a, b = self.rng.choice(pool, 2, replace=False) if len(pool) > 1 else (pool[0], pool[0])
        return self.ops.variate(np.vstack([self.X[a], self.X[b]]), self.rng)[:1]

    def iterate(self):
        for i in self.rng.permutation(self.N):
            pool = self.B[i] if self.rng.random() < self.delta else np.arange(self.N)
            y = self.make_child(i, pool)
            Fy, CVy = self.evaluate(y)
            self.z = np.minimum(self.z, Fy[0])
            gy = tcheb(Fy[0], self.W[pool], self.z); go = tcheb(self.F[pool], self.W[pool], self.z)
            better = np.where(gy <= go)[0]
            if len(better):
                sel = self.rng.permutation(better)[:self.nr]
                for s in sel:
                    j = pool[s]; self.X[j] = y[0]; self.F[j] = Fy[0]; self.CV[j] = CVy[0]


class MOEADDE(MOEAD):
    name = "MOEA/D-DE"

    def __init__(self, problem, pop=100, seed=0, cmode="penalty", Fscale=0.5, CR=1.0, **kw):
        super().__init__(problem, pop, seed, cmode, **kw); self.Fs = Fscale; self.CR = CR

    def make_child(self, i, pool):
        r = self.rng.choice(pool, 3, replace=len(pool) < 3)
        x, p = self.X[i], self.prob
        v = self.X[r[0]] + self.Fs * (self.X[r[1]] - self.X[r[2]])
        mask = (self.rng.random(len(x)) < self.CR); mask[self.rng.integers(len(x))] = True
        u = np.where(mask, v, x)
        u = np.clip(u, p.lb, p.ub)[None, :]
        return self.ops.mutate(u, self.rng)


class MOEADACO(MOEA):
    name = "MOEA/D-ACO"

    def __init__(self, problem, pop=20, seed=0, cmode="penalty", T=5, alpha=1.0, beta=2.0, rho=0.1, nr=2, **kw):
        W = weights_for(2, pop)
        super().__init__(problem, len(W), seed, cmode, **kw)
        self.W = W; self.T = T; self.alpha, self.beta, self.rho, self.nr = alpha, beta, rho, nr
        d = np.sqrt(((W[:, None] - W[None]) ** 2).sum(2)); self.B = np.argsort(d, axis=1)[:, :T]
        n = problem.n_var; self.n = n
        self.tau = np.ones((self.N, n, n)); self.tmin, self.tmax = 0.01, 5.0
        self.eta1 = 1.0 / (problem.D + np.eye(n)); self.eta2 = 1.0 / (problem.T + np.eye(n))

    def initialize(self):
        super().initialize(); self.z = self.F.min(0).copy()

    def construct(self, i):
        lam = self.W[i]
        eta = (self.eta1 ** lam[0]) * (self.eta2 ** lam[1])
        tau = self.tau[i]
        cur = int(self.rng.integers(self.n)); tour = [cur]; vis = np.zeros(self.n, bool); vis[cur] = True
        for _ in range(self.n - 1):
            w = (tau[cur] ** self.alpha) * (eta[cur] ** self.beta); w[vis] = 0
            nxt = int(self.rng.choice(self.n, p=w / w.sum()))
            tour.append(nxt); vis[nxt] = True; cur = nxt
        return np.array(tour)

    def deposit(self, i, tour, amount):
        nx = np.roll(tour, -1)
        self.tau[i] *= (1 - self.rho)
        self.tau[i][tour, nx] += amount; self.tau[i][nx, tour] += amount
        np.clip(self.tau[i], self.tmin, self.tmax, out=self.tau[i])

    def iterate(self):
        for i in range(self.N):
            tour = self.construct(i)
            F, CV = self.evaluate(tour[None, :])
            self.z = np.minimum(self.z, F[0])
            nb = self.B[i]
            gy = tcheb(F[0], self.W[nb], self.z); go = tcheb(self.F[nb], self.W[nb], self.z)
            better = np.where(gy <= go)[0]
            for s in self.rng.permutation(better)[:self.nr]:
                j = nb[s]; self.X[j] = tour; self.F[j] = F[0]
                self.deposit(j, tour, 1.0 / (1.0 + gy[s]) * self.rho * 10)
            # reinforce own current solution
            self.deposit(i, self.X[i], 0.5 * self.rho)
