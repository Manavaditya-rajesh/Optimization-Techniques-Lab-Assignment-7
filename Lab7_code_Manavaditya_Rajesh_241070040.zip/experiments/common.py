"""Registry of the 37 algorithms, problem factory, metric helpers and plotting helpers."""
import sys, os, time, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from moo import moo_utils as U, problems as P
from moo.a01_classical import *
from moo.a10_noneelitist import *
from moo.a14_elitist import *
from moo.a18_decomposition import *
from moo.a22_swarm import *
from moo.a26_misc import *
from moo.a31_indicator import *

OUT = os.path.join(ROOT, "outputs"); FIG = os.path.join(OUT, "figures"); DAT = os.path.join(OUT, "data")
for d in (FIG, DAT):
    os.makedirs(d, exist_ok=True)

NAMES = {1: "Weighted Sum", 2: "eps-Constraint", 3: "Benson's Method", 4: "Weight Metric (p-norm, Tchebycheff)", 5: "Value Function",
         6: "Goal Programming", 7: "Lexicographic", 8: "TOPSIS", 9: "VIKOR", 10: "VEGA", 11: "MOGA", 12: "NSGA", 13: "NPGA",
         14: "NSGA-II", 15: "NSGA-III", 16: "SPEA2", 17: "PESA-II", 18: "MOEA/D", 19: "MOEA/D-DE", 20: "MOEA/D-ACO",
         21: "Constrained NSGA-II", 22: "MOPSO", 23: "MOGWO", 24: "MOABC", 25: "MOACO", 26: "MOSA", 27: "MODE", 28: "MO-TLBO",
         29: "MOBA", 30: "MOMA", 31: "RVEA", 32: "IBEA", 33: "SMS-EMOA", 34: "HypE", 35: "R-NSGA-II", 36: "MGDA", 37: "GradNorm"}
POP = {10: VEGA, 11: MOGA, 12: NSGA, 13: NPGA, 14: NSGA2, 15: NSGA3, 16: SPEA2, 17: PESA2, 18: MOEAD, 19: MOEADDE, 20: MOEADACO,
       21: ConstrainedNSGA2, 22: MOPSO, 23: MOGWO, 24: MOABC, 25: MOACO, 26: MOSA, 27: MODE, 28: MOTLBO, 29: MOBA, 30: MOMA,
       31: RVEA, 32: IBEA, 33: SMSEMOA, 34: HypE, 35: RNSGA2}
NATIVE = {14: ("perm", "binary"), 30: ("perm", "binary"), 20: ("perm",), 25: ("perm",)}
TEST = {1: ["P1", "P3", "P4"], 2: ["P2", "P3", "P5"], 3: ["P1", "P7"], 4: ["P1", "P3"], 5: ["P4", "P14"], 6: ["P11", "P7"], 7: ["P11", "P7"],
        8: ["P12", "P4"], 9: ["P12", "P4"], 10: ["P2", "P3"], 11: ["P3", "P5"], 12: ["P5", "P7"], 13: ["P3", "P5"], 14: ["P3", "P5", "P6"],
        15: ["P10_3", "P10_5"], 16: ["P4", "P5"], 17: ["P3", "P5"], 18: ["P3", "P10_3"], 19: ["P3", "P5"], 20: ["P8"], 21: ["P5", "P6", "P7"],
        22: ["P4", "P5"], 23: ["P5", "P9"], 24: ["P3", "P6"], 25: ["P8"], 26: ["P3", "P5"], 27: ["P3", "P5"], 28: ["P3", "P5"],
        29: ["P3", "P4"], 30: ["P5", "P9"], 31: ["P10_3"], 32: ["P3", "P14"], 33: ["P3", "P14"], 34: ["P10_3"], 35: ["P5", "P14"],
        36: ["P13"], 37: ["P13"]}
_cache = {}


def mkprob(key):
    if key in _cache:
        return _cache[key]
    f = {"P1": P.P1, "P2": P.P2, "P2i": lambda: P.P2(True), "P3": P.P3, "P4": P.P4, "P4p": lambda: P.P4("penalty"), "P5": P.P5, "P6": P.P6,
         "P7": P.P7, "P8": P.P8, "P9": P.P9, "P10_3": lambda: P.P10(3), "P10_5": lambda: P.P10(5), "P14": P.P14}[key]
    _cache[key] = f()
    return _cache[key]


def run_pop(aid, key, seed=1, evals=10000, **kw):
    """Run population algorithm aid on problem key. Returns (X, Fn(normalised), seconds, nfe)."""
    p = mkprob(key)
    if p.kind != "real" and p.kind not in ("perm", "binary") or (p.kind != "real" and p.kind not in NATIVE.get(aid, ())):
        p = P.RealWrap(p)
    if p.kind == "binary" and aid in (30, 14):
        pass
    if key == "P9":
        evals = min(evals, 1500)
    args = dict(kw)
    if aid == 35 and "refs" not in args and p.pref_point is None:
        args["refs"] = np.array([[0.236, 0.057]])           # P5: DM wants ~40 kg and ~1 mm
    if aid in (15, 31, 34, 18, 19) and key.startswith("P10"):
        H = 12 if key == "P10_3" else 4
        if aid in (15, 31, 18):
            args["H"] = H
        if aid == 15:
            args["pop"] = 92 if key == "P10_3" else 70
        if aid in (31, 18):
            args.pop("pop", None)
        if aid == 34:
            args.setdefault("pop", 91 if key == "P10_3" else 70); args.setdefault("S", 2000)
    if key == "P10_5":
        args.setdefault("pop", 70)
        if aid == 14: args["pop"] = 70
    a = POP[aid](p, seed=seed, **args)
    t = time.time(); X, F = a.run(evals)
    return X, F, time.time() - t, a.nfe


def metrics(key, F):
    p = mkprob(key)
    F = np.asarray(F)
    tf = p.true_front()
    m = {"n": int(len(F)), "HV": float(U.hypervolume(F, p.ref_hv)) if len(F) else 0.0, "SP": float(U.spacing(F))}
    m["IGD"] = float(U.igd(p.norm(tf), F)) if tf is not None and len(F) else None
    return m


def ref_hv_true(key):
    p = mkprob(key); tf = p.true_front()
    return float(U.hypervolume(p.norm(tf), p.ref_hv)) if tf is not None else None


# ------------------------------------------------------------- classical sweeps -> normalised fronts
def classical_front(aid, key, **kw):
    p = mkprob(key)
    if aid == 1:
        r = weighted_sum(p, n_w=kw.get("n", 21)); F = [f for _, _, f in r]
    elif aid == 2:
        r = eps_constraint(p, n_eps=kw.get("n", 21)); F = [f for _, _, f in r]
    elif aid == 3:
        n = kw.get("n", 15); zs = [np.array([t, 1 - t]) + 0.02 for t in np.linspace(0, 1, n)]
        w = (1.0, 0.7) if key == "P7" else (1.0, 1.0)
        r = benson(p, zs, w=w); F = [f for _, _, f, _ in r]
    elif aid == 4:
        r = weight_metric(p, n_w=kw.get("n", 21), pnorm=kw.get("pnorm", np.inf)); F = [f for _, _, f in r]
    F = np.array(F) if len(F) else np.zeros((0, p.n_obj))
    m = U.nondominated_mask(F) if len(F) else np.zeros(0, bool)
    return F[m] if len(F) else F


def plot_front(ax, key, F, label=None, true=True, color="C0"):
    p = mkprob(key)
    if key == "P9":
        ax.scatter(p.denorm(F)[:, 1], p.denorm(F)[:, 0], s=14, c=color, label=label); ax.set_xlabel("# features"); ax.set_ylabel("CV error")
        return
    R = p.denorm(F) if len(F) else F
    if p.n_obj == 2:
        if true and p.true_front() is not None:
            tf = p.true_front(); o = np.argsort(tf[:, 0]); ax.plot(tf[o, 0], tf[o, 1], "k-", lw=1, label="true front")
        ax.scatter(R[:, 0], R[:, 1], s=12, c=color, label=label); ax.set_xlabel("f1 (min form)"); ax.set_ylabel("f2 (min form)")
    else:
        tf = p.true_front()
        ax.scatter(tf[:, 0], tf[:, 1], s=3, c="lightgray", label="true front")
        ax.scatter(R[:, 0], R[:, 1], s=12, c=color, label=label); ax.set_xlabel("f1"); ax.set_ylabel("f2 (projection)")
