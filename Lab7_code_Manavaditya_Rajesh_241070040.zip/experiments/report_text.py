"""Static text for the report: Task B master table rows (tokens [[...]] are filled from my own result files), study cards, viva answers."""

# token syntax: [[A:aid:key:METRIC]]  (Task A, seed 1)  [[D1:key:aid:METRIC]] (10-seed mean+-std)  [[D2:aid:METRIC]] [[D3:aid:METRIC]] [[TRUE:key]] [[X:path]] (extras/Task C json)
ROWS = {}
def R(aid, family, what, adv, dis, best, avoid): ROWS[aid] = dict(family=family, what=what, adv=adv, dis=dis, best=best, avoid=avoid)

R(1, "Classical", "Scalarise F by sum_i w_i f~_i, solve the single-objective problem (SLSQP, 6 random starts) and repeat for 21 weights in [0,1].",
  ["Cheapest scheme: one smooth single-objective solve per point (about 0.3-0.7 s for the whole 21-weight sweep on P1/P4, Fig. A-01).",
   "On the convex P1 front all 21 weights give 21 different Pareto points, IGD [[A:1:P1:IGD]] (Fig. A-01).",
   "Any gradient solver can be reused; constraints (equality on P4) are passed straight to the solver; scales to many variables.",
   "The only parameter, the weight, has an intuitive meaning (relative importance); the obtained points are provably Pareto-optimal on convex fronts."],
  ["Cannot reach a non-convex front: only [[A:1:P3:n]] points on ZDT2, HV [[A:1:P3:HV]] against [[TRUE:P3]] for the true front (Fig. A-01).",
   "Equal weight steps do not give equal spacing: nearest-point steps on P1 range from [[X:P1:ws_step_min_max]] (normalised units); on P4 Spacing is [[A:1:P4:SP]], the worst of the P4 methods.",
   "Each solve gives one point and gradient solvers can stop in local optima on multimodal problems.",
   "Needs normalised objectives and a sensible weight grid; a priori weights hide the shape of the trade-off."],
  "Convex, smooth, cheap-to-evaluate problems with a gradient solver at hand (P1, P4).", "Non-convex or disconnected fronts (ZDT2/P3), discrete or noisy objectives.")

R(2, "Classical", "Minimise one objective f1 and turn the others into constraints f2 <= eps; sweep 21 eps values between the ideal and nadir values.",
  ["Reaches non-convex fronts: HV [[A:2:P3:HV]] on P3, where weighted sum finds 2 points (Fig. A-02).",
   "Handles the constrained P5 and returns [[A:2:P5:n]] feasible points covering the whole range of the front (Fig. A-02).",
   "eps has a direct physical meaning (an acceptable deflection, delay or cost bound).",
   "Every solution is Pareto-optimal provided the constraint is active, and the front can be sampled as densely as wished."],
  ["Equal eps steps give uneven points: Spacing [[A:2:P5:SP]] and IGD [[A:2:P5:IGD]] on P5, [[A:2:P2:SP]] on P2 (Fig. A-02).",
   "Sub-problems with a tight eps can be infeasible; the nadir must be known to choose the eps range.",
   "Needs a constrained solver (SLSQP with multi-start here); cost grows as (points)^(M-1) for M objectives.",
   "A bad eps range wastes solves on dominated/infeasible settings."],
  "Bi-objective problems where one objective has a natural bound (budget, deflection limit); non-convex fronts.", "Many objectives (grid of eps explodes); problems whose feasibility for a given eps is hard to find.")

R(3, "Classical", "For a reference point z that some feasible point improves on, maximise sum w_i l_i subject to f_i(x) + l_i = z_i, l_i >= 0.",
  ["Result is Pareto-optimal and dominates z by construction: l = z - f(x), checked in the hand trace of Task C (x = 5 and x = 4.414).",
   "With a tight but attainable z it reaches the dented middle of ZDT2: 5 mid-front points at offset 0.2 (Fig. C-1, Task C).",
   "z is an intuitive input (a current design to be improved); also usable as a Pareto-optimality test of any given point.",
   "Provides the improvement vector l, a measure of how much each objective can be bettered."],
  ["Needs an attainable z: for z = (t, 1-t)+0.02 the sub-problem was infeasible for mid-front t on ZDT2, leaving only 2 points (Fig. C-1).",
   "If z lies beyond the nadir the constraints are inactive and it reduces to weighted sum (extreme points only for offset 0.6, Fig. C-1).",
   "On P7 (linear front) equal weights give a degenerate tie along the front; unequal weights were needed: HV [[A:3:P7:HV]], Spacing [[A:3:P7:SP]].",
   "Extra l variables and equality constraints per solve; sweep of z and w required to build a front."],
  "Improving an existing design or screening a candidate for Pareto optimality.", "When no feasible reference point is known or for large objective counts.")

R(4, "Classical", "Minimise (sum w_i |f~_i|^p)^(1/p) (distance to the ideal point) for p = 1, 2 and infinity (Tchebycheff via an epigraph variable t).",
  ["p = infinity reaches the concave front: HV [[A:4:P3:HV]], IGD [[A:4:P3:IGD]] on ZDT2, where p = 1 finds only end points (Fig. A-04).",
   "On P1 the p = 2 and p = infinity metrics return 21 distinct Pareto points; p = 1 reproduces weighted sum ([[X:P1:p1]] distinct).",
   "Unified family: p controls the convexity assumption; Tchebycheff solutions are weakly Pareto optimal for every front shape.",
   "Weights keep their meaning of relative importance."],
  ["Spacing is uneven: Spacing for p = 1, 2, inf on P1 is 0.0080 / 0.0300 / 0.0335, so equal weight steps cluster points near the middle.",
   "The Tchebycheff non-smooth max needs an epigraph reformulation with extra variable and constraints.",
   "Requires the ideal point (a pre-solve of every objective) and normalisation.",
   "Only weak Pareto-optimality is guaranteed for p = infinity; one solve per point."],
  "Bi-objective problems where the front may be non-convex and a gradient solver is available.", "Black-box problems without a solver or with expensive solves per weight.")

R(5, "Classical", "Maximise the decision maker's utility V(f~) = prod (1.05 - f~_i)^a_i; different exponents a model different profiles.",
  ["Returns one preferred solution per profile (3 investor profiles on P4, 3 laptop profiles on P14, Fig. A-05) - no front needed.",
   "Solutions lie on the Pareto front (all profile points sit on the plotted front, Fig. A-05).",
   "Encodes trade-off attitude (risk-averse vs return-seeking) directly, so the analyst gets an answer, not a menu.",
   "Cheap: one single-objective solve per profile."],
  ["Needs a utility function; a wrong V gives a confidently wrong answer (a=(2,1) vs (1,2) moves P4 from the safe to the risky end).",
   "Does not show the alternatives, so the decision maker cannot learn the trade-off.",
   "Utility elicitation is hard and non-unique; exponents are not comparable across people.",
   "Non-convex utilities may need multi-start (6 starts used)."],
  "A single decision maker whose preferences are known (investor profiles on P4, laptop on P14).", "Exploratory design where preferences are unknown or several stakeholders disagree.")

R(6, "Classical", "Targets T_i with deviation variables d-, d+: f_i + d-_i - d+_i = T_i, minimise weighted unwanted deviations (LP).",
  ["Handles unreachable targets gracefully: P11 units goal leaves exactly the minimum shortfall 100 at x = (300, 200), profit goal met (Fig. A-06).",
   "Unreachable targets still give a sensible compromise: on P7 an unreachable goal (60,110) returns (10,80) with deviations (52,14), the minimum total (Fig. A-06).",
   "For linear problems it is an LP: exact, fast, no tuning.",
   "Targets are natural for managers (profit >= 2400, units >= 600)."],
  ["Answer depends entirely on the targets: on P7 a reachable goal (32, 60) is hit exactly (40, 50) while an unreachable one gives a different compromise.",
   "Returns a single compromise, not a front; weights decide which goal is sacrificed.",
   "On P11 unit weights, 1/target weights and a 10x priority on units all return the same x = (300,200) (only the objective value changes: 100, 0.167, 1000), so the solution is insensitive but the objective value is not comparable between weightings.",
   "Poorly set goals can return a dominated solution if only one-sided deviations are penalised wrongly."],
  "Linear/convex planning with explicit targets (P11, P7).", "When targets are unknown or the real aim is the full trade-off curve.")

R(7, "Classical", "Solve objective 1, fix it (within a tolerance), solve objective 2 under that restriction, and so on.",
  ["P11: profit first gives 2400 on a whole edge, second priority then selects (300, 200) with 500 units (Fig. A-07).",
   "Priority order changes the answer clearly on P7: yield first gives (70, 20), industry first gives (10, 80) (Fig. A-07).",
   "No weights needed, only a priority order; LP solves are exact.",
   "Transparent and easy to explain to managers."],
  ["Strict priority means lower objectives matter only for ties: the second priority is irrelevant unless profit has ties, as in P11.",
   "Sensitive to the tolerance: on P7 a 10% tolerance on yield moves the answer from (70, 20) to (63, 27); on P11 tol 0 and 5% gave the same point.",
   "Gives one solution, no trade-off information.",
   "Needs a total order of objectives, which may not exist."],
  "Clear priorities and ties in the first objective (P11).", "Objectives of similar importance.")

R(8, "Ranking / MCDM", "Vector-normalise the matrix, weight, compute distance to the ideal and anti-ideal point, rank by C = D-/(D+ + D-).",
  ["Ranks the 5 suppliers in one pass without optimisation: S3 > S1 > S5 > S2 > S4 (Fig. A-08).",
   "Applied to the NSGA-II front of P4 it names the top three portfolios instantly (JSON).",
   "No parameters except the weights; handles benefit and cost criteria.",
   "Zero cost - O(m n)."],
  ["A 0.1 weight shift between cost and quality swaps S1 and S5 (rank flip, Task A/P12).",
   "Compensatory: in a toy case (10,10,10,1) vs (6,6,6,6) TOPSIS gives 0.577 vs 0.598, so one terrible criterion is only mildly punished (Task D4).",
   "Rank reversal can occur when alternatives are added or removed.",
   "It is a ranker, not an optimiser: it needs the candidate set."],
  "Choosing among a short list of alternatives (P12, picking from a front).", "When one criterion must not be allowed to be very bad.")

R(9, "Ranking / MCDM", "Compute S (weighted sum of regrets), R (max regret) and Q = v*S~ + (1-v)*R~; rank by Q, check acceptable advantage.",
  ["Parameter v moves between group utility and individual regret: ranks S1,S2,S5,S3,S4 for v = 0.25/0.5 and S1,S3,S2,S5,S4 for v = 0.75 (Fig. A-09).",
   "Protects against one very bad criterion: in the toy case (10,10,10,1) vs (6,6,6,6) VIKOR with v = 0 gives Q = 1 vs 0, i.e. the balanced alternative wins decisively, while v = 1 reverses it (Task D4).",
   "Acceptable-advantage test says if the winner is clearly better.",
   "Cheap and transparent."],
  ["The ranking changes with v (S3 moves from 4th to 2nd), so v is a hidden decision.",
   "The advantage test often fails on small data sets, then only a compromise set is returned.",
   "Min-max normalisation is sensitive to outliers.",
   "Not an optimiser."],
  "Compromise decisions where a single bad criterion is unacceptable.", "Large candidate sets with many near ties.")

R(10, "Non-elitist EA", "Population split into M sub-populations of size N/M, sub-population m selected only on objective m; shuffle, SBX, mutation.",
  ["Extremely cheap: the 10,000-evaluation run takes [[A:10:P2:time]] s (Fig. A-10).",
   "Needs no dominance computation and no diversity parameter.",
   "Finds extreme (single-objective-best) solutions quickly; on the convex-like P2 it kept [[A:10:P2:n]] points, HV [[A:10:P2:HV]].",
   "Very simple to implement."],
  ["Collapsed to [[A:10:P3:n]] point on ZDT2, HV [[A:10:P3:HV]]: speciation towards the extremes (Fig. A-10, A-HV history E-2).",
   "Misses middle trade-offs: sub-populations favour extremes ('speciation').",
   "No elitism: the final front is only the last population.",
   "No diversity mechanism, so spacing is poor ([[A:10:P2:SP]] on P2)."],
  "Quick demonstration or when only the extremes matter.", "Concave fronts or any task needing evenly spread compromises.")

R(11, "Non-elitist EA", "Rank = 1 + number of dominators, linear rank-to-fitness map, fitness sharing (sigma 0.1) inside each rank, roulette selection.",
  ["Pareto-based: finds interior points (HV [[A:11:P5:HV]] on P5, Fig. A-11).",
   "Sharing keeps a spread: [[A:11:P3:n]] distinct points on ZDT2.",
   "Rank definition is simple; no gradient needed.",
   "Works with any encoding."],
  ["Poorer than elitist methods on ZDT2: HV [[A:11:P3:HV]] and IGD [[A:11:P3:IGD]] vs NSGA-II [[A:14:P3:HV]] / [[A:14:P3:IGD]] (Fig. A-11).",
   "No elitism: good solutions can be lost between generations.",
   "sigma_share must be tuned; sharing costs O(N^2) per rank.",
   "Rank-based selection pressure is weak early on."],
  "Historical baseline, small low-dimensional problems.", "Production use; prefer NSGA-II/SPEA2.")

R(12, "Non-elitist EA", "Non-dominated sorting into fronts, dummy fitness reduced by niche sharing within each front, roulette selection.",
  ["Front-wise dummy fitness gives good convergence on P5: HV [[A:12:P5:HV]], IGD [[A:12:P5:IGD]] (Fig. A-12).",
   "Sharing inside a front keeps diversity: [[A:12:P5:n]] points.",
   "Pure dominance - no weights.",
   "Easy to program."],
  ["O(M N^3) sorting and the need for sigma_share make it slower and tuning-dependent.",
   "Lost solutions (no elitism): P7 front has only [[A:12:P7:n]] points, HV [[A:12:P7:HV]] vs [[A:21:P7:HV]] for Constrained NSGA-II (Fig. A-12).",
   "Sharing in objective space needs normalised objectives and sigma.",
   "Superseded by NSGA-II (which fixed exactly these three flaws)."],
  "Teaching the origin of NSGA-II.", "Anything where NSGA-II is available.")

R(13, "Non-elitist EA", "Binary tournament where each of two candidates is compared against a random comparison set (10% of N); niche count breaks ties.",
  ["No global ranking needed, selection cost is O(t_dom) per tournament, scales to big populations.",
   "Constrained P5 handled well: HV [[A:13:P5:HV]], [[A:13:P5:n]] points (Fig. A-13).",
   "Tournament pressure tuned by t_dom.",
   "No fitness assignment step."],
  ["Failed on ZDT2: [[A:13:P3:n]] points, HV [[A:13:P3:HV]], IGD [[A:13:P3:IGD]] (Fig. A-13).",
   "Result depends strongly on t_dom and sigma_share (two parameters).",
   "Not elitist; ties resolved by sharing which needs distance in objective space.",
   "Slow in Python: [[A:13:P3:time]] s versus 0.3 s for NSGA-II."],
  "Very large populations where full sorting is expensive.", "Small populations; tough non-convex benchmarks.")

R(14, "Elitist EA", "Fast non-dominated sorting + crowding distance; parent+offspring union, best N survive (elitism).",
  ["Elitism: HV of the non-dominated set never decreased (unit test 14); ZDT2 HV [[D1:P3:14:HV]] over 10 seeds (Fig. D1-P3).",
   "Evenly spread bi-objective fronts: Spacing [[A:14:P3:SP]] on P3 and [[A:14:P6:SP]] on P6 (Fig. A-14).",
   "Few parameters (pc, pm, eta); runs in [[A:14:P3:time]] s for 10,000 evaluations.",
   "Works with real, binary and permutation encodings (used on P8, P9)."],
  ["Constraints: without feasibility rules P5 gives Spacing [[A:14:P5:SP]] and [[A:14:P5:n]] points against Constrained NSGA-II [[A:21:P5:SP]] / [[A:21:P5:n]] (Fig. A-14).",
   "Many objectives: on DTLZ2 M=5 IGD [[D2:14:IGD]] vs NSGA-III [[D2:15:IGD]] (Fig. D2).",
   "Crowding distance is a weak diversity measure in 3+ objectives.",
   "O(M N^2) per generation."],
  "Bi-objective problems, mixed encodings, strong default.", "More than 3 objectives; tight constraints unless Deb's rules are switched on.")

R(15, "Elitist EA (many-objective)", "NSGA-II with crowding replaced by Das-Dennis reference points: normalisation by ideal/intercepts, perpendicular association, niche-count filling.",
  ["On 5 objectives it keeps all [[D2:15:n]] population members spread and far outperforms NSGA-II: HV [[D2:15:HV]] vs [[D2:14:HV]], IGD [[D2:15:IGD]] vs [[D2:14:IGD]] (Fig. D2).",
   "Uniform, user-controlled spread: one solution per reference line ([[A:15:P10_3:n]] points for M=3).",
   "Hand trace in Task C shows exactly which points survive and why.",
   "Reference points can be redefined for preference regions."],
  ["Number of divisions sets the population: H = 4/8/12 gave IGD [[X:nsga3_sens:4:IGD]] / [[X:nsga3_sens:8:IGD]] / [[X:nsga3_sens:12:IGD]] (Fig. C-2).",
   "Needs intercept normalisation, fails on degenerate or disconnected fronts (empty niches wasted).",
   "Huge reference sets for many objectives (C(M+H-1,H)).",
   "Slower than NSGA-II per generation (association and niching)."],
  "3-15 objectives with a regular front.", "Irregular/degenerate fronts; two objectives.")

R(16, "Elitist EA", "Strength S, raw fitness R = sum of strengths of dominators, density 1/(sigma_k + 2), fixed-size archive truncated by nearest-neighbour distance.",
  ["Very even fronts: Spacing [[A:16:P4:SP]] on P4 and [[A:16:P5:SP]] on P5 (among the best in Task A, Fig. A-16), IGD [[A:16:P4:IGD]] on P4.",
   "Fine-grained fitness distinguishes dominated individuals too.",
   "Archive truncation preserves boundary points.",
   "Archive of fixed size, elitist."],
  ["Slow: [[A:16:P5:time]] s per run vs 0.3 s for NSGA-II (O((N+Nbar)^2) distance work, Fig. A-16).",
   "k-th neighbour density gets weak in many objectives.",
   "Truncation is O(n^3) in worst case.",
   "Archive size and population size are two parameters to match."],
  "When evenness of the front matters (portfolios, P4).", "Tight wall-clock budgets or many objectives.")

R(17, "Elitist EA", "Archive divided in hyper-grid boxes; select by box (less crowded wins), small internal population (20), archive 100.",
  ["Best front quality among classic EAs on ZDT2: IGD [[A:17:P3:IGD]], HV [[A:17:P3:HV]] (Fig. A-17).",
   "Region-based selection is cheap (cost in boxes, not individuals).",
   "Small population = many generations for the same budget.",
   "Grid gives a cheap density estimate."],
  ["Grid resolution (divs = 10) must be set; too fine/too coarse changes diversity.",
   "On P5 Spacing [[A:17:P5:SP]] is less even than SPEA2 [[A:16:P5:SP]] (Fig. A-17).",
   "Archive bounds adapt each generation, so box indices shift.",
   "Number of boxes grows exponentially with M."],
  "Bi-objective problems with expensive evaluations (small internal population).", "Many objectives.")

R(18, "Decomposition", "N scalar Tchebycheff sub-problems with weight vectors, each solved cooperatively with its T nearest neighbours.",
  ["Cheap per generation: no sorting, [[A:18:P3:time]] s; HV [[A:18:P3:HV]], IGD [[A:18:P3:IGD]] on ZDT2.",
   "Scales better with objectives than NSGA-II: DTLZ2 M=3 IGD [[A:18:P10_3:IGD]] (Fig. A-18); M=5 HV [[D2:18:HV]] vs NSGA-II [[D2:14:HV]].",
   "Good spacing on regular fronts by construction of weights.",
   "Easy to inject preferences with weights."],
  ["Needs a weight set and normalisation; on M=5 only [[D2:18:n]] of 70 sub-problems end with distinct points (Fig. D2).",
   "Poor on irregular fronts because weights do not match front geometry.",
   "Parameters T, delta, nr affect results.",
   "Neighbourhood updates are sequential, hard to parallelise."],
  "Smooth regular fronts with 2-5 objectives.", "Disconnected/degenerate fronts.")

R(19, "Decomposition", "MOEA/D whose offspring is made by DE/rand/1 (F = 0.5, CR = 1) plus polynomial mutation.",
  ["Best of all methods on ZDT2: HV [[D1:P3:19:HV]], IGD [[D1:P3:19:IGD]] over 10 seeds (Fig. D1-P3, A-19).",
   "Handles variable linkages in ZDT2-like problems.",
   "DE operator needs no distribution index tuning.",
   "Inherits MOEA/D efficiency."],
  ["On P5 IGD is [[D1:P5:19:IGD]] and Spacing [[D1:P5:19:SP]] (Fig. A-19, D1-P5): uniform weights do not match the strongly skewed beam front, 25x worse than MODE.",
   "Real-coded only (DE).",
   "Parameters F, CR, nr, delta, T.",
   "Penalty-based constraint handling gives uneven spread."],
  "Continuous problems with complicated variable interactions.", "Discrete or skewed-front problems.")

R(20, "Decomposition", "Sub-problem i owns a pheromone matrix; ant i builds a tour with tau and a weighted heuristic (1/d)^l1 (1/t)^l2; neighbours replaced as in MOEA/D.",
  ["Natural discrete construction: always valid tours (unit test 20), HV [[D3:20:HV]] on P8 (Fig. D3).",
   "Heuristic information per weight vector biases ants to different regions of the front.",
   "Small population (20) so budget goes to many iterations.",
   "Cooperation via neighbours shares pheromone."],
  ["Found only [[A:20:P8:n]] distinct tours, Spacing [[A:20:P8:SP]] (Fig. A-20).",
   "Slow: [[A:20:P8:time]] s (Python loops) for 10,000 evaluations.",
   "Needs problem-specific heuristics; not for continuous variables.",
   "Parameters alpha, beta, rho, T, nr."],
  "Routing/sequencing with good heuristic information.", "Continuous problems.")

R(21, "Constrained", "NSGA-II with Deb's rules in the crowded comparison: feasible beats infeasible, smaller violation wins, otherwise Pareto.",
  ["Feasible, well spread results: P5 Spacing [[A:21:P5:SP]] vs [[A:14:P5:SP]] without rules; HV [[A:21:P5:HV]] (Fig. A-21).",
   "Parameter-free constraint handling (no penalty factor).",
   "Final population is feasible: P7 HV [[A:21:P7:HV]], P6 HV [[A:21:P6:HV]].",
   "Same cost as NSGA-II."],
  ["On P7 the front is on the boundary x1+x2=90: points sit up to [[X:P7:max_line_dev]] units inside (Fig. A-21).",
   "Infeasible individuals are ranked only by violation so exploration of infeasible regions near the boundary is limited.",
   "Violation values of several constraints need scaling to be comparable.",
   "Inherits crowding-distance weakness for M > 3."],
  "Constrained engineering design (P5, P7).", "Problems whose feasible region is tiny and disconnected (needs feasibility-first search).")

R(22, "Swarm", "Velocity update from personal best and an archive leader picked from sparse grid cells, archive of 100, turbulence mutation.",
  ["Fast: [[A:22:P5:time]] s; HV [[A:22:P5:HV]] on P5 and [[A:22:P4:HV]] on P4 (Fig. A-22).",
   "Archive plus grid gives uniform spread: Spacing [[A:22:P4:SP]].",
   "Few operators, easy to code.",
   "Good on smooth continuous problems."],
  ["Constraint handling by penalty only; real-coded.",
   "Premature convergence risk: parameters w, c1, c2, mutation decay (4) need tuning.",
   "Leaders from sparse cells may chase unreachable regions.",
   "Grid divisions and archive size add two more parameters."],
  "Smooth continuous problems with cheap evaluations.", "Discrete encodings without a decoder.")

R(23, "Swarm", "Alpha/beta/delta leaders from the archive, X = mean of three encircling moves, a decreasing 2 -> 0, archive pruned from crowded cells.",
  ["P5: HV [[A:23:P5:HV]], IGD [[A:23:P5:IGD]] (Fig. A-23); no velocity or personal best to store.",
   "Very few parameters (archive size, grid divisions).",
   "Fast: [[A:23:P5:time]] s.",
   "Binary version through thresholding found [[A:23:P9:n]] feature subsets."],
  ["On ZDT2 it converges poorly: HV [[D1:P3:23:HV]] and IGD [[D1:P3:23:IGD]] over 10 seeds (Fig. D1-P3).",
   "Clipping to bounds collapsed the archive to one point - positions had to be re-sampled.",
   "Averaging three leaders contracts diversity as a goes to 0.",
   "Binary use needs a threshold decoder; not elitist for the pack itself."],
  "Smooth low-dimensional problems and quick prototyping.", "Concave fronts with many variables.")

R(24, "Swarm", "Employed bees (one-dimension moves, greedy by dominance), onlookers chosen by rank, scouts reset stale sources; archive.",
  ["Strong ZDT2 result: HV [[D1:P3:24:HV]], IGD [[D1:P3:24:IGD]] (10 seeds, Fig. D1-P3).",
   "Scouts give built-in diversification.",
   "Only 'limit' and colony size as parameters.",
   "Very good Spacing on P6: [[A:24:P6:SP]] (Fig. A-24)."],
  ["Two evaluations per source per cycle: 5 s-scale costs when objectives are expensive.",
   "Single-dimension moves are slow on high-dimensional problems.",
   "Dominance-based replacement is arbitrary for non-dominated pairs (50% rule here).",
   "Real-coded only."],
  "Continuous problems that need robust exploration (P3, P6).", "High dimensional and expensive objectives.")

R(25, "Swarm", "Two pheromone matrices (distance, time), ants with different lambda, probabilistic construction, deposits from non-dominated ants.",
  ["Valid tours by construction; HV [[D3:25:HV]] on P8 and Spacing [[A:25:P8:SP]] (Fig. A-25).",
   "Heuristic knowledge (1/d, 1/t) speeds up search.",
   "Lambda per ant spreads solutions over the front.",
   "Pheromone memory shares information."],
  ["Only [[A:25:P8:n]] distinct tours - low diversity on a 15-city case (Fig. A-25).",
   "Parameters alpha, beta, rho, deposit scheme.",
   "Slow in Python: [[A:25:P8:time]] s.",
   "Discrete only."],
  "TSP/VRP type problems.", "Continuous design problems.")

R(26, "Physics-inspired", "Gaussian neighbour moves with temperature-dependent size, Boltzmann acceptance on a random weighted change, geometric cooling, archive.",
  ["Extremely light: [[A:26:P5:time]] s; P5 IGD [[A:26:P5:IGD]], Spacing [[A:26:P5:SP]] (Fig. A-26).",
   "Can escape local optima (accepts worse moves).",
   "No population-sorting, tiny memory.",
   "Works with any move operator."],
  ["Weak on ZDT2 with many variables: HV [[D1:P3:26:HV]] over 10 seeds vs [[D1:P3:19:HV]] for MOEA/D-DE (Fig. D1-P3).",
   "Cooling schedule T0, Tend, move size - sensitive.",
   "Slow convergence; budget is split among chains.",
   "Random weights give uneven coverage."],
  "Rugged landscapes with cheap neighbours and small memory.", "Smooth high-dimensional continuous problems.")

R(27, "Evolutionary (DE)", "DE/rand/1/bin; the trial vector replaces its target only if it dominates it; non-dominated archive.",
  ["P5: HV [[D1:P5:27:HV]], IGD [[D1:P5:27:IGD]] over 10 seeds - among the best (Fig. D1-P5).",
   "Only F, CR, N to set; no distribution indices.",
   "Self-scaling step from population differences.",
   "Trace in Task C reproduces every number."],
  ["Collapsed to [[A:27:P3:n]] point on ZDT2, HV [[A:27:P3:HV]]: strict dominance replacement drives the population to the (0,1) end (Fig. A-27, C-3).",
   "Nothing maintains diversity except the archive, which cannot store unvisited points.",
   "Replacement needs strict dominance, so mutually non-dominated trials are wasted.",
   "Real-coded only."],
  "Constrained smooth problems where the front is convex-ish (P5).", "Concave fronts.")

R(28, "Human-inspired", "Teacher = non-dominated member; teaching phase X + r(T - TF*mean) with TF shrinking 2 -> 1; learner phase towards the better partner; archive.",
  ["No algorithm-specific parameters except population size (TF is scheduled).",
   "P5: HV [[A:28:P5:HV]], Spacing [[A:28:P5:SP]] (Fig. A-28).",
   "Two phases give both exploration and refinement.",
   "Simple to code."],
  ["Slow on ZDT2: HV [[D1:P3:28:HV]], IGD [[D1:P3:28:IGD]] over 10 seeds (Fig. D1-P3).",
   "Two evaluations per learner per iteration (halves the iterations).",
   "Teacher chosen from a small non-dominated set reduces diversity.",
   "Real-coded only."],
  "Parameter-free first trials on smooth problems.", "Concave, many-variable problems on small budgets.")

R(29, "Swarm", "Frequency-driven velocity towards an archive leader, local walk with prob. 1 - r, acceptance with prob A, A decays, r grows.",
  ["P3: HV [[A:29:P3:HV]], Spacing [[A:29:P3:SP]] with fast runs [[A:29:P3:time]] s (Fig. A-29).",
   "Automatic switch exploration -> exploitation through A and r.",
   "P4: HV [[A:29:P4:HV]].",
   "Few lines of code."],
  ["Needs 5 parameters (fmin, fmax, alpha, gamma, r0); alpha = 0.9 froze the swarm in my first trial, 0.97 was needed.",
   "IGD [[A:29:P4:IGD]] on P4 is about 3x worse than SPEA2 [[A:16:P4:IGD]] (Fig. A-29).",
   "Loudness-based acceptance throws away good moves late.",
   "Real-coded only."],
  "Quick continuous experiments.", "Tight budgets; problems needing fine tuning.")

R(30, "Hybrid (memetic)", "NSGA-II plus hill-climbing local search (random-weight scalarisation) on 20% of the offspring.",
  ["P5: HV [[A:30:P5:HV]], IGD [[A:30:P5:IGD]] (Fig. A-30).",
   "Works on binary P9 feature selection ([[A:30:P9:n]] subsets, Fig. A-30) and permutations (P8).",
   "Local search refines solutions per evaluation.",
   "Inherits NSGA-II elitism."],
  ["High variance on ZDT2: HV [[D1:P3:30:HV]] (10 seeds) vs NSGA-II [[D1:P3:14:HV]] because evaluations go to the local search.",
   "Extra parameters p_ls, steps; budget share of local search.",
   "Random-weight scalar search can pull solutions to the ends.",
   "Each iteration costs ~1.6x NSGA-II evaluations."],
  "Rugged discrete problems (P8, P9) where neighbourhood moves help.", "Smooth problems where plain NSGA-II converges anyway.")

R(31, "Many-objective", "Reference vectors, angle-penalised distance APD, one survivor per vector, vector adaptation.",
  ["M=5 DTLZ2: HV [[D2:31:HV]] and IGD [[D2:31:IGD]], second only to HypE but about 500 times cheaper ([[D2:31:time]] s vs [[D2:34:time]] s, Fig. D2).",
   "Very fast: [[D2:31:time]] s for a 10,000-evaluation run on M=5.",
   "Penalty angle grows over time: exploration first, convergence later.",
   "Adaptation follows the front's scale."],
  ["Population shrinks to [[A:31:P10_3:n]] points on M=3 because empty vectors discard individuals.",
   "Needs a known number of generations (t_max) for the penalty schedule.",
   "Parameters alpha, fr.",
   "Poor on irregular fronts."],
  "4-10 objectives with regular fronts.", "Irregular fronts or 2 objectives.")

R(32, "Indicator-based", "Fitness = sum of -exp(-I(y,x)/(c k)) with the additive epsilon indicator; iteratively remove the worst; no diversity step.",
  ["Excellent on P14: HV [[A:32:P14:HV]], Spacing [[A:32:P14:SP]] (Fig. A-32).",
   "No explicit diversity mechanism needed: the indicator already prefers spread.",
   "Works for any number of objectives.",
   "ZDT2 HV [[D1:P3:32:HV]] (10 seeds)."],
  ["Constraint handling only by penalty; P5 IGD [[D1:P5:32:IGD]] (10 seeds) is the worst of the EAs (Fig. D1-P5).",
   "Kappa must be tuned; fitness is O(N^2).",
   "Needs normalised objectives.",
   "Fitness removal loop is sequential."],
  "Unconstrained problems wanting a well converged, even set.", "Skewed constrained problems.")

R(33, "Indicator-based", "Steady-state (mu+1); discard the point with the smallest hypervolume contribution in the worst front.",
  ["Best Spacing in Task A on P14: [[A:33:P14:SP]] and top IGD [[A:33:P14:IGD]] (Fig. A-33).",
   "Directly optimises hypervolume, so HV is close to the best on ZDT2: [[D1:P3:33:HV]] vs [[D1:P3:19:HV]] for the best method (10 seeds).",
   "Steady-state: always keeps all best solutions.",
   "No diversity parameter."],
  ["Slowest EA here: [[A:33:P3:time]] s for 10,000 evaluations (one sort per evaluation).",
   "Exact HV contribution is exponential in M; MC needed beyond 3 objectives.",
   "Reference point choice affects results.",
   "Hard to parallelise."],
  "Bi/tri-objective problems with expensive evaluations.", "Many objectives or when wall-clock matters.")

R(34, "Indicator-based", "Monte-Carlo estimate of hypervolume contributions with the HypE weights alpha_i; remove worst repeatedly.",
  ["Best on 5 objectives: HV [[D2:34:HV]] and IGD [[D2:34:IGD]] vs NSGA-III [[D2:15:HV]] (Fig. D2); MC estimation keeps hypervolume selection tractable.",
   "M=3: HV [[A:34:P10_3:HV]], the highest of the four P10 runs in Task A.",
   "Sample count trades accuracy for time.",
   "No diversity parameter."],
  ["Very slow: [[A:34:P10_3:time]] s on M=3 and [[D2:34:time]] s on M=5 (Fig. A-34, D2).",
   "Estimates are noisy: unit test needs 200000 samples for 5% accuracy.",
   "Number of samples S is a parameter.",
   "IGD on M=3 is [[A:34:P10_3:IGD]] (MOEA/D [[A:18:P10_3:IGD]])."],
  "Many objectives when HV-driven selection is wanted.", "Strict time limits.")

R(35, "Preference-based", "NSGA-II whose last front is ranked by distance to decision-maker reference points with epsilon-clearing.",
  ["Focuses the population: on P14 [[X:P14:frac_within_0.15kg_rnsga]] of the points lie within 0.15 kg of 1.8 kg vs [[X:P14:frac_within_0.15kg_nsga2]] for NSGA-II (Fig. E-5).",
   "Saves evaluations on the region of interest.",
   "Several reference points are allowed.",
   "Same cost as NSGA-II."],
  ["A wrong reference point steers the search away from what is wanted; on P14 the reference lies behind the front.",
   "Epsilon needs tuning (0.01-0.02).",
   "Less coverage of the rest of the front.",
   "P5: needs an invented reference ([[A:35:P5:HV]] HV)."],
  "Decision maker can name aspirations (P14).", "No preference information available.")

R(36, "Gradient-based", "Min-norm point of the convex hull of task gradients gives a common descent direction (Frank-Wolfe solver).",
  ["Guaranteed descent for every task: <d*,g_i> >= ||d*||^2 (unit test 36).",
   "Reaches the Pareto set: P13a ends at (2.5, 2.5) on the segment x1 = x2 (Fig. A-36).",
   "No loss weights to choose.",
   "Stops at Pareto-stationary points (d* = 0)."],
  ["Needs gradients of all tasks every step (M backward passes).",
   "Gives one Pareto point per run - the point depends on start (2.5,2.5 from (0,5)).",
   "Tends to follow tasks with small gradients; sensitive to gradient scales (needs normalisation in the network).",
   "Minimum-norm QP per step."],
  "Differentiable multi-task learning (P13).", "Black-box or non-differentiable problems.")

R(37, "Gradient-based", "Adaptive task weights w_i so that w_i||grad L_i|| follows the mean gradient norm times relative inverse training rate^alpha.",
  ["Balances tasks automatically: toy weights end near (1.63, 0.37) summing to 2 (Fig. A-37).",
   "On the network with regression targets x10 both losses still fall (Fig. A-P13b).",
   "Single backward pass per task for the shared layer norm.",
   "Light overhead."],
  ["Hyper-parameters alpha, lr_w; weights hit the floor 0.01 when one task's gradient is huge (regression x10: w = (1.99, 0.01)).",
   "Final regression loss ratio [[X:net]] is worse than equal weights in that case.",
   "Heuristic: no Pareto guarantee.",
   "Needs a chosen shared layer."],
  "Multi-task networks with unbalanced loss scales.", "When Pareto optimality guarantees are required.")

FAMILY_ORDER = ["Classical", "Ranking / MCDM", "Non-elitist EA", "Elitist EA", "Elitist EA (many-objective)", "Decomposition", "Constrained", "Swarm", "Physics-inspired",
                "Evolutionary (DE)", "Human-inspired", "Hybrid (memetic)", "Many-objective", "Indicator-based", "Preference-based", "Gradient-based"]

FAMILY_PARAGRAPH = (
 "Diversity: classical methods get diversity only from the sweep (weights, eps, z) and therefore inherit its unevenness; non-elitist EAs rely on sharing or sub-populations and lose it quickly "
 "(VEGA collapsed to one point on ZDT2); elitist EAs add an explicit density estimate (crowding distance, k-th neighbour, grid boxes) and give the most even bi-objective fronts, SPEA2 and SMS-EMOA being "
 "the most even; decomposition and many-objective methods (MOEA/D, NSGA-III, RVEA) get diversity from the geometry of weights or reference vectors, which is superb on regular simplex-like fronts and wasted on skewed ones; "
 "indicator-based methods let the indicator itself prefer spread. Convergence: gradient and scalarisation methods converge fastest per solve on smooth convex problems; DE-based and decomposition EAs (MOEA/D-DE, MODE on P5) "
 "converge best among EAs on continuous problems, while the weaker swarm variants (MOGWO, MO-TLBO, MOSA) needed far more evaluations on ZDT2. Constraints: classical methods pass constraints to a solver, "
 "Deb's rules (Constrained NSGA-II) are the cleanest EA mechanism and the others use a penalty; ignoring them returned a front where 45% of the points violate the stress limit of P5. "
 "Non-convex fronts: weighted sum and p = 1 fail by construction; eps-constraint, Tchebycheff, Benson with a tight reference point, and every Pareto-based EA reach the dent. More than three objectives: dominance-based selection "
 "and crowding degrade (on random DTLZ2 populations the non-dominated share grows from 35% at M=3 to 57% at M=5 and 70% at M=8), so reference-point (NSGA-III, RVEA, MOEA/D) and indicator (HypE) methods are needed.")
