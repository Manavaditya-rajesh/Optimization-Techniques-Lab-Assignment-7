"""Builds the PDF report (reportlab) from the result files."""
import re, glob, pickle
from common import *
from report_text import ROWS, FAMILY_ORDER, FAMILY_PARAGRAPH
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, NextPageTemplate, KeepTogether, Preformatted)

A = json.load(open(os.path.join(DAT, "taskA.json"))); C = json.load(open(os.path.join(DAT, "taskC.json"))); E = json.load(open(os.path.join(DAT, "extras.json")))
D = json.load(open(os.path.join(DAT, "taskD.json"))); UT = json.load(open(os.path.join(DAT, "unit_tests.json")))
ss = getSampleStyleSheet()
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=8.6, leading=11.2, spaceAfter=3)
Bs = ParagraphStyle("Bs", parent=B, fontSize=7, leading=8.6, spaceAfter=0)
Bt = ParagraphStyle("Bt", parent=B, fontSize=6.2, leading=7.4, spaceAfter=0)
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=15, spaceBefore=8, spaceAfter=6); H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=11.5, spaceBefore=6, spaceAfter=4)
H3 = ParagraphStyle("H3", parent=ss["Heading3"], fontSize=9.5, spaceBefore=4, spaceAfter=2)
Cd = ParagraphStyle("Cd", parent=B, fontName="Courier", fontSize=7, leading=8.4)
def P_(t, s=B): return Paragraph(t, s)
def esc(t): return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
story = []
def img(name, w=16.5 * cm, maxh=None):
    path = os.path.join(FIG, name); from PIL import Image as PI
    iw, ih = PI.open(path).size; h = w * ih / iw
    if maxh and h > maxh: w = w * maxh / h; h = maxh
    return Image(path, width=w, height=h)
def tbl(data, widths=None, style=Bs, header=True, fs=7, extra=None):
    rows = [[Paragraph(str(c), style) if not isinstance(c, Paragraph) else c for c in r] for r in data]
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 2.5), ("RIGHTPADDING", (0, 0), (-1, -1), 2.5), ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]
    if header: st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dde6f3")))
    if extra: st += extra
    t.setStyle(TableStyle(st)); return t

# ------------------------------------------------------------------ token filling
TRUE_CACHE = {}
def tv(key):
    if key not in TRUE_CACHE: TRUE_CACHE[key] = ref_hv_true(key)
    return TRUE_CACHE[key]
def fmt(met, v):
    if v is None: return "n/a"
    if met == "n": return "%d" % round(v)
    if met == "time": return "%.1f" % v
    return "%.3f" % v if abs(v) >= 0.01 or v == 0 else "%.4f" % v
net = A["36_37"]
def lr(m, sc): d = net["net_%s_scale%s" % (m, sc)]; return np.array(d["L"][-1]) / np.array(d["L0"])
SPECIAL = {"P1:ws_step_min_max": lambda: "%.3f to %.3f" % tuple(E["P1"]["ws_step_min_max"]), "P1:p1": lambda: str(E["P1"]["p1"]["distinct"]), "P7:max_line_dev": lambda: "%.2f" % E["P7"]["max_line_dev"],
           "P14:frac_within_0.15kg_rnsga": lambda: "%.0f%%" % (100 * E["P14"]["frac_within_0.15kg_rnsga"]), "P14:frac_within_0.15kg_nsga2": lambda: "%.0f%%" % (100 * E["P14"]["frac_within_0.15kg_nsga2"]),
           "net": lambda: "%.3f (GradNorm) vs %.3f (equal)" % (lr("gradnorm", "10")[1], lr("equal", "10")[1])}
bad = []
def fill(s):
    def rep(m):
        p = m.group(1).split(":")
        try:
            if p[0] == "A": return fmt(p[3], A[p[1]][p[2]][p[3]])
            if p[0] == "D1": v = D["D1_%s_%s" % (p[1], p[2])][p[3]]; return "%s&plusmn;%s" % (fmt(p[3], v[0]), fmt(p[3], v[1]))
            if p[0] in ("D2", "D3"):
                v = D["%s_%s" % (p[0], p[1])][p[2]]
                if not isinstance(v, list): return fmt(p[2], v)
                return "%s&plusmn;%s" % (fmt(p[2], v[0]), fmt(p[2], v[1])) if p[2] != "n" else "%.0f" % v[0]
            if p[0] == "TRUE": return "%.3f" % tv(p[1])
            if p[0] == "X":
                key = ":".join(p[1:])
                if key in SPECIAL: return SPECIAL[key]()
                if p[1] == "nsga3_sens": return "%.3f" % C["nsga3_sens"][p[2]][p[3]][0]
        except Exception as e:
            bad.append((m.group(0), repr(e))); return "??"
        bad.append((m.group(0), "unknown")); return "??"
    return re.sub(r"\[\[([^\]]+)\]\]", rep, s)
def bullets(items): return "<br/>".join("&bull; " + fill(esc(x).replace("&amp;plusmn;", "&plusmn;")) for x in items)

# ------------------------------------------------------------------ front matter
story += [Spacer(1, 3 * cm), P_("<b>Lab Assignment 7 &mdash; Multiobjective Optimization</b>", ParagraphStyle("T", parent=H1, fontSize=22, leading=26)),
          P_("37 algorithms, trade-offs and applications", ParagraphStyle("T2", parent=H2, fontSize=14)), Spacer(1, .5 * cm),
          tbl([["Student", "Manavaditya Rajesh"], ["Registration number", "241070040  (roll number R = 40)"], ["Programme", "M.Tech, Department of Artificial Intelligence &amp; Data Science &mdash; Optimization Techniques Lab"],
               ["Deep-dive algorithms (Task C)", "Alg. 1 = ((40-1) mod 37)+1 = <b>3 Benson's Method</b>;  Alg. 2 = ((40+11) mod 37)+1 = <b>15 NSGA-III</b>;  Alg. 3 = ((40+23) mod 37)+1 = <b>27 MODE</b>"],
               ["Language / tools", "Python 3 with NumPy and Matplotlib only for all 37 algorithms and the toolkit; scipy.optimize / linprog only as sub-problem solver of algorithms 1&ndash;7 (Section 2A exception); scikit-learn only to load the Wisconsin data (P9); reportlab only to typeset this PDF"],
               ["Budget / seeds", "10,000 function evaluations per run (1,500 for P9 because every evaluation is a 5-fold 5-NN cross-validation); seed 1 for Task A; seeds 1&ndash;10 for Tasks C and D; mean &plusmn; std reported"],
               ["Issued / compiled", "Issued 5 October 2026; report compiled 25 October 2026"]], [4.5 * cm, 12 * cm], header=False),
          Spacer(1, .6 * cm),
          P_("<b>Reading guide.</b> Section 1 states the 14 problems; Section 2 the toolkit and its unit tests; Section 3 (Task A) the implementation log and one figure per algorithm; Section 4 (Task B) the master comparison table; "
             "Section 5 (Task C) the deep dives; Section 6 (Task D) the head-to-head experiments; Section 7 (Task E) algorithm selection; Section 8 the answers to every 'Investigate' question; Section 9 (Task F) viva preparation; Section 10 reproducibility. "
             "Figures are referred to as Fig. A-nn (Task A, algorithm nn), Fig. C-n, Fig. D-n, Fig. E-n. All numbers come from the raw files in the outputs archive."),
          P_("<b>Honest notes on scope.</b> (i) The 37 algorithms are grouped into 11 Python modules by family (each algorithm is its own class with <i>initialize / evaluate / iterate / run</i> and a docstring listing the lecture steps) rather than 37 separate files. "
             "(ii) I did not have the lecture slides, so the 'car Pareto-front example' and 'Deb's constrained-dominance table' used in the unit tests are small examples I constructed with the same logic. (iii) Where an algorithm behaves poorly on a problem (VEGA and MODE collapse on ZDT2, NSGA-III is under-converged at 10,000 evaluations on DTLZ2) I report it as measured and explain why, rather than tuning it away. "
             "(iv) Constraint handling: Constrained NSGA-II uses Deb's rules, plain NSGA-II ignores constraints (infeasible points are filtered at the end), all other population methods use the same static penalty F + 1 + 10*CV (CV normalised).")]
story.append(PageBreak())

# ------------------------------------------------------------------ 1 formulations
story.append(P_("1. Problem formulations (P1&ndash;P14)", H1))
story.append(P_("Common conventions: every objective is converted to minimisation (Max f = Min -f); each metric is computed after normalising with a fixed ideal/nadir pair per problem, f~ = (f - ideal)/(nadir - ideal), and the hypervolume reference point is (1.1,...,1.1) in normalised space; termination is a budget of 10,000 evaluations (1,500 for P9) unless stated. "
                "IGD uses the analytic or numerically generated true front; Spacing is the standard deviation of nearest-neighbour distances."))
form = [["#", "Standard form min F(x) s.t.", "Encoding &amp; constraint handling", "Normalisation (ideal / nadir), HV ref"],
 ["P1", "min ((x-3)^2, (x-7)^2), 1&le;x&le;10. Pareto set 3&le;x&le;7; f2=(4-&radic;f1)^2 (convex)", "1 real variable; bounds only", "ideal (0,0), nadir (16,16)"],
 ["P2", "min (100/x, x^2), 1&le;x&le;10 (real and integer)", "real x; integer version rounds x inside the evaluation; bounds only", "ideal (10,1), nadir (100,100)"],
 ["P3", "ZDT2, n=10: f1=x1, g=1+&Sigma;x_i, f2=g(1-(f1/g)^2), x in [0,1]^10 (non-convex)", "10 reals; bounds only", "ideal (0,0), nadir (1,1)"],
 ["P4", "min (w'&Sigma;w, -&mu;'w), &Sigma;w=1, w&ge;0 (&mu;, &Sigma; as given)", "4 reals in [0,1]; <b>repair by normalisation</b> w=x/&Sigma;x (default) or penalty |&Sigma;x-1|-0.01 (Section 8)", "ideal (0.00704, -0.15), nadir (0.09, -0.0927); front by my own eps-constraint sweep"],
 ["P5", "min (7850 L b h, 4PL^3/(E b h^3)) s.t. b h^2 &ge; 2.4e-5, b in [0.01,0.1], h in [0.02,0.2]", "2 reals; CV = max(0, 2.4e-5-bh^2)/2.4e-5; analytic true front h=min(0.2,100A), b=A/h", "ideal (3.846 kg, 2.5e-5 m), nadir (157 kg, 0.01701 m)"],
 ["P6", "Binh-Korn: min (4x1^2+4x2^2, (x1-5)^2+(x2-5)^2) s.t. (x1-5)^2+x2^2&le;25, (x1-8)^2+(x2+3)^2&ge;7.7", "2 reals, CV = sum of normalised violations; true front x1=x2 (0..3) &cup; x2=3 (x1 3..5)", "ideal (0,4), nadir (136,50)"],
 ["P7", "min (-0.8x1, -1.2x2) s.t. x1+x2&le;90, x1&ge;10, x2&ge;20", "2 reals in [0,100]; CV normalised; front is the line x1+x2=90, x1&in;[10,70]", "ideal (-56,-96), nadir (-8,-24); DM point (40,50) = (-32,-60)"],
 ["P8", "bi-objective TSP, 15 cities: min (total distance, total time), time=d*u, u~U(0.5,2) symmetric", "permutation of 15 cities (random seed 7, coordinates printed in Section 8); operators OX + inversion/swap", "ideal/nadir from my own 2-opt tours of each objective: ideal (351.8, 366.3), nadir (411.4, 463.7)"],
 ["P9", "min (1-CV accuracy of 5-NN with 5-fold CV, #features), mask&ne;0", "30-bit mask; all-zero mask is infeasible (CV=1); real-coded methods threshold at 0.5", "ideal (0,1), nadir (0.40,30); 5-NN and 5-fold CV coded by me"],
 ["P10", "DTLZ2, M=3 and M=5, n=M+9 variables in [0,1]", "reals; bounds only; true front = unit-sphere simplex-lattice points", "ideal 0, nadir 1; MC hypervolume (40,000 common random samples)"],
 ["P11", "max (4xA+6xB, xA+xB) s.t. 2xA+3xB&le;1200, 4xA+2xB&le;1600; goals profit&ge;2400, units&ge;600; priorities profit &gt; units", "LP (linprog); deviation variables d-, d+", "n/a (LP methods)"],
 ["P12", "5 suppliers &times; 4 criteria, weights (0.3,0.3,0.2,0.2)", "ranking only (TOPSIS, VIKOR)", "vector / min-max normalisation inside the ranker"],
 ["P13", "(a) min (||x-a||^2, ||x-b||^2), start (0,5); (b) two-head network, classification BCE + regression MSE on synthetic data", "(a) 2 reals; (b) hand-coded forward/backward pass, 10-16-1+1", "loss ratios L/L(0)"],
 ["P14", "min (0.4+0.05x1+0.012x2, -0.2x2/(0.5+0.03x1)), x1 in [13,17], x2 in [40,90]", "2 reals; bounds only; true front x1=13", "ideal (1.53,-20.22), nadir (2.13,-8.99); DM point (1.8 kg, 12 h)"]]
story.append(tbl(form, [1 * cm, 6.2 * cm, 5.2 * cm, 4.6 * cm]))
story.append(PageBreak())

# ------------------------------------------------------------------ 2 toolkit
story.append(P_("2. Shared toolkit (moo_utils) and unit tests", H1))
story.append(P_("moo_utils.py contains the dominance test, Deb's constrained dominance, fast non-dominated sorting, crowding distance, rank-and-crowding survivor selection, exact 2-D hypervolume, Monte-Carlo hypervolume (M&ge;3), IGD, Spacing, normalisation and Das-Dennis reference points; problems.py holds P1&ndash;P14; ops.py the real (SBX, polynomial mutation), binary and permutation (order crossover, inversion/swap) operators; base.py the common initialize/evaluate/iterate/run skeleton with budget counting and the archive classes. "
                "tests/test_all.py contains 3 toolkit tests and one key-rule test for each of the 37 algorithms; all must pass before any experiment is run. Verification of the three deep-dive algorithms against the hand traces is shown in Section 5."))
ut = [["Test", "Result"]] + [[esc(r[0]), "<b>%s</b>" % r[1]] for r in UT]
story.append(tbl(ut, [14.5 * cm, 2 * cm])); story.append(P_("<b>%d of %d tests pass.</b>" % (sum(r[1] == "PASS" for r in UT), len(UT))))
story.append(PageBreak())

# ------------------------------------------------------------------ 3 Task A
story.append(P_("3. Task A &mdash; implementation log", H1))
story.append(P_("Seed 1, budget 10,000 evaluations (P9: 1,500). HV and Spacing are computed on the normalised front; IGD only where the true front is known. For algorithms 5&ndash;9 and 36&ndash;37 the output is a solution or ranking, so HV/IGD are not meaningful (n/a); their results are in the figures and in Task D. "
                "Statuses: 'works' means the key-rule unit test passes and the run is plotted; remarks mark behaviour a reader should know about."))
remarks = {10: "works - collapses on ZDT2 (by design: sub-populations favour extremes)", 13: "works - weak on ZDT2", 15: "works - under-converged at 10k evals on DTLZ2 (30k: IGD 0.055, best of 3 methods)", 23: "works - weak on ZDT2; needed bound re-sampling (clipping collapsed the archive)",
           27: "works - collapses on ZDT2 under the strict dominance-replacement rule", 31: "works - only 56 points on M=3 (empty vectors discard)", 34: "works - slow (Monte-Carlo contributions)", 26: "works - weak on ZDT2", 28: "works - weak on ZDT2"}
log = [["#", "Algorithm", "Problems (HV / IGD / Spacing, seed 1)", "Budget", "Runtime s", "Status"]]
for aid in range(1, 38):
    parts = []; tsum = 0
    if aid in (5, 6, 7, 8, 9, 36, 37):
        parts = ["; ".join(TEST[aid]) + ": solution(s) / ranking, see Fig. A-%02d" % aid]
    else:
        for key in TEST[aid]:
            m = A[str(aid)][key]; tsum += m["time"]
            parts.append("%s: HV %.3f, IGD %s, SP %.4f (n=%d)" % (key, m["HV"], "%.4f" % m["IGD"] if m["IGD"] is not None else "n/a", m["SP"], m["n"]))
    bud = "closed form / sweep" if aid <= 9 or aid in (36, 37) else ("%d" % A[str(aid)][TEST[aid][0]]["nfe"] + (" (P9: 1500)" if "P9" in TEST[aid] else ""))
    log.append([aid, NAMES[aid], "<br/>".join(parts), bud, "%.1f" % tsum if tsum else "-", remarks.get(aid, "works")])
story.append(tbl(log, [0.7 * cm, 2.6 * cm, 8.1 * cm, 1.6 * cm, 1.2 * cm, 2.8 * cm], style=Bt))
story.append(PageBreak())
story.append(P_("Per-algorithm figures and results (Fig. A-01 &hellip; A-37)", H2))
extra_notes = {
 5: "Value function: profiles P4 conservative / balanced / aggressive map to weights (0.0,0.395,0.342,0.263) &hellip; see taskA.json; P14 profiles give 1.72 kg / 12.5 h, 1.83 kg / ... (JSON).",
 6: "P11: unit-weight and normalised-weight goal programming both give x = (300,200), profit goal met, units shortfall exactly 100 (the unavoidable minimum). P7: goal (32,60) i.e. (40,50) is reached exactly with zero deviation.",
 7: "P11: profit-first gives 2400 (tie along (300,200)-(0,400)), the second priority picks (300,200) with 500 units. Units-first gives the same x; P7: yield-first (70,20), industry-first (10,80).",
 8: "P12: Pareto-optimal suppliers = %s. TOPSIS ranks %s; after shifting 0.1 of weight from cost to quality %s (the order of S1 and S5 flips)." % (A["8"]["pareto_optimal"], A["8"]["topsis_rank"], A["8"]["topsis_shift_rank"]),
 9: "VIKOR ranks (v=0.25 / 0.5 / 0.75): %s / %s / %s; after the weight shift: %s." % (A["9"]["v=0.25"]["rank"], A["9"]["v=0.50"]["rank"], A["9"]["v=0.75"]["rank"], A["9"]["v=0.50"]["shift_rank"]),
 36: "P13a: equal weights end at (0,0) with losses (18,18); MGDA ends at (2.5,2.5), the projection of the start (0,5) on the Pareto segment, with losses (0.5,60.5). Network results are in Section 6 (Task D).",
 37: "P13a: GradNorm weights end at (1.63,0.37); network results are in Section 6 (Task D)."}
for aid in range(1, 38):
    blk = [P_("<b>%d. %s</b>" % (aid, NAMES[aid]), H3), img("A_alg%02d.png" % aid, 16.5 * cm, 5.2 * cm)]
    if aid in extra_notes: blk.append(P_(extra_notes[aid], Bs))
    story.append(KeepTogether(blk))
story.append(img("A_p13b.png", 15 * cm))
story.append(P_("Fig. A-P13b: P13(b) network, loss divided by initial loss for equal weights, MGDA and GradNorm, regression target scale 1 (left) and 10 (right).", Bs))
story.append(PageBreak())

# ------------------------------------------------------------------ 4 Task B (landscape)
story.append(NextPageTemplate("land")); story.append(PageBreak())
story.append(P_("4. Task B &mdash; master comparison table (all 37 algorithms)", H1))
story.append(P_("Rows are grouped by family. Every algorithm lists at least four advantages and four disadvantages; at least two of each cite a number from my own runs (Task A seed 1, or Task D 10 seeds, or Task C/extras) with the figure; the other points are justified by the algorithm's steps. "
                "'Best' and 'avoid' state the situation in which the algorithm should or should not be chosen.", B))
hdr = ["#", "Algorithm", "What it does (my words)", "Advantages", "Disadvantages", "Best choice when", "Avoid when"]
for fam in FAMILY_ORDER:
    ids = [a for a in sorted(ROWS) if ROWS[a]["family"] == fam]
    if not ids: continue
    data = [hdr]
    for a in ids:
        r = ROWS[a]; data.append([a, "<b>%s</b>" % NAMES[a], fill(esc(r["what"])), bullets(r["adv"]), bullets(r["dis"]), fill(esc(r["best"])), fill(esc(r["avoid"]))])
    story.append(P_("Family: %s" % fam, H2))
    story.append(tbl(data, [0.6 * cm, 1.9 * cm, 3.6 * cm, 6.9 * cm, 6.9 * cm, 2.8 * cm, 2.8 * cm], style=Bt))
story.append(P_("How the families differ (diversity, convergence, constraints, non-convex fronts)", H2)); story.append(P_(FAMILY_PARAGRAPH))
story.append(NextPageTemplate("port")); story.append(PageBreak())

# ------------------------------------------------------------------ 5 Task C
story.append(P_("5. Task C &mdash; deep dive on my three algorithms (R = 40: algorithms 3, 15, 27)", H1))
def card(rows): return tbl([[ "<b>%s</b>" % a, b] for a, b in rows], [3.6 * cm, 12.9 * cm], header=False)

# ---- 5.1 Benson
story.append(P_("5.1 Algorithm 3 &mdash; Benson's Method", H2))
story.append(P_("Study card", H3))
story.append(card([
 ("Full form, year, authors", "Benson's method (H. P. Benson, 1978, 'Existence of efficient solutions for vector maximization problems', J. Optim. Theory Appl. 26). Often called Benson's test/proper-efficiency method."),
 ("Problem it fixes", "Weighted sum cannot reach non-convex parts and cannot tell whether a given design is already Pareto-optimal. Benson starts from an attainable reference point z and finds a Pareto-optimal point that improves on it, with one LP/NLP."),
 ("Core idea (&le;5 lines)", "Pick a reference point z that some feasible design dominates or equals. Introduce slacks l_i = z_i - f_i(x) &ge; 0 (how much each objective is improved) and maximise their weighted sum. The optimal x* is Pareto-optimal and dominates z; if every l_i = 0, z itself was Pareto-optimal. Sweeping z (and w) draws the front."),
 ("Numbered steps", "1. Choose z (objective vector of a feasible design or an aspiration) and weights w_i &gt; 0.<br/>2. Solve  max &Sigma; w_i l_i  s.t.  f_i(x) + l_i = z_i,  l_i &ge; 0,  x in X (SLSQP, 6 random starts).<br/>3. Report x*, f(x*), l*.<br/>4. If l* = 0 the point z is Pareto-optimal; otherwise f(x*) improves z by l*.<br/>5. Repeat with a new z (the sweep z_k = (t_k, 1-t_k) + delta in normalised space)."),
 ("Parameters", "<b>z</b>: beyond the nadir the constraints are inactive and Benson collapses to weighted sum (offset 0.6: 2 end points); too tight (no feasible design improves it) the sub-problem is infeasible (offset 0.02 on ZDT2: 2 points). Offset 0.2 gave the best coverage (Fig. C-1). <b>w</b>: with equal weights on a linear front (P7) the optimum is a degenerate tie; unequal weights pick a vertex."),
 ("Convergence / diversity", "Each solve is exact (local optimum of a smooth NLP; LP optimum for linear problems). Diversity comes only from the user's sweep of z and w; nothing spreads the points automatically."),
 ("Constraints / non-convex / M>3", "Constraints are passed to the solver. Non-convex fronts are reachable when z is attainable and close (Fig. C-1). For M objectives M slacks are added; the sweep needs a grid of dimension M-1, so it is practical for 2-3 objectives."),
 ("Complexity", "One NLP (SLSQP: about O((n+M)^3) per iteration) or LP per reference point; k reference points cost k solves, no population.")]))
story.append(img("flow_benson.png", 16.5 * cm))
story.append(P_("Hand trace on P1 (min f1 = (x-3)^2, f2 = (x-7)^2, w = (1,1)). Maximising l1 + l2 = z1 + z2 - [(x-3)^2 + (x-7)^2] means minimising S(x) = (x-3)^2 + (x-7)^2, whose unconstrained minimiser is x = 5 (S' = 4x - 20 = 0). The constraints l &ge; 0 restrict x to (x-3)^2 &le; z1 and (x-7)^2 &le; z2, i.e. x in [max(3-&radic;z1, 7-&radic;z2), min(3+&radic;z1, 7+&radic;z2)]. The solution is x = 5 clipped to that interval.", B))
bt = C["benson_trace"]
rows = [["", "Setting 1: z = (10, 8)", "Setting 2: z = (2, 20)"],
        ["allowed interval for x", "[%.4f, %.4f]" % tuple(bt[0]["interval"]), "[%.4f, %.4f]" % tuple(bt[1]["interval"])],
        ["x* (hand)", "5 inside the interval -> x = %.4f" % bt[0]["x"], "5 is above 4.4142 -> clipped x = 3+&radic;2 = %.4f" % bt[1]["x"]],
        ["f(x*) hand", "(%.4f, %.4f)" % tuple(bt[0]["f"]), "(%.4f, %.4f)" % tuple(bt[1]["f"])],
        ["l = z - f hand", "(%.4f, %.4f), sum %.4f" % (bt[0]["l"][0], bt[0]["l"][1], bt[0]["sum_l"]), "(%.4f, %.4f), sum %.4f" % (bt[1]["l"][0], bt[1]["l"][1], bt[1]["sum_l"])],
        ["x*, f, l from my code (benson())", "x = %.4f, f = (%.4f, %.4f), l = (%.4f, %.4f)" % (bt[0]["code_x"], *bt[0]["code_f"], *bt[0]["code_l"]), "x = %.4f, f = (%.4f, %.4f), l = (%.4f, %.4f)" % (bt[1]["code_x"], *bt[1]["code_f"], *bt[1]["code_l"])],
        ["code reproduces hand trace?", "<b>%s</b>" % ("YES" if bt[0]["match"] else "NO"), "<b>%s</b>" % ("YES" if bt[1]["match"] else "NO")]]
story.append(tbl(rows, [4 * cm, 6 * cm, 6.5 * cm]))
story.append(P_("Second setting in words: with z1 = 2 the first objective is capped, (x-3)^2 &le; 2 gives x &le; 3 + 1.4142 = 4.4142, which is below the sum-minimiser 5, so the constraint f1 &le; z1 is active (l1 = 0) and all improvement goes to f2: l2 = 20 - 6.6863 = 13.3137.", B))
story.append(P_("Sensitivity study: reference-point offset delta (the most important parameter)", H3))
sb = C["benson_sens"]
story.append(tbl([["delta in z_k = (t_k, 1-t_k) + delta", "distinct non-dominated points", "points with 0.2 &lt; f1 &lt; 0.8", "HV (mean &plusmn; std)", "IGD (mean &plusmn; std)"]] +
                 [[d, "%.1f" % sb[d]["n"][0], "%.1f" % sb[d]["mid"][0], "%.3f &plusmn; %.4f" % tuple(sb[d]["HV"]), "%.3f &plusmn; %.4f" % tuple(sb[d]["IGD"])] for d in sb], [4.8 * cm, 3 * cm, 3.3 * cm, 2.8 * cm, 2.6 * cm]))
story.append(img("C_benson_sens.png", 16.5 * cm)); story.append(P_("Fig. C-1: Benson on ZDT2 for three offsets (15 reference points each; green dashed = the line f1 + f2 = 1; 10 seeds only change the multi-start, so the std is tiny). "
    "Because the ZDT2 front lies <i>above</i> that line, a reference point on it with offset 0.02 is not attainable in the middle (infeasible sub-problems, only the two end points remain); offset 0.2 is attainable and tight enough to bind, so Benson finds the dented middle (5 points, best HV 0.488, IGD 0.048); offset 0.6 is beyond the nadir, the constraints are inactive and the method reproduces weighted sum (end points only).", Bs))

# ---- 5.2 NSGA-III
story.append(PageBreak()); story.append(P_("5.2 Algorithm 15 &mdash; NSGA-III", H2)); story.append(P_("Study card", H3))
story.append(card([
 ("Full form, year, authors", "Non-dominated Sorting Genetic Algorithm III &mdash; K. Deb and H. Jain, 2014, IEEE Trans. Evolutionary Computation 18(4) (reference-point based many-objective NSGA)."),
 ("Problem it fixes", "In NSGA-II the crowding distance stops working with 4+ objectives (almost every point is non-dominated and neighbours are no longer meaningful); NSGA-III replaces it by niching around well-spread reference points."),
 ("Core idea (&le;5 lines)", "Keep NSGA-II's elitist (P+Q) non-dominated sorting. Choose structured reference points on the unit simplex (Das-Dennis). When the last front must be cut, normalise the objectives, associate every candidate with its nearest reference line and fill the missing slots from the least-crowded reference lines, preferring the candidate closest to the line."),
 ("Numbered steps", "1. Reference points Z = Das-Dennis(M,H), |Z| = C(M+H-1,H); N &asymp; |Z|.<br/>2. R = P u Q; non-dominated sort; take whole fronts until size &ge; N; last front F_l.<br/>3. Ideal z_i = min f_i over S_t; translate f'_i = f_i - z_i.<br/>4. Extreme points by ASF(f',w) = max_i f'_i / w_i with w = e_i (+1e-6); intercepts a_i from the hyperplane through them; f~_i = f'_i / a_i.<br/>5. Association: d&perp;(s,w) = ||f~ - (w&middot;f~/||w||^2) w||, j(s) = argmin_w d&perp;.<br/>6. Niche count rho_j = number of already chosen members at line j.<br/>7. Repeat K = N - |chosen| times: pick the line with minimum rho (random tie); if rho = 0 take the F_l member with smallest d&perp; else a random member; rho_j += 1."),
 ("Parameters", "<b>H</b> (divisions): too small gives very few lines and small N (H = 4: 15 lines, N = 16, IGD 0.159), too large gives a big N and few generations for the same budget (H = 12: N = 92, 10 generations fewer, HV 0.590 &plusmn; 0.035, noisy); H = 8 was best (IGD 0.099) (Fig. C-2). pc, eta_c, eta_m: standard SBX/polynomial mutation (0.9, 15, 20)."),
 ("Convergence / diversity", "Elitist non-dominated sorting for convergence; diversity is enforced by the niche counts, so every reference line gets a representative if one exists. At 10,000 evaluations it is still converging on DTLZ2 (IGD 0.120 at 10k, 0.055 at 30k evaluations, best of NSGA-II/MOEA/D at 30k)."),
 ("Constraints / non-convex / M>3", "Constraints: Deb's constrained domination can be put into the sort (here the same penalty as the other methods). Non-convex fronts: dominance-based, so fine. M>3: this is what it was designed for (M=5 in Task D). Weak point: irregular or degenerate fronts leave reference lines empty."),
 ("Complexity", "O(N^2 M) for the sort of 2N points plus O(N |Z| M) for association per generation, i.e. a little more than NSGA-II.")]))
story.append(img("flow_nsga3.png", 16.5 * cm))
story.append(P_("Hand trace: tiny instance on P1 (one variable x, minimise (x-3)^2 and (x-7)^2), M = 2, H = 3, reference points Z = {(0,1), (1/3,2/3), (2/3,1/3), (1,0)}, N = 4. Parent population x = {1.0, 3.5, 6.0, 9.0}. "
               "To make every number checkable the offspring are given (they stand for the result of SBX + mutation, which is verified separately by unit tests): generation 1 offspring {1.5, 8.0, 2.0, 5.5}, generation 2 offspring {9.0, 4.5, 4.0, 5.0}. "
               "In the tables 'idx' numbers the 8 combined individuals (0-3 parents, 4-7 offspring). The hand trace was computed with plain Python loops (nsga3_trace in run_task_c.py) and compared with my module's nsga3_select for 30 different random seeds.", B))
for g, T in enumerate(C["nsga3_trace"]):
    story.append(P_("Generation %d" % (g + 1), H3))
    fr_of = {}
    for k, fr in enumerate(T["fronts"]):
        for i in fr: fr_of[i] = k + 1
    rows = [["idx", "x", "f1", "f2", "front", "f'~1 (normalised)", "f'~2", "nearest line j (Z_j)", "d_perp", "selected"]]
    sel = set(T["selected"])
    for i, (x, f) in enumerate(zip(T["combined_x"], T["F"])):
        nm = T["normalised"].get(str(i)); asj = T["assoc"].get(str(i))
        rows.append([i, "%.1f" % x, "%.2f" % f[0], "%.2f" % f[1], fr_of[i], "%.3f" % nm[0] if nm else "-", "%.3f" % nm[1] if nm else "-", ("%d (%.2f,%.2f)" % (asj[0], *C["nsga3_Z"][asj[0]])) if asj else "-", "%.3f" % asj[1] if asj else "-", "<b>yes</b>" if i in sel else "no"])
    story.append(tbl(rows, [0.8 * cm, 1 * cm, 1.3 * cm, 1.3 * cm, 1.1 * cm, 2.4 * cm, 1.5 * cm, 3.3 * cm, 1.5 * cm, 1.7 * cm]))
    ex = T.get("extreme"); ic = T.get("intercepts")
    txt = "Fronts: %s. Whole fronts taken before the cut: %s; last front F_l = %s. " % (T["fronts"], T["chosen_full"], T["last"])
    if ic: txt += "Ideal point (%.2f, %.2f); extreme points = idx %s; intercepts (%.3f, %.3f). Initial niche counts rho = %s. " % (T["ideal"][0], T["ideal"][1], ex, ic[0], ic[1], T["rho0"])
    for (zi, mn, nt, c, why) in T["niching"]: txt += "Niching step: line %d (rho = %d, %d tied lines) &rarr; idx %d (%s). " % (zi, mn, nt, c, why)
    txt += "<b>Selected idx = %s</b> (x = %s) and my code returns %s: <b>%s</b>." % (sorted(T["selected"]), [T["combined_x"][i] for i in sorted(T["selected"])], T["selected_code"], "MATCH" if T["match"] and T["match_all_seeds"] else "MISMATCH")
    story.append(P_(txt, B))
story.append(P_("Sensitivity study: number of divisions H on DTLZ2 (M = 3), 10 seeds each, 10,000 evaluations", H3))
sn = C["nsga3_sens"]
story.append(tbl([["H", "reference points", "N", "HV mean &plusmn; std", "IGD mean &plusmn; std", "Spacing", "points"]] +
                 [[h, len(U.das_dennis(3, int(h))), sn[h]["pop"], "%.3f &plusmn; %.3f" % tuple(sn[h]["HV"]), "%.3f &plusmn; %.3f" % tuple(sn[h]["IGD"]), "%.3f &plusmn; %.3f" % tuple(sn[h]["SP"]), "%.1f" % sn[h]["n"][0]] for h in sn], [1.2 * cm, 2.4 * cm, 1.2 * cm, 3.2 * cm, 3.2 * cm, 3.2 * cm, 1.8 * cm]))
story.append(img("C_nsga3_sens.png", 13 * cm))
story.append(P_("Fig. C-2: NSGA-III sensitivity to H. A very coarse set (H=4) is fast to converge but returns only 16 points (IGD 0.159); H=8 balances density and generations; H=12 gives the densest and most even set (Spacing 0.060) but, with a fixed 10,000-evaluation budget, fewer generations and a noisier HV.", Bs))

# ---- 5.3 MODE
story.append(PageBreak()); story.append(P_("5.3 Algorithm 27 &mdash; MODE (multi-objective differential evolution)", H2)); story.append(P_("Study card", H3))
story.append(card([
 ("Full form, year, authors", "Multi-Objective Differential Evolution. DE: R. Storn and K. Price (1997); Pareto-based MODE: F. Xue, A. C. Sanderson and R. J. Graves, 2003 (IEEE CEC). The lecture form implemented here: DE/rand/1/bin where the trial replaces its target only if it dominates it, plus a non-dominated archive."),
 ("Problem it fixes", "Genetic algorithms need distribution indices and crossover/mutation tuning; DE uses scaled differences of population members so the step size adapts automatically. MODE brings that to Pareto problems by replacing the scalar 'better' test by dominance."),
 ("Core idea (&le;5 lines)", "For each target x_i make a mutant v = x_r1 + F (x_r2 - x_r3) from three other members, mix v with x_i by binomial crossover (rate CR, one forced coordinate j_rand) to get the trial u, evaluate u and let it replace x_i only if u dominates x_i. All non-dominated points seen are kept in an archive (crowding-truncated to 100)."),
 ("Numbered steps", "1. Random population of N vectors in the box; evaluate.<br/>2. For i = 1..N: choose distinct r1, r2, r3 &ne; i.<br/>3. v = x_r1 + F (x_r2 - x_r3).<br/>4. u_k = v_k if rand_k &lt; CR or k = j_rand, else x_ik; clip u to the bounds.<br/>5. Evaluate u.<br/>6. If u dominates x_i then x_i = u (otherwise keep x_i).<br/>7. Add all trials to the archive; repeat 2-7 until the budget is spent."),
 ("Parameters", "<b>F</b> (scale factor): too small (0.2) means tiny steps, slow movement; too large (0.9) means overshoot and noisy search. <b>CR</b>: low = coordinate-wise moves, high = rotation-invariant moves. <b>N</b>: needs &ge; 4; small N has little difference-vector variety, large N is slow. On P5 the effect of F is small (Fig. C-3); on ZDT2 the algorithm collapses for every F."),
 ("Convergence / diversity", "Convergence is fast and monotone for every individual (an individual never gets worse in dominance). Diversity is weak: nothing pushes members apart and mutually non-dominated trials are wasted, so the population can drift to one end of the front."),
 ("Constraints / non-convex / M>3", "Constraints: penalty (here) or Deb rules in the replacement test. Non-convex: on ZDT2 the (0,1) end point dominates its neighbours' trials in f2 only after g shrinks, and the population contracts onto it (HV 0.110, 1 point, all 10 seeds). M&gt;3: dominance becomes rare in the replacement test so improvement stalls."),
 ("Complexity", "Per generation O(N n) for variation, N evaluations, O(N M) dominance tests, plus archive maintenance O(A^2 M); memory O(N n + A n).")]))
story.append(img("flow_mode.png", 16.5 * cm))
mt = C["mode_trace"]
story.append(P_("Hand trace: P14 (two variables x1 in [13,17], x2 in [40,90]; minimise weight f1 = 0.4 + 0.05 x1 + 0.012 x2 and -runtime f2 = -0.2 x2 / (0.5 + 0.03 x1)), N = 4, F = 0.5, CR = 0.9, seed 7. The random numbers (initial population, the indices r1, r2, r3 for each target, the crossover uniforms and j_rand) are those produced by numpy's generator with seed 7; the "
               "arithmetic below was recomputed independently with plain Python and then compared with my module's MODE.iterate (population after each iteration identical: iteration 1 <b>%s</b>, iteration 2 <b>%s</b>)." % ("MATCH" if mt["iters"][0]["match_code"] else "MISMATCH", "MATCH" if mt["iters"][1]["match_code"] else "MISMATCH"), B))
story.append(P_("Initial population", H3))
story.append(tbl([["i", "x1", "x2", "f1 (kg)", "f2 (-hours)"]] + [[i, "%.4f" % x[0], "%.4f" % x[1], "%.4f" % f[0], "%.4f" % f[1]] for i, (x, f) in enumerate(zip(mt["x0"], mt["f0"]))], [1 * cm, 3 * cm, 3 * cm, 3 * cm, 3 * cm]))
for it, d in enumerate(mt["iters"]):
    story.append(P_("Iteration %d" % (it + 1), H3))
    rows = [["i", "r1,r2,r3", "mutant v = x_r1 + 0.5 (x_r2 - x_r3)", "j_rand", "crossover (x1,x2 from v?)", "trial u (clipped)", "f(u)", "f(x_i)", "u dominates x_i?"]]
    for r in d["rows"]:
        rows.append([r["i"], "%d,%d,%d" % tuple(r["r"]), "(%.4f, %.4f)" % tuple(r["v"]), r["jr"] + 1, "%s, %s" % tuple("yes" if c else "no" for c in r["cross"]), "(%.4f, %.4f)" % tuple(r["u"]), "(%.4f, %.4f)" % tuple(r["f_u"]), "(%.4f, %.4f)" % tuple(r["f_x"]), "<b>%s</b>" % ("replace" if r["replace"] else "keep")])
    story.append(tbl(rows, [0.5 * cm, 1.3 * cm, 3.4 * cm, 1.0 * cm, 2.1 * cm, 3.0 * cm, 2.3 * cm, 2.3 * cm, 1.5 * cm], style=Bt))
    story.append(P_("Population after iteration %d: %s. Archive size %d." % (it + 1, "; ".join("x%d = (%.3f, %.3f)" % (i, x[0], x[1]) for i, x in enumerate(d["X"])), d["archive_size"]), Bs))
story.append(P_("Reading the trace: target 0 is replaced because its trial hit the corner (13, 90) (lightest-weight design at maximum battery is not required to dominate in both... it dominates since f1 2.130 &lt; 2.193 and -20.22 &lt; -17.59); target 2's trial is clipped at x1 = 17 and is dominated in runtime so it is rejected; this shows the key rule 'replace only if it dominates' and the clipping rule.", Bs))
story.append(P_("Sensitivity study: scale factor F (0.2, 0.5, 0.9), CR = 0.9, N = 100, 10 seeds, 10,000 evaluations", H3))
sm = C["mode_sens"]
story.append(tbl([["problem / F", "HV mean &plusmn; std", "IGD mean &plusmn; std", "Spacing", "points in archive"]] +
                 [[k.replace("_", " "), "%.3f &plusmn; %.4f" % tuple(sm[k]["HV"]), "%.4f &plusmn; %.4f" % tuple(sm[k]["IGD"]), "%.4f &plusmn; %.4f" % tuple(sm[k]["SP"]), "%.1f" % sm[k]["n"][0]] for k in sm], [3 * cm, 4 * cm, 4 * cm, 3 * cm, 2.5 * cm]))
story.append(img("C_mode_sens.png", 13 * cm))
story.append(P_("Fig. C-3: MODE sensitivity. On P5 (convex-like, constrained) F barely changes the front (IGD about 0.005-0.006) but larger F is slightly more accurate and more consistent; on ZDT2 every F collapses to the single end point (0,1): the failure comes from the strict dominance replacement rule, not from the step size.", Bs))
story.append(PageBreak())

# ------------------------------------------------------------------ 6 Task D
story.append(P_("6. Task D &mdash; head-to-head comparison (own implementations, equal budget 10,000 evaluations, 10 seeds)", H1))
def ms_(v, d=3): return "%.*f &plusmn; %.*f" % (d, v[0], d, v[1]) if v else "n/a"
def ranked(key):
    rows = [(int(k.split("_")[-1]), v) for k, v in D.items() if k.startswith("D1_%s_" % key)]; rows.sort(key=lambda r: -r[1]["HV"][0]); return rows
for key, ttl in (("P3", "D1(a) P3 ZDT2 (unconstrained, n = 10)"), ("P5", "D1(b) P5 cantilever beam (constrained)")):
    rk = ranked(key); story.append(P_(ttl, H2))
    story.append(tbl([["rank by HV", "algorithm", "HV (mean &plusmn; std)", "IGD (mean &plusmn; std)", "Spacing (mean &plusmn; std)", "points", "time s"]] +
                     [[i + 1, "%d %s%s" % (a, NAMES[a], " *" if a in (1, 2, 4) else ""), ms_(v["HV"]), ms_(v["IGD"], 4), ms_(v["SP"], 4), "%.0f" % v["n"][0], "%.1f" % v["time"]] for i, (a, v) in enumerate(rk)], [1.3 * cm, 4.6 * cm, 3 * cm, 3 * cm, 3 * cm, 1.1 * cm, 1.2 * cm], style=Bt))
    story.append(P_("* classical sweeps (21 weights / eps / Tchebycheff weights) are deterministic up to multi-start, so std = 0 and no time measured per run. True-front HV for reference: %.3f." % tv(key), Bs))
    story.append(img("D1_%s_hv.png" % key, 14 * cm)); story.append(img("D1_%s_fronts.png" % key, 16.5 * cm))
    story.append(P_("Fig. D-1%s: fronts of all algorithms on %s, seed 1 (black line = true front)." % ("a" if key == "P3" else "b", key), Bs))
    exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "d_text.py")).read().split("#---%s---" % key)[1].split("#---end---")[0])
story.append(PageBreak())
story.append(P_("D2 Many-objective: DTLZ2 with M = 5 (population 70, 10,000 evaluations, 10 seeds)", H2))
ids = [14, 15, 18, 31, 34]
story.append(tbl([["algorithm", "HV (mean &plusmn; std)", "IGD (mean &plusmn; std)", "Spacing", "points", "time s"]] + [[NAMES[a], ms_(D["D2_%d" % a]["HV"]), ms_(D["D2_%d" % a]["IGD"]), ms_(D["D2_%d" % a]["SP"]), "%.1f" % D["D2_%d" % a]["n"][0], "%.1f" % D["D2_%d" % a]["time"]] for a in sorted(ids, key=lambda a: -D["D2_%d" % a]["HV"][0])], [3.2 * cm, 3.6 * cm, 3.6 * cm, 3.4 * cm, 1.4 * cm, 1.4 * cm]))
story.append(img("D23_hv.png", 14 * cm))
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "d_text.py")).read().split("#---D2---")[1].split("#---end---")[0])
story.append(P_("D3 Discrete: P8 bi-objective TSP (15 cities), permutation operators (10 seeds)", H2))
ids = [20, 25, 14, 30]
story.append(tbl([["algorithm", "HV (mean &plusmn; std)", "Spacing", "points", "time s"]] + [[NAMES[a], ms_(D["D3_%d" % a]["HV"]), ms_(D["D3_%d" % a]["SP"]), "%.1f" % D["D3_%d" % a]["n"][0], "%.1f" % D["D3_%d" % a]["time"]] for a in sorted(ids, key=lambda a: -D["D3_%d" % a]["HV"][0])], [4 * cm, 4 * cm, 3.5 * cm, 2 * cm, 2 * cm]))
story.append(img("D3_P8_fronts.png", 9 * cm))
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "d_text.py")).read().split("#---D3---")[1].split("#---end---")[0])
story.append(P_("D4 Methods that do not produce a front on their own", H2))
a8, a9 = A["8"], A["9"]
story.append(P_("<b>Algorithms 1&ndash;4</b> were swept with 21 weights / eps values / Tchebycheff weights (15 reference points for Benson) and appear in the D1 tables. <b>Algorithms 5&ndash;7</b>: the preference or priority that produced each answer is listed in Section 3 (value-function exponents a for investor and laptop profiles; goal weights and targets; priority order and tolerance).", B))
story.append(P_("<b>TOPSIS and VIKOR on the NSGA-II front of P4</b> (%d portfolios, weights 0.5 risk / 0.5 return, then 0.6 / 0.4):" % a8["P4_front"]["n"], B))
rows = [["method", "top 3 (risk, return) with weights 0.5/0.5", "top 3 after shifting weight 0.1 (0.6/0.4)", "winner flips?"]]
for nm, d in (("TOPSIS", a8["P4_front"]), ("VIKOR (v=0.5)", a9["P4_front"])):
    rows.append([nm, "<br/>".join("%d. (%.4f, %.4f)  w=%s" % (i + 1, t["risk"], t["ret"], t["w"]) for i, t in enumerate(d["top3"])), "<br/>".join("%d. (%.4f, %.4f)  w=%s" % (i + 1, t["risk"], t["ret"], t["w"]) for i, t in enumerate(d["top3_shift"])), "<b>%s</b>" % ("yes" if d["flips"] else "no")])
story.append(tbl(rows, [2.3 * cm, 5.9 * cm, 5.9 * cm, 2.4 * cm], style=Bs))
story.append(P_("<b>P12 suppliers</b>: Pareto-optimal suppliers %s (S4 is cheapest, S3 best on quality/delivery/reliability, S1 and S5 balanced; S2 is dominated by none either). TOPSIS: %s; with weight shifted 0.1 from cost to quality: %s &rarr; <b>the ranking flips (S1 and S5 swap)</b>. VIKOR v = 0.25 / 0.5 / 0.75: %s / %s / %s; after the shift at v = 0.5: %s. "
               "When S3's cost is raised to 400 TOPSIS ranks %s and VIKOR (v = 0) %s: both punish S3, VIKOR ties it with S4 on maximal regret. A cleaner test is a toy case of two alternatives with 4 equally weighted benefit criteria, A = (6,6,6,6) and B = (10,10,10,1): TOPSIS C = 0.598 vs 0.577 (A narrowly first), VIKOR v = 0 gives Q = 0 vs 1 (A decisively first) and v = 1 gives Q = 0.275 vs 0 (B first). <b>VIKOR with a small v protects against one very bad criterion</b> because R is the largest single regret; TOPSIS lets the three excellent criteria compensate. " % (
               a8["pareto_optimal"], a8["topsis_rank"], a8["topsis_shift_rank"], a9["v=0.25"]["rank"], a9["v=0.50"]["rank"], a9["v=0.75"]["rank"], a9["v=0.50"]["shift_rank"], a8["bad_criterion_topsis"], a9["bad_criterion_vikor_v0"]), B))
story.append(P_("<b>Algorithms 36&ndash;37 on P13</b>", B))
rows = [["setting", "method", "final f1 or L_cls/L_cls(0)", "final f2 or L_reg/L_reg(0)", "final weights"]]
for m in ("equal", "mgda", "gradnorm"):
    d = net["toy_" + m]; rows.append(["P13a toy (losses, start (0,5))", m, "%.3f" % d["final_L"][0], "%.3f" % d["final_L"][1], str(np.round(d["w"], 2).tolist()) if m == "gradnorm" else ("alpha* from min-norm solver" if m == "mgda" else "(1,1)")])
for sc in ("1", "10"):
    for m in ("equal", "mgda", "gradnorm"):
        d = net["net_%s_scale%s" % (m, sc)]; l_ = np.array(d["L"][-1]) / np.array(d["L0"]); rows.append(["P13b network, regression target x%s" % sc, m, "%.3f" % l_[0], "%.3f" % l_[1], str(np.round(d["w"][-1], 2).tolist())])
story.append(tbl(rows, [4.5 * cm, 2 * cm, 3.4 * cm, 3.4 * cm, 3 * cm]))
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "d_text.py")).read().split("#---D4---")[1].split("#---end---")[0])
story.append(PageBreak())

# ------------------------------------------------------------------ 7 Task E
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "e_text.py")).read())
# ------------------------------------------------------------------ doc
def foot(c, d):
    c.saveState(); c.setFont("Helvetica", 7); c.drawString(1.5 * cm, 0.8 * cm, "Lab Assignment 7 - Manavaditya Rajesh (241070040)"); c.drawRightString(c._pagesize[0] - 1.5 * cm, 0.8 * cm, "Page %d" % d.page); c.restoreState()
doc = BaseDocTemplate(os.path.join(OUT, "Lab7_Report_Manavaditya_Rajesh_241070040.pdf"), pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.5 * cm, bottomMargin=1.6 * cm, title="Lab Assignment 7 - Multiobjective Optimization", author="Manavaditya Rajesh")
fp = Frame(1.8 * cm, 1.6 * cm, A4[0] - 3.6 * cm, A4[1] - 3.1 * cm, id="p"); L = landscape(A4); fl = Frame(1.3 * cm, 1.5 * cm, L[0] - 2.6 * cm, L[1] - 2.8 * cm, id="l")
doc.addPageTemplates([PageTemplate(id="port", frames=[fp], onPage=foot, pagesize=A4), PageTemplate(id="land", frames=[fl], onPage=foot, pagesize=L)])
doc.build(story)
print("tokens unresolved:", bad)
print("PDF built")
