"""Problem-specific investigations (the 'Investigate' questions of P1-P14) and viva evidence."""
from common import *
from moo.a08_mcdm import *
from moo.ops import PermOps, order_crossover, inversion_swap_mut
out = {}
def ms(v): return [float(np.mean(v)), float(np.std(v))]

# ---------------- P1
p1 = mkprob("P1"); r = {}
rw = weighted_sum(p1, n_w=21); F = np.array([f for _, _, f in rw]); X = np.array([x[0] for _, x, _ in rw])
r["ws_distinct"] = int(len(np.unique(np.round(X, 3))))
d = np.linalg.norm(np.diff(F[np.argsort(F[:, 0])], axis=0), axis=1); r["ws_step_min_max"] = [float(d.min()), float(d.max())]
r["ws_x"] = X.round(3).tolist()
for pn, lab in ((1, "p1"), (2, "p2"), (np.inf, "pinf")):
    rr = weight_metric(p1, n_w=21, pnorm=pn); Fx = np.array([f for _, _, f in rr]); Xx = np.array([x[0] for _, x, _ in rr])
    dd = np.linalg.norm(np.diff(Fx[np.argsort(Fx[:, 0])], axis=0), axis=1)
    r[lab] = dict(distinct=int(len(np.unique(np.round(Xx, 3)))), spacing=float(U.spacing(Fx)), step_min_max=[float(dd.min()), float(dd.max())], x=Xx.round(2).tolist())
out["P1"] = r

# ---------------- P2 real vs integer, clustering
r = {}
for key in ("P2", "P2i"):
    for aid in (10, 14):
        X, F, t, n = run_pop(aid, key, seed=1); x = X[:, 0] if key == "P2" else np.round(X[:, 0])
        r["%s_%d" % (key, aid)] = dict(n=int(len(F)), distinct_x=int(len(np.unique(np.round(x, 2)))), frac_x_lt_3=float((x < 3).mean()), frac_x_gt_8=float((x > 8).mean()),
                                         x_quartiles=np.percentile(x, [0, 25, 50, 75, 100]).round(2).tolist(), SP=float(U.spacing(F)), HV=float(U.hypervolume(F, mkprob(key).ref_hv)))
rr = eps_constraint(mkprob("P2"), n_eps=21); r["eps_x"] = [float(x[0]) for _, x, _ in rr]
out["P2"] = r

# ---------------- P3 IGD vs population and generations (NSGA-II)
p3 = mkprob("P3"); grid = {}
for pop in (20, 50, 100, 200):
    for gens in (25, 50, 100, 200):
        v = []
        for s in range(1, 4):
            a = NSGA2(p3, pop=pop, seed=s); X, F = a.run(pop * (gens + 1)); v.append(U.igd(p3.norm(p3.true_front()), F))
        grid["%d_%d" % (pop, gens)] = float(np.mean(v))
out["P3_igd_grid"] = grid; print("P3 grid done"); sys.stdout.flush()

# ---------------- P4 repair vs penalty
r = {}
for key in ("P4", "P4p"):
    rows = []; viol = []
    for s in range(1, 6):
        p = mkprob(key); a = NSGA2(p, seed=s, cmode="penalty" if key == "P4p" else "ignore"); X, F = a.run(10000); m = metrics(key, F); rows.append(m)
        viol.append(float(np.abs(X.sum(1) - 1).max()) if key == "P4p" else 0.0)
    r[key] = dict(HV=ms([m["HV"] for m in rows]), IGD=ms([m["IGD"] for m in rows]), SP=ms([m["SP"] for m in rows]), max_sum_violation=float(np.max(viol)))
p = mkprob("P4"); X, F, t, n = run_pop(14, "P4", seed=1); Fr = p.denorm(F); o = np.argsort(Fr[:, 0]); k = len(o)
r["profiles"] = {nm: dict(risk=float(Fr[o[int(q * (k - 1))], 0]), ret=float(-Fr[o[int(q * (k - 1))], 1]), w=(X[o[int(q * (k - 1))]] / X[o[int(q * (k - 1))]].sum()).round(3).tolist()) for nm, q in (("conservative(min-risk end)", 0.0), ("conservative-balanced", 0.25), ("balanced", 0.5), ("aggressive-balanced", 0.75), ("aggressive(max-return end)", 1.0))}
out["P4"] = r

# ---------------- P5 infeasible fraction, ignoring stress
p5 = mkprob("P5"); rng = np.random.default_rng(0); S = p5.lb + rng.random((100000, 2)) * (p5.ub - p5.lb)
F5, CV5 = p5.evaluate(S); r = dict(infeasible_fraction=float((CV5 > 0).mean()))
class P5nc(P.P5):
    def evaluate(self, X): F, CV = super().evaluate(X); return F, CV * 0
pn = P5nc(); a = NSGA2(pn, seed=1); X, F = a.run(10000); Fu = pn.denorm(F); _, cv = p5.evaluate(X)
r["no_stress_front"] = dict(n=int(len(F)), frac_violating_stress=float((cv > 0).mean()), min_mass=float(Fu[:, 0].min()), min_deflection=float(Fu[:, 1].min()),
                            HV_ignoring=float(U.hypervolume(F, p5.ref_hv)))
X2, F2, t, n = run_pop(21, "P5", seed=1); Fc = p5.denorm(F2); r["with_stress_front"] = dict(n=int(len(F2)), min_mass=float(Fc[:, 0].min()), min_deflection=float(Fc[:, 1].min()), HV=float(U.hypervolume(F2, p5.ref_hv)))
r["sanity"] = dict(zip(("mass", "defl"), p5.evaluate(np.array([[0.01, 0.05]]))[0][0].tolist()), stress_MPa=6 * 1000 / (0.01 * 0.05 ** 2) / 1e6)
out["P5"] = r

# ---------------- P6 Deb's rules by hand on four candidates + with/without rules
p6 = mkprob("P6"); cand = np.array([[1.0, 1.0], [3.0, 2.9], [4.9, 2.9], [0.5, 0.5]]); Fc, CVc = p6.evaluate(cand)
# make two of them infeasible by moving into the excluded disc / outside circle
cand = np.array([[0.5, 0.5], [3.0, 2.9], [5.0, 3.0], [2.0, 2.0]]); Fc, CVc = p6.evaluate(cand)
cand2 = np.array([[3.0, 0.1], [4.9, 0.2], [0.5, 0.5], [2.5, 2.5]]); Fc2, CVc2 = p6.evaluate(cand2)
r = dict(cand=cand2.tolist(), F=Fc2.tolist(), CV=CVc2.tolist())
pairs = {}
for i in range(4):
    for j in range(i + 1, 4):
        pairs["%d-%d" % (i, j)] = "%d wins" % i if U.constrained_dominates(Fc2[i], CVc2[i], Fc2[j], CVc2[j]) else ("%d wins" % j if U.constrained_dominates(Fc2[j], CVc2[j], Fc2[i], CVc2[i]) else "incomparable")
r["pairs"] = pairs
rows_i = []; rows_d = []
for s in range(1, 6):
    a = NSGA2(p6, seed=s, cmode="ignore"); X, F = a.run(10000); rows_i.append((float((a.CV <= 0).mean()), len(F)))
    b = ConstrainedNSGA2(p6, seed=s); X, F = b.run(10000); rows_d.append((float((b.CV <= 0).mean()), len(F)))
r["ignore"] = dict(final_pop_feasible=ms([x[0] for x in rows_i]), nd_points=ms([x[1] for x in rows_i]))
r["deb"] = dict(final_pop_feasible=ms([x[0] for x in rows_d]), nd_points=ms([x[1] for x in rows_d]))
out["P6"] = r

# ---------------- P7 line + decision maker (40,50)
p7 = mkprob("P7"); X, F, t, n = run_pop(21, "P7", seed=1); Xr = X
r = dict(max_line_dev=float(np.abs(Xr.sum(1) - 90).max()), n=int(len(X)))
tf = p7.true_front(); ref = p7.pref_point; d = np.linalg.norm(p7.norm(tf) - p7.norm(ref), axis=1); r["closest_front_x1"] = float(10 + 60 * np.argmin(d) / 299); r["closest_dist"] = float(d.min())
a = RNSGA2(p7, seed=1, refs=p7.norm(ref)[None, :]); X2, F2 = a.run(10000); x1 = X2[:, 0]
r["rnsga_x1_quartiles"] = np.percentile(x1, [0, 25, 50, 75, 100]).round(2).tolist(); r["nsga2_x1_quartiles"] = np.percentile(Xr[:, 0], [0, 25, 50, 75, 100]).round(2).tolist()
out["P7"] = r

# ---------------- P8 operators, NN tours
p8 = mkprob("P8"); r = {}
nnd = p8.nearest_neighbour(p8.D); nnt = p8.nearest_neighbour(p8.T)
r["nn_dist_tour"] = [p8.length(p8.D, nnd), p8.length(p8.T, nnd)]; r["nn_time_tour"] = [p8.length(p8.D, nnt), p8.length(p8.T, nnt)]
r["opt2_dist_tour"] = [p8.length(p8.D, p8.tour_d), p8.length(p8.T, p8.tour_d)]; r["opt2_time_tour"] = [p8.length(p8.D, p8.tour_t), p8.length(p8.T, p8.tour_t)]
rr = np.random.default_rng(0); rt = np.array([rr.permutation(15) for _ in range(2000)]); Fr, _ = p8.evaluate(rt); r["random_mean"] = Fr.mean(0).tolist()
edges = lambda t: {frozenset((int(t[i]), int(t[(i + 1) % 15]))) for i in range(15)}
ed, et = edges(p8.tour_d), edges(p8.tour_t); r["edge_overlap_jaccard"] = len(ed & et) / len(ed | et)
r["xy"] = p8.xy.round(3).tolist()
class OpVar(PermOps):
    def __init__(s, p, xo=True, mut="both"): super().__init__(p); s.xo, s.mut = xo, mut
    def variate(s, P_, rng):
        N = len(P_); P_ = np.vstack([P_, P_[:1]]) if N % 2 else P_; C = P_.copy()
        if s.xo:
            for k in range(0, len(P_), 2):
                C[k] = order_crossover(P_[k], P_[k + 1], rng); C[k + 1] = order_crossover(P_[k + 1], P_[k], rng)
        return s.mutate(C, rng)[:N]
    def mutate(s, X, rng, scale=None):
        o = []
        for t in X:
            t = t.copy()
            if s.mut in ("inv", "both") and rng.random() < (0.5 if s.mut == "inv" else 0.3):
                i, j = sorted(rng.choice(15, 2, replace=False)); t[i:j + 1] = t[i:j + 1][::-1]
            if s.mut in ("swap", "both") and rng.random() < (0.5 if s.mut == "swap" else 0.15):
                i, j = rng.choice(15, 2, replace=False); t[i], t[j] = t[j], t[i]
            o.append(t)
        return np.array(o)
ops_res = {}
for name, kw in (("OX + inversion + swap", dict(xo=True, mut="both")), ("OX + inversion", dict(xo=True, mut="inv")), ("OX + swap", dict(xo=True, mut="swap")),
                 ("inversion only (no crossover)", dict(xo=False, mut="inv")), ("OX only (no mutation)", dict(xo=True, mut="none"))):
    v = []
    for s in range(1, 6):
        a = NSGA2(p8, seed=s); a.ops = OpVar(p8, **kw); X, F = a.run(10000); v.append(U.hypervolume(F, p8.ref_hv))
    ops_res[name] = ms(v)
r["operators_HV"] = ops_res
# naive one-point crossover on permutations produces invalid tours:
a_, b_ = rr.permutation(15), rr.permutation(15); c_ = np.r_[a_[:7], b_[7:]]; r["one_point_invalid"] = bool(len(set(c_.tolist())) < 15)
out["P8"] = r; print("P8 done"); sys.stdout.flush()

# ---------------- P9 feature selection with NSGA-II (native binary), 3 seeds, 3000 evals each
p9 = mkprob("P9"); allF, _ = p9.evaluate(np.ones((1, 30), int)); base = float(allF[0, 0]); sols = []
for s in (1, 2, 3):
    a = NSGA2(p9, pop=60, seed=s, cmode="penalty"); X, F = a.run(3000); sols.append((X, p9.denorm(F)))
Xa = np.vstack([s[0] for s in sols]); Fa = np.vstack([s[1] for s in sols]); m = U.nondominated_mask(Fa); Xa, Fa = Xa[m], Fa[m]
r = dict(baseline_error=base, baseline_acc=1 - base, front=[[int(f[1]), float(f[0])] for f in Fa[np.argsort(Fa[:, 1])]])
ok = Fa[:, 0] <= base + 0.01; i = np.where(ok)[0]; best = i[np.argmin(Fa[i, 1])]
r["smallest_within_1pp"] = dict(k=int(Fa[best, 1]), error=float(Fa[best, 0]), features=[p9.names[j] for j in np.where(Xa[best] == 1)[0]])
freq = Xa.mean(0); o = np.argsort(-freq)[:8]; r["top_features"] = [(p9.names[j], float(freq[j])) for j in o]; r["n_front"] = int(len(Fa))
out["P9"] = r; print("P9 done"); sys.stdout.flush()

# ---------------- P10 non-dominated fraction of random populations
r = {}
for M in (3, 5, 8):
    p = P.P10(M); fr = []
    for s in range(30):
        Xr_ = np.random.default_rng(s).random((100, p.n_var)); F, _ = p.evaluate(Xr_); fr.append(U.nondominated_mask(F).mean())
    r["M%d" % M] = ms(fr)
    # also uniformly random objective vectors (worst-case intuition)
    fr2 = [U.nondominated_mask(np.random.default_rng(s).random((100, M))).mean() for s in range(30)]; r["rand_obj_M%d" % M] = ms(fr2)
out["P10"] = r

# ---------------- P14 x1 = 13, reference point vs front
p14 = mkprob("P14"); r = {}
X, F, t, n = run_pop(14, "P14", seed=1); r["nsga2_frac_x1_13"] = float((np.abs(X[:, 0] - 13) < 0.05).mean()); r["nsga2_x1_max"] = float(X[:, 0].max())
tf = p14.true_front(); dom_ref = bool(any(U.dominates(f, p14.pref_point) for f in tf)); r["front_dominates_ref"] = dom_ref
w = tf[:, 0]; r["front_weight_at_runtime12"] = float(w[np.argmin(np.abs(-tf[:, 1] - 12))])
a = RNSGA2(p14, seed=1, eps=0.02); X2, F2 = a.run(10000); F2r = p14.denorm(F2); Fn_r = p14.denorm(F)
r["rnsga_weight_quartiles"] = np.percentile(F2r[:, 0], [0, 25, 50, 75, 100]).round(3).tolist(); r["nsga2_weight_quartiles"] = np.percentile(Fn_r[:, 0], [0, 25, 50, 75, 100]).round(3).tolist()
near = lambda Fr_: float(((Fr_[:, 0] > 1.65) & (Fr_[:, 0] < 1.95)).mean())
r["frac_within_0.15kg_rnsga"] = near(F2r); r["frac_within_0.15kg_nsga2"] = near(Fn_r)
out["P14"] = r

# ---------------- viva evidence: HV vs generation (premature convergence, VEGA collapse)
hist = {}
for aid, key in ((14, "P3"), (10, "P3"), (27, "P3"), (19, "P3"), (23, "P3")):
    p = mkprob(key); a = POP[aid](p, seed=1); a.initialize(); a.max_iters = 10000 // a.cost() - 1; h = []; g = 0
    while a.nfe + a.cost() <= 10000:
        a.iterate(); g += 1
        if g % 5 == 0:
            X_, F_, CV_ = a.final_set(); m_ = U.nondominated_mask(F_, CV_); h.append((g, float(U.hypervolume(F_[m_], p.ref_hv)) if m_.any() else 0.0))
    hist[NAMES[aid]] = h
out["hv_history_P3"] = hist
json.dump(out, open(os.path.join(DAT, "extras.json"), "w"), indent=1, default=float)
print("saved")
