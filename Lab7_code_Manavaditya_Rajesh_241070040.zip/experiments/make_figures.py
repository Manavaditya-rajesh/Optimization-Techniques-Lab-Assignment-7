"""All figures for the report (reads outputs/data/*.json|npz)."""
from common import *
from matplotlib.patches import FancyBboxPatch
A = json.load(open(os.path.join(DAT, "taskA.json"))); AF = np.load(os.path.join(DAT, "taskA_fronts.npz"))
D = json.load(open(os.path.join(DAT, "taskD.json"))); DF = np.load(os.path.join(DAT, "taskD_fronts.npz"))
C = json.load(open(os.path.join(DAT, "taskC.json"))); E = json.load(open(os.path.join(DAT, "extras.json")))
plt.rcParams.update({"font.size": 8, "axes.titlesize": 8})
def save(fig, name): fig.tight_layout(); fig.savefig(os.path.join(FIG, name), dpi=110); plt.close(fig)

# ---------------------------------------------------------------- Task A per-algorithm figures
for aid in range(1, 38):
    keys = TEST[aid]; fig, axs = plt.subplots(1, len(keys), figsize=(3.3 * len(keys), 2.9)); axs = np.atleast_1d(axs)
    for ax, key in zip(axs, keys):
        title = "%s on %s" % (NAMES[aid], key)
        try:
            if aid in (1, 2, 3, 4) or aid in POP:
                F = AF["a%d_%s" % (aid, key)]; plot_front(ax, key, F, label=NAMES[aid]); m = A[str(aid)][key]
                ax.set_title("%s | %s\nHV %.3f  SP %.4f  IGD %s" % (NAMES[aid], key, m["HV"], m["SP"], "%.4f" % m["IGD"] if m["IGD"] is not None else "n/a"), fontsize=7)
                ax.legend(fontsize=6)
            elif aid == 5:
                p = mkprob(key); tf = p.true_front(); o = np.argsort(tf[:, 0]); ax.plot(tf[o, 0], tf[o, 1], "k-", lw=1, label="front")
                for nm, v in A["5"][key]["profiles"].items():
                    f = v["f_raw"]; ax.scatter(f[0], f[1], s=40, label="%s a=%s" % (nm, v["alpha"]))
                ax.set_title("Value function profiles | %s" % key, fontsize=7); ax.legend(fontsize=5); ax.set_xlabel("f1 (min form)"); ax.set_ylabel("f2 (min form)")
            elif aid in (6, 7):
                if key == "P11":
                    poly = np.array([[0, 0], [400, 0], [300, 200], [0, 400]]); ax.fill(poly[:, 0], poly[:, 1], alpha=.2); ax.plot(*poly[[0, 1, 2, 3, 0]].T, "k-")
                    d = A[str(aid)]
                    pts = {"GP unit": d["P11_unit"]["x"], "GP norm": d["P11_norm"]["x"], "GP units-first": d["P11_unitsfirst"]["x"]} if aid == 6 else {"profit>units": d["P11_tol0.00"]["x"], "units first": d["P11_units_first"]["x"]}
                    for nm, x in pts.items(): ax.scatter(x[0], x[1], s=45, label=nm)
                    ax.set_xlabel("xA"); ax.set_ylabel("xB"); ax.set_title("%s | P11 feasible region" % NAMES[aid], fontsize=7); ax.legend(fontsize=6)
                else:
                    x1 = np.linspace(10, 70, 50); ax.plot(x1, 90 - x1, "k-"); ax.set_xlabel("x1 agriculture"); ax.set_ylabel("x2 industry"); d = A[str(aid)]
                    pts = {"goal (40,50)": d["P7_goal(40,50)"]["x"], "unreachable goal": d["P7_goal_unreachable(75,92)"]["x"]} if aid == 6 else {"yield first": d["P7_yield_first"]["x"], "industry first": d["P7_industry_first"]["x"], "yield, tol 10%": d["P7_yield_first_tol0.10"]["x"]}
                    for nm, x in pts.items(): ax.scatter(x[0], x[1], s=45, label=nm)
                    ax.set_title("%s | P7 efficient line" % NAMES[aid], fontsize=7); ax.legend(fontsize=6)
            elif aid in (8, 9):
                if key == "P12":
                    if aid == 8: ax.bar(SUPPLIERS, A["8"]["topsis"]); ax.set_title("TOPSIS closeness C (higher better)", fontsize=7)
                    else:
                        w = .25
                        for k, v in enumerate((0.25, 0.5, 0.75)): ax.bar(np.arange(5) + (k - 1) * w, A["9"]["v=%.2f" % v]["Q"], w, label="v=%.2f" % v)
                        ax.set_xticks(range(5)); ax.set_xticklabels(SUPPLIERS); ax.legend(fontsize=6); ax.set_title("VIKOR Q (lower better)", fontsize=7)
                else:
                    p = mkprob("P4"); F = AF["a14_P3"][:0]; X, Fn, _, _ = run_pop(14, "P4", seed=1); Fr = p.denorm(Fn)
                    ax.scatter(Fr[:, 0], -Fr[:, 1], s=8, c="lightgray")
                    for t3 in A[str(aid)]["P4_front"]["top3"]: ax.scatter(t3["risk"], t3["ret"], s=55)
                    ax.set_xlabel("risk"); ax.set_ylabel("return"); ax.set_title("%s: top-3 on NSGA-II front of P4" % NAMES[aid], fontsize=7)
            elif aid in (36, 37):
                R = A["36_37"]; ms = ("equal", "mgda") if aid == 36 else ("equal", "gradnorm")
                for m in ms:
                    L = np.array(R["toy_" + m]["L"]); ax.plot(L[:, 0], L[:, 1], label=m)
                ax.set_xlabel("f1"); ax.set_ylabel("f2"); ax.set_title("P13a: loss trajectory (equal vs %s)" % ms[1], fontsize=7); ax.legend(fontsize=6)
        except Exception as e:
            ax.set_title("%s (plot error %s)" % (title, e), fontsize=6)
    if aid in (36, 37) :
        pass
    save(fig, "A_alg%02d.png" % aid)
# extra figure: P13b curves
fig, axs = plt.subplots(1, 2, figsize=(8, 3))
R = A["36_37"]
for ax, sc in zip(axs, ("1", "10")):
    for m, ls in (("equal", "-"), ("mgda", "--"), ("gradnorm", ":")):
        d = R["net_%s_scale%s" % (m, sc)]; L = np.array(d["L"]); L0 = np.array(d["L0"])
        ax.plot(L[:, 0] / L0[0], ls, c="C0", label="%s cls" % m); ax.plot(L[:, 1] / L0[1], ls, c="C3", label="%s reg" % m)
    ax.set_yscale("log"); ax.set_title("P13b: loss / initial loss (regression target x%s)" % sc); ax.set_xlabel("step"); ax.legend(fontsize=5, ncol=3)
save(fig, "A_p13b.png")

# ---------------------------------------------------------------- Task D
def grid(key, ids, fname):
    n = len(ids); cols = 6; rows = int(np.ceil(n / cols)); fig, axs = plt.subplots(rows, cols, figsize=(2.3 * cols, 2.1 * rows)); axs = axs.ravel()
    for ax, aid in zip(axs, ids):
        F = DF["%d_%s" % (aid, key)]; plot_front(ax, key, F, label=None); ax.set_title(NAMES[aid][:22], fontsize=6); ax.tick_params(labelsize=5); ax.set_xlabel(""); ax.set_ylabel("")
    for ax in axs[n:]: ax.axis("off")
    save(fig, fname)
ids = [1, 2, 4, 10, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24, 26, 27, 28, 29, 30, 32, 33, 35]
grid("P3", ids, "D1_P3_fronts.png"); grid("P5", ids, "D1_P5_fronts.png")
for key in ("P3", "P5"):
    rows = [(k.split("_")[-1], v) for k, v in D.items() if k.startswith("D1_%s_" % key)]; rows.sort(key=lambda r: -r[1]["HV"][0])
    fig, ax = plt.subplots(figsize=(8, 3.2)); ax.bar([NAMES[int(r[0])][:14] for r in rows], [r[1]["HV"][0] for r in rows], yerr=[r[1]["HV"][1] for r in rows], color="C0")
    ax.set_ylim(min(r[1]["HV"][0] for r in rows) * 0.9 if key == "P3" else 1.1, None); plt.xticks(rotation=70); ax.set_title("D1 %s: mean HV (10 seeds, error bar = std)" % key); save(fig, "D1_%s_hv.png" % key)
fig, axs = plt.subplots(1, 2, figsize=(7.5, 3))
for ax, (key, ids_) in zip(axs, (("D2", (14, 15, 18, 31, 34)), ("D3", (20, 25, 14, 30)))):
    nm = [NAMES[i] for i in ids_]; v = [D["%s_%d" % (key, i)]["HV"][0] for i in ids_]; e = [D["%s_%d" % (key, i)]["HV"][1] for i in ids_]
    ax.bar(nm, v, yerr=e); ax.set_title("%s: HV, 10 seeds" % ("D2 P10 M=5" if key == "D2" else "D3 P8 TSP")); plt.setp(ax.get_xticklabels(), rotation=30)
save(fig, "D23_hv.png")
fig, ax = plt.subplots(figsize=(4.5, 3.4))
for i in (20, 25, 14, 30):
    F = DF["%d_P8" % i]; R = mkprob("P8").denorm(F); ax.scatter(R[:, 0], R[:, 1], s=14, label=NAMES[i])
ax.set_xlabel("total distance"); ax.set_ylabel("total time"); ax.legend(fontsize=6); ax.set_title("P8 fronts, seed 1"); save(fig, "D3_P8_fronts.png")

# ---------------------------------------------------------------- Task C figures
p3 = mkprob("P3"); fig, axs = plt.subplots(1, 3, figsize=(9, 2.8))
for ax, d in zip(axs, (0.02, 0.2, 0.6)):
    r = benson(p3, [np.array([t, 1 - t]) + d for t in np.linspace(0, 1, 15)], seed=1); F = np.array([f for _, _, f, _ in r])
    tf = p3.true_front(); ax.plot(tf[:, 0], tf[:, 1], "k-", lw=1); ax.plot(np.linspace(0, 1, 5), 1 - np.linspace(0, 1, 5), "g--", lw=.8)
    ax.scatter(F[:, 0], F[:, 1], s=14); ax.set_title("Benson z=(t,1-t)+%.2f  (%d points)" % (d, len(F))); ax.set_xlabel("f1"); ax.set_ylabel("f2")
save(fig, "C_benson_sens.png")
fig, axs = plt.subplots(1, 2, figsize=(7, 2.8)); s = C["nsga3_sens"]
axs[0].bar(["H=%s\n(N=%d)" % (h, s[h]["pop"]) for h in s], [s[h]["IGD"][0] for h in s], yerr=[s[h]["IGD"][1] for h in s]); axs[0].set_title("NSGA-III on DTLZ2 M=3: IGD vs divisions H")
axs[1].bar(["H=%s" % h for h in s], [s[h]["HV"][0] for h in s], yerr=[s[h]["HV"][1] for h in s]); axs[1].set_title("HV vs divisions H"); axs[1].set_ylim(0.5, 0.7)
save(fig, "C_nsga3_sens.png")
fig, axs = plt.subplots(1, 2, figsize=(7, 2.8)); s = C["mode_sens"]
for ax, key in zip(axs, ("P3", "P5")):
    ks = [k for k in s if k.startswith(key)]; ax.bar([k.split("_")[1] for k in ks], [s[k]["IGD"][0] for k in ks], yerr=[s[k]["IGD"][1] for k in ks]); ax.set_title("MODE on %s: IGD vs scale factor F" % key)
save(fig, "C_mode_sens.png")
# flow diagrams for the study cards
def flow(steps, fname, w=9):
    fig, ax = plt.subplots(figsize=(w, 1.4)); ax.axis("off"); n = len(steps); bw = 0.9 / n
    for i, s in enumerate(steps):
        x = 0.05 * 0.5 + i * (0.95 / n)
        ax.add_patch(FancyBboxPatch((x, 0.2), 0.95 / n - 0.015, 0.6, boxstyle="round,pad=0.01", fc="#e8f0fe", ec="#345", transform=ax.transAxes))
        ax.text(x + (0.95 / n - 0.015) / 2, 0.5, s, ha="center", va="center", fontsize=6.5, transform=ax.transAxes, wrap=True)
        if i < n - 1: ax.annotate("", xy=(x + 0.95 / n, 0.5), xytext=(x + 0.95 / n - 0.018, 0.5), xycoords="axes fraction", arrowprops=dict(arrowstyle="->"))
    save(fig, fname)
flow(["pick reference\npoint z (attainable)", "choose weights w", "max sum w_i l_i\ns.t. f_i(x)+l_i=z_i", "l_i >= 0\nx feasible", "Pareto-optimal x\n(improves on z)", "sweep z -> front"], "flow_benson.png")
flow(["random P0 (N)", "random mating ->\nSBX+PM -> Q", "R = P u Q\nnon-dominated sort", "normalise\n(ideal, intercepts)", "associate to\nreference lines", "niche-count\nfilling of last front", "next P (N)"], "flow_nsga3.png")
flow(["random P0 (N)", "DE/rand/1:\nv = x_r1+F(x_r2-x_r3)", "binomial crossover\n(CR, j_rand) -> u", "evaluate u", "u replaces x only\nif u dominates x", "archive of\nnon-dominated", "repeat"], "flow_mode.png")

# ---------------------------------------------------------------- extras figures
g = E["P3_igd_grid"]; pops = (20, 50, 100, 200); gens = (25, 50, 100, 200)
M_ = np.array([[g["%d_%d" % (p, q)] for q in gens] for p in pops]); fig, ax = plt.subplots(figsize=(4, 3)); im = ax.imshow(np.log10(M_), cmap="viridis_r")
ax.set_xticks(range(4)); ax.set_xticklabels(gens); ax.set_yticks(range(4)); ax.set_yticklabels(pops); ax.set_xlabel("generations"); ax.set_ylabel("population")
for i in range(4):
    for j in range(4): ax.text(j, i, "%.3f" % M_[i, j], ha="center", va="center", color="w", fontsize=6)
ax.set_title("P3 NSGA-II mean IGD (3 seeds)"); save(fig, "E_p3_igd_grid.png")
fig, ax = plt.subplots(figsize=(5, 3))
for k, h in E["hv_history_P3"].items(): ax.plot(*zip(*h), label=k)
ax.set_xlabel("generation"); ax.set_ylabel("HV of non-dominated set"); ax.set_title("P3: HV vs generation (seed 1)"); ax.legend(fontsize=6); save(fig, "E_hv_history.png")
p8 = mkprob("P8"); fig, axs = plt.subplots(1, 2, figsize=(7, 3))
for ax, t, nm in zip(axs, (p8.tour_d, p8.tour_t), ("shortest-distance tour (2-opt)", "shortest-time tour (2-opt)")):
    tt = np.r_[t, t[0]]; ax.plot(p8.xy[tt, 0], p8.xy[tt, 1], "-o", ms=3); ax.set_title(nm)
    for i, (x, y) in enumerate(p8.xy): ax.text(x + 1, y + 1, str(i), fontsize=5)
save(fig, "E_p8_tours.png")
r = E["P9"]; fig, ax = plt.subplots(figsize=(4.2, 3)); fr = np.array(r["front"]); ax.step(fr[:, 0], fr[:, 1], where="post", marker="o", ms=3); ax.axhline(r["baseline_error"], c="r", ls="--", lw=.8, label="all-ones baseline")
ax.axhline(r["baseline_error"] + 0.01, c="gray", ls=":", lw=.8, label="baseline+1pp"); ax.set_xlabel("# features"); ax.set_ylabel("5-fold CV error"); ax.legend(fontsize=6); ax.set_title("P9 NSGA-II front"); save(fig, "E_p9_front.png")
p14 = mkprob("P14"); fig, ax = plt.subplots(figsize=(4.2, 3)); tf = p14.true_front(); ax.plot(tf[:, 0], -tf[:, 1], "k-")
X, F, t, n = run_pop(14, "P14", seed=1); Fr = p14.denorm(F); ax.scatter(Fr[:, 0], -Fr[:, 1], s=8, label="NSGA-II")
a = RNSGA2(p14, seed=1, eps=0.02); X2, F2 = a.run(10000); F2r = p14.denorm(F2); ax.scatter(F2r[:, 0], -F2r[:, 1], s=8, label="R-NSGA-II"); ax.scatter(1.8, 12, marker="*", s=90, c="r", label="reference (1.8 kg, 12 h)")
ax.set_xlabel("weight (kg)"); ax.set_ylabel("runtime (h)"); ax.legend(fontsize=6); ax.set_title("P14 preference focus"); save(fig, "E_p14.png")
print("figures done")
