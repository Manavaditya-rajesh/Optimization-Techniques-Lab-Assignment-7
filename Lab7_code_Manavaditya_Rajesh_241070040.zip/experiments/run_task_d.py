"""Task D: head-to-head, 10 seeds, equal budget (10,000 evaluations)."""
from common import *
SEEDS = list(range(1, 11)); EV = 10000
import pickle
CK = os.path.join(DAT, "taskD_ckpt.pkl")
out, fr = pickle.load(open(CK, "rb")) if os.path.exists(CK) else ({}, {})
def ck(): pickle.dump((out, fr), open(CK, "wb"))
D1 = [10, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24, 26, 27, 28, 29, 30, 32, 33, 35]
def agg(rows):
    d = {}
    for k in ("HV", "SP", "IGD", "n"):
        v = [r[k] for r in rows if r.get(k) is not None]
        d[k] = (float(np.mean(v)), float(np.std(v))) if v else None
    return d
# D1 continuous bi-objective
for key in ("P3", "P5"):
    for aid in D1 + [1, 2, 4]:
        if "D1_%s_%d" % (key, aid) in out: continue
        rows = []
        if aid in (1, 2, 4):
            F = classical_front(aid, key); m = metrics(key, F); rows = [m]; fr["%d_%s" % (aid, key)] = F
        else:
            for s in SEEDS:
                X, F, t, nfe = run_pop(aid, key, seed=s, evals=EV); m = metrics(key, F); m["time"] = t; rows.append(m)
                if s == 1: fr["%d_%s" % (aid, key)] = F
        out["D1_%s_%d" % (key, aid)] = dict(name=NAMES[aid], **agg(rows), time=float(np.mean([r.get("time", 0) for r in rows])))
        print(key, aid, NAMES[aid], {k: v for k, v in out["D1_%s_%d" % (key, aid)].items() if k in ("HV", "IGD")}); sys.stdout.flush(); ck()
# D2 many-objective M=5
for aid in (14, 15, 18, 31, 34):
    if "D2_%d" % aid in out: continue
    rows = []
    for s in SEEDS:
        X, F, t, nfe = run_pop(aid, "P10_5", seed=s, evals=EV); m = metrics("P10_5", F); m["time"] = t; rows.append(m)
        nd = None
        if s == 1:
            fr["%d_P10_5" % aid] = F
    out["D2_%d" % aid] = dict(name=NAMES[aid], **agg(rows), time=float(np.mean([r["time"] for r in rows])))
    print("P10_5", aid, out["D2_%d" % aid]); sys.stdout.flush(); ck()
# D3 discrete TSP
for aid in (20, 25, 14, 30):
    if "D3_%d" % aid in out: continue
    rows = []
    for s in SEEDS:
        X, F, t, nfe = run_pop(aid, "P8", seed=s, evals=EV); m = metrics("P8", F); m["time"] = t; rows.append(m)
        if s == 1: fr["%d_P8" % aid] = F
    out["D3_%d" % aid] = dict(name=NAMES[aid], **agg(rows), time=float(np.mean([r["time"] for r in rows])))
    print("P8", aid, out["D3_%d" % aid]); sys.stdout.flush(); ck()
json.dump(out, open(os.path.join(DAT, "taskD.json"), "w"), indent=1)
np.savez_compressed(os.path.join(DAT, "taskD_fronts.npz"), **fr)
print("saved")
