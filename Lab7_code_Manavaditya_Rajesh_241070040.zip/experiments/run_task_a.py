"""Task A: run each of the 37 algorithms (seed 1, 10,000 evaluations) on its catalogue problems; metrics, plots, log."""
from common import *
from moo.a08_mcdm import *
from moo.a36_gradient import *

SEED = 1; EV = 10000
res = {}; fronts = {}

def rec(aid, key, F, t, nfe, extra=None):
    m = metrics(key, F); m.update(time=t, nfe=int(nfe)); 
    if extra: m.update(extra)
    res.setdefault(str(aid), {})[key] = m; fronts["a%d_%s" % (aid, key)] = np.asarray(F)

# ---- classical front builders (1-4)
for aid in (1, 2, 3, 4):
    for key in TEST[aid]:
        t = time.time(); F = classical_front(aid, key); rec(aid, key, F, time.time() - t, 0)
        print(aid, key, res[str(aid)][key]); sys.stdout.flush()

# ---- 5 value function: investor / manager profiles
prof = {"P4": {"conservative": (2.0, 1.0), "balanced": (1.0, 1.0), "aggressive": (1.0, 2.0)},
        "P14": {"light-first": (2.0, 1.0), "balanced": (1.0, 1.0), "endurance-first": (1.0, 2.0)}}
for key in TEST[5]:
    p = mkprob(key); names = list(prof[key]); r = value_function(p, [prof[key][n] for n in names]); t = time.time()
    F = np.array([f for _, _, f in r]); rec(5, key, F, 0, 0, {"profiles": {n: {"alpha": list(prof[key][n]), "x": x.tolist(), "f_raw": p.denorm(f).tolist()} for n, (a, x, f) in zip(names, r)}})
    print(5, key, res["5"][key]["profiles"]); sys.stdout.flush()

# ---- 6, 7 on P11 and P7
C7 = np.array([[0.8, 0], [0, 1.2]]); A7 = np.array([[1., 1.]]); b7 = np.array([90.]); lb7 = [10, 20]
gp = {}
x, dm, dp, obj = goal_programming(np.array([2400., 600.]), np.zeros(2), np.ones(2)); gp["P11_unit"] = dict(x=x.tolist(), d_minus=dm.tolist(), obj=obj)
x, dm, dp, obj = goal_programming(np.array([2400., 600.]), np.zeros(2), 1 / np.array([2400., 600.])); gp["P11_norm"] = dict(x=x.tolist(), d_minus=dm.tolist(), obj=obj)
x, dm, dp, obj = goal_programming(np.array([2400., 600.]), np.zeros(2), np.array([1.0, 10.0])); gp["P11_unitsfirst"] = dict(x=x.tolist(), d_minus=dm.tolist(), obj=obj)
x, dm, dp, obj = goal_programming(np.array([32., 60.]), np.zeros(2), np.ones(2), C=C7, A=A7, b=b7, lb=lb7); gp["P7_goal(40,50)"] = dict(x=x.tolist(), d_minus=dm.tolist(), obj=obj)
x, dm, dp, obj = goal_programming(np.array([60., 110.]), np.zeros(2), np.ones(2), C=C7, A=A7, b=b7, lb=lb7); gp["P7_goal_unreachable(75,92)"] = dict(x=x.tolist(), d_minus=dm.tolist(), obj=obj)
lx = {}
for tol in (0.0, 0.05):
    x, log = lexicographic(tol=tol); lx["P11_tol%.2f" % tol] = dict(x=x.tolist(), log=[(o, v, xx.tolist()) for o, v, xx in log])
x, log = lexicographic(order=(1, 0)); lx["P11_units_first"] = dict(x=x.tolist(), log=[(o, v, xx.tolist()) for o, v, xx in log])
x, log = lexicographic(C=C7, A=A7, b=b7, lb=lb7, order=(0, 1)); lx["P7_yield_first"] = dict(x=x.tolist())
x, log = lexicographic(C=C7, A=A7, b=b7, lb=lb7, order=(1, 0)); lx["P7_industry_first"] = dict(x=x.tolist())
x, log = lexicographic(C=C7, A=A7, b=b7, lb=lb7, order=(0, 1), tol=0.1); lx["P7_yield_first_tol0.10"] = dict(x=x.tolist())
res["6"] = gp; res["7"] = lx

# ---- 8, 9 on P12 and the NSGA-II front of P4
D, W, B = P12_DATA, P12_W, P12_BENEFIT
Dm = np.where(B, -D, D)
pareto = [i for i in range(5) if not any(U.dominates(Dm[j], Dm[i]) for j in range(5) if j != i)]
rk = lambda s, hi=True: [SUPPLIERS[i] for i in (np.argsort(-s) if hi else np.argsort(s))]
ts = topsis(D, W, B)[0]; w2 = W.copy(); w2[0] -= 0.1; w2[1] += 0.1
ts2 = topsis(D, w2, B)[0]
r8 = {"pareto_optimal": [SUPPLIERS[i] for i in pareto], "topsis": ts.tolist(), "topsis_rank": rk(ts), "topsis_shift_rank": rk(ts2), "w_shift": w2.tolist()}
r9 = {"pareto_optimal": r8["pareto_optimal"]}
for v in (0.25, 0.5, 0.75):
    Q, S, R, adv = vikor(D, W, B, v); Q2 = vikor(D, w2, B, v)[0]
    r9["v=%.2f" % v] = dict(Q=Q.tolist(), S=S.tolist(), R=R.tolist(), rank=rk(Q, False), advantage=adv, shift_rank=rk(Q2, False))
r9["S"] = vikor(D, W, B, .5)[1].tolist(); r9["R"] = vikor(D, W, B, .5)[2].tolist()
# one very bad criterion test: S2 made terrible on cost
D3 = D.copy(); D3[2, 0] = 400; r8["bad_criterion_topsis"] = rk(topsis(D3, W, B)[0]); r9["bad_criterion_vikor_v0"] = rk(vikor(D3, W, B, 0.0)[0], False)
p4 = mkprob("P4"); Xn, Fn, _, _ = run_pop(14, "P4", seed=SEED)
Fr = p4.denorm(Fn); Dp = np.c_[Fr[:, 0], -Fr[:, 1]]                  # risk (cost), return (benefit)
wp = np.array([0.5, 0.5]); bp = np.array([False, True]); wp2 = np.array([0.6, 0.4])
t4 = topsis(Dp, wp, bp)[0]; t42 = topsis(Dp, wp2, bp)[0]; v4 = vikor(Dp, wp, bp, .5)[0]; v42 = vikor(Dp, wp2, bp, .5)[0]
def top3(s, hi): o = np.argsort(-s if hi else s)[:3]; return [dict(idx=int(i), risk=float(Dp[i, 0]), ret=float(Dp[i, 1]), w=(Xn[i] / Xn[i].sum()).round(3).tolist()) for i in o]
r8["P4_front"] = dict(n=int(len(Fn)), top3=top3(t4, True), top3_shift=top3(t42, True), flips=bool(np.argmax(t4) != np.argmax(t42)))
r9["P4_front"] = dict(top3=top3(v4, False), top3_shift=top3(v42, False), flips=bool(np.argmin(v4) != np.argmin(v42)))
res["8"] = r8; res["9"] = r9
print("8", r8["topsis_rank"], r8["topsis_shift_rank"], "9", {k: r9[k]["rank"] for k in r9 if k.startswith("v=")}); sys.stdout.flush()

# ---- 10-35 population algorithms
for aid in sorted(POP):
    for key in TEST[aid]:
        X, F, t, nfe = run_pop(aid, key, seed=SEED, evals=EV)
        rec(aid, key, F, t, nfe)
        print(aid, NAMES[aid], key, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in res[str(aid)][key].items()}); sys.stdout.flush()

# ---- 36, 37 on P13
r36 = {}
for m in ("equal", "mgda", "gradnorm"):
    h = run_toy(m); r36["toy_" + m] = dict(final_x=h[-1][0].tolist(), final_L=h[-1][1].tolist(), w=h[-1][2].tolist(), path=[hh[0].tolist() for hh in h[::5]], L=[hh[1].tolist() for hh in h])
    for sc, lr in ((1.0, 0.05), (10.0, 0.01)):
        hist, L0 = run_net(m, scale_reg=sc, lr=lr)
        r36["net_%s_scale%g" % (m, sc)] = dict(L0=L0.tolist(), L=[hh[0].tolist() for hh in hist], w=[hh[1].tolist() for hh in hist])
res["36_37"] = r36
json.dump(res, open(os.path.join(DAT, "taskA.json"), "w"), indent=1, default=float)
np.savez_compressed(os.path.join(DAT, "taskA_fronts.npz"), **fronts)
print("saved")
