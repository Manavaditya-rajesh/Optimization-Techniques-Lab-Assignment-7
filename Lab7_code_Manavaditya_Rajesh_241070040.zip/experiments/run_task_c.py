"""Task C: hand traces (Benson, NSGA-III, MODE) reproduced by code + sensitivity studies (3 values x 10 seeds)."""
from common import *
import math
out = {}
SKIP = os.environ.get('SKIP_SENS'); prev = json.load(open(os.path.join(DAT, 'taskC.json'))) if SKIP else {}

# ============================================================ (1) Benson (3) trace on P1
# min f1=(x-3)^2, f2=(x-7)^2 ; setting A: z=(10,8) w=(1,1) ; setting B: z=(2,20) w=(1,1)
def benson_hand(z):
    """Closed form: maximise l1+l2 = z1+z2-[(x-3)^2+(x-7)^2] with l>=0  <=> minimise S(x)=(x-3)^2+(x-7)^2
    s.t. (x-3)^2<=z1, (x-7)^2<=z2. S'(x)=2(x-3)+2(x-7)=0 -> x=5. Then clip to the interval allowed by the constraints."""
    lo = max(1.0, 3 - math.sqrt(z[0]), 7 - math.sqrt(z[1])); hi = min(10.0, 3 + math.sqrt(z[0]), 7 + math.sqrt(z[1]))
    x = min(max(5.0, lo), hi)
    f = ((x - 3) ** 2, (x - 7) ** 2); l = (z[0] - f[0], z[1] - f[1])
    return dict(z=z, interval=(lo, hi), x=x, f=f, l=l, sum_l=l[0] + l[1])
p1 = mkprob("P1"); tr = []
for z in ((10.0, 8.0), (2.0, 20.0)):
    h = benson_hand(z); zt = (np.array(z) - p1.ideal) / (p1.nadir - p1.ideal)
    r = benson(p1, [zt])[0]; code_x = float(r[1][0]); code_f = p1.denorm(r[2]); code_l = r[3] * (p1.nadir - p1.ideal)
    h.update(code_x=code_x, code_f=code_f.tolist(), code_l=code_l.tolist(), match=bool(abs(code_x - h["x"]) < 1e-3 and np.allclose(code_f, h["f"], atol=1e-2)))
    tr.append(h)
out["benson_trace"] = tr

# ---- Benson sensitivity: offset delta of reference points above the utopia line on P3 (non-convex), 10 seeds
p3 = mkprob("P3"); sens = {}
for delta in ((0.02, 0.2, 0.6) if not SKIP else ()):
    rows = []
    for s in range(1, 11):
        zs = [np.array([t, 1 - t]) + delta for t in np.linspace(0, 1, 15)]
        r = benson(p3, zs, seed=s); F = np.array([f for _, _, f, _ in r]); F = F[U.nondominated_mask(F)] if len(F) else F
        mid = int(((F[:, 0] > 0.2) & (F[:, 0] < 0.8)).sum()) if len(F) else 0
        rows.append(dict(HV=U.hypervolume(F, p3.ref_hv) if len(F) else 0, IGD=U.igd(p3.norm(p3.true_front()), F) if len(F) else np.inf, mid=mid, n=len(F)))
    sens[str(delta)] = {k: (float(np.mean([r[k] for r in rows])), float(np.std([r[k] for r in rows]))) for k in rows[0]}
    print("benson", delta, sens[str(delta)]); sys.stdout.flush()
out["benson_sens"] = prev.get('benson_sens', sens)

# ============================================================ (2) NSGA-III trace
def nsga3_trace(F, N, Z):
    """plain-python NSGA-III environmental selection on a small objective matrix; returns dict of every intermediate"""
    n = len(F); M = len(F[0]); T = {}
    dom = lambda a, b: all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))
    rem = list(range(n)); fronts = []
    while rem:
        fr = [i for i in rem if not any(dom(F[j], F[i]) for j in rem if j != i)]; fronts.append(fr); rem = [i for i in rem if i not in fr]
    T["fronts"] = fronts
    chosen = []; last = None
    for fr in fronts:
        if len(chosen) + len(fr) <= N: chosen += fr
        else: last = fr; break
    T["chosen_full"] = list(chosen); T["last"] = last
    if last is None: T["selected"] = chosen; return T
    St = chosen + last
    ideal = [min(F[i][m] for i in St) for m in range(M)]; T["ideal"] = ideal
    Ft = [[F[i][m] - ideal[m] for m in range(M)] for i in St]
    ext = []
    for m in range(M):
        w = [1e-6] * M; w[m] = 1.0
        asf = [max(Ft[k][q] / w[q] for q in range(M)) for k in range(len(St))]; ext.append(asf.index(min(asf)))
    T["extreme"] = [St[e] for e in ext]
    E = [Ft[e] for e in ext]
    # M=2: solve E a = 1 by Cramer
    det = E[0][0] * E[1][1] - E[0][1] * E[1][0]; a0 = (E[1][1] - E[0][1]) / det; a1 = (E[0][0] - E[1][0]) / det
    icpt = [1 / a0, 1 / a1]; T["intercepts"] = icpt
    Fn = [[Ft[k][m] / icpt[m] for m in range(M)] for k in range(len(St))]; T["normalised"] = {St[k]: Fn[k] for k in range(len(St))}
    assoc = {}; 
    for k in range(len(St)):
        best = None
        for zi, z in enumerate(Z):
            nz = math.sqrt(sum(c * c for c in z)); proj = sum(Fn[k][m] * z[m] for m in range(M)) / nz
            d = math.sqrt(max(sum(c * c for c in Fn[k]) - proj * proj, 0))
            if best is None or d < best[1]: best = (zi, d)
        assoc[St[k]] = best
    T["assoc"] = assoc
    rho = [0] * len(Z)
    for i in chosen: rho[assoc[i][0]] += 1
    T["rho0"] = list(rho)
    need = N - len(chosen); cand = {zi: [i for i in last if assoc[i][0] == zi] for zi in range(len(Z))}; picked = []; log = []
    while len(picked) < need:
        live = [zi for zi in cand if cand[zi]]; mn = min(rho[zi] for zi in live); tied = [zi for zi in live if rho[zi] == mn]
        zi = tied[0]
        if rho[zi] == 0: c = min(cand[zi], key=lambda i: assoc[i][1]); why = "rho=0 -> closest to line"
        else: c = cand[zi][0]; why = "rho>0 -> random member"
        log.append((zi, mn, len(tied), c, why)); cand[zi].remove(c); picked.append(c); rho[zi] += 1
    T["niching"] = log; T["selected"] = chosen + picked
    return T

# tiny instance on P1 (x in [1,10]), N=4, M=2, H=3 -> 4 reference points
Z = U.das_dennis(2, 3).tolist(); out["nsga3_Z"] = Z
xs0 = [1.0, 3.5, 6.0, 9.0]
off = [[1.5, 8.0, 2.0, 5.5], [9.0, 4.5, 4.0, 5.0]]
def f_(x): return [(x - 3) ** 2, (x - 7) ** 2]
pop = list(xs0); gens = []
for g in range(2):
    comb = pop + off[g]; Fc = [f_(x) for x in comb]
    T = nsga3_trace(Fc, 4, Z)
    sel_code = nsga3_select(np.array(Fc), 4, np.array(Z), np.random.default_rng(0))
    T["combined_x"] = comb; T["F"] = Fc; T["selected_code"] = sorted(sel_code.tolist()); T["match"] = sorted(T["selected"]) == sorted(sel_code.tolist())
    # check against several rng seeds (tie-breaks)
    T["match_all_seeds"] = all(sorted(nsga3_select(np.array(Fc), 4, np.array(Z), np.random.default_rng(s)).tolist()) == sorted(T["selected"]) for s in range(20))
    gens.append(T); pop = [comb[i] for i in T["selected"]]
    T["new_pop_x"] = list(pop)
out["nsga3_trace"] = gens
for T in gens: print("nsga3 trace match", T["match"], T["match_all_seeds"], T["selected"])

# ---- NSGA-III sensitivity: H (divisions) on P10 M=3, 10 seeds
sens = {}
p10 = mkprob("P10_3")
for H in ((4, 8, 12) if not SKIP else ()):
    rows = []
    for s in range(1, 11):
        n = len(U.das_dennis(3, H)); pop_ = int(math.ceil(n / 4) * 4)
        a = NSGA3(p10, pop=pop_, H=H, seed=s); X, F = a.run(10000); rows.append(metrics("P10_3", F))
    sens[str(H)] = {k: (float(np.mean([r[k] for r in rows])), float(np.std([r[k] for r in rows]))) for k in ("HV", "IGD", "SP", "n")}
    sens[str(H)]["pop"] = pop_
    print("nsga3 H", H, sens[str(H)]); sys.stdout.flush()
out["nsga3_sens"] = prev.get('nsga3_sens', sens)

# ============================================================ (3) MODE trace on P14 (2 variables), N=4, F=0.5, CR=0.9
p14 = mkprob("P14"); seed = 7
a = MODE(p14, pop=4, seed=seed, Fscale=0.5, CR=0.9); a.initialize()
rg = np.random.default_rng(seed); lb, ub = p14.lb, p14.ub
X = [list(lb + r * (ub - lb)) for r in rg.random((4, 2))]
def fobj(x): return (0.4 + 0.05 * x[0] + 0.012 * x[1], -(0.2 * x[1] / (0.5 + 0.03 * x[0])))     # min form (weight, -runtime)
dominates = lambda a_, b_: all(x <= y for x, y in zip(a_, b_)) and any(x < y for x, y in zip(a_, b_))
Fv = [fobj(x) for x in X]
mt = dict(x0=[list(map(float, x)) for x in X], f0=[list(map(float, f)) for f in Fv], iters=[])
assert np.allclose(a.X, np.array(X)), "init mismatch"
for it in range(2):
    R = [list(rg.choice([j for j in range(4) if j != i], 3, replace=False)) for i in range(4)]
    mask = rg.random((4, 2)); jr = rg.integers(2, size=4)
    rows = []; newX = []; newF = []
    # code side
    Xcode = a.trial_vectors.__func__  # (documentation only)
    for i in range(4):
        r1, r2, r3 = R[i]
        v = [X[r1][k] + 0.5 * (X[r2][k] - X[r3][k]) for k in range(2)]
        cr = [bool(mask[i][k] < 0.9 or k == jr[i]) for k in range(2)]
        u = [min(max(v[k] if cr[k] else X[i][k], lb[k]), ub[k]) for k in range(2)]
        fu = fobj(u); fx = Fv[i]; rep = dominates(fu, fx)
        rows.append(dict(i=i, r=[int(q) for q in R[i]], v=v, jr=int(jr[i]), cross=cr, u=u, f_u=fu, f_x=fx, replace=bool(rep)))
        newX.append(u if rep else X[i]); newF.append(fu if rep else fx)
    a.iterate()
    ok = np.allclose(a.X, np.array(newX)) and np.allclose(a.F, p14.norm(np.array([[f[0], f[1]] for f in newF])))
    X = [list(map(float, x)) for x in newX]; Fv = [tuple(f) for f in newF]
    mt["iters"].append(dict(rows=rows, X=X, F=[list(map(float, f)) for f in Fv], match_code=bool(ok), archive_size=int(len(a.arc.X))))
    print("mode trace iter", it + 1, "match", ok)
out["mode_trace"] = mt

# ---- MODE sensitivity: scale factor F on P3 and P5, 10 seeds
sens = {}
for key in ("P3", "P5"):
    for Fs in ((0.2, 0.5, 0.9) if not SKIP else ()):
        rows = []
        for s in range(1, 11):
            a = MODE(mkprob(key), seed=s, Fscale=Fs); X_, F_ = a.run(10000); rows.append(metrics(key, F_))
        sens["%s_F%.1f" % (key, Fs)] = {k: (float(np.mean([r[k] for r in rows])), float(np.std([r[k] for r in rows]))) for k in ("HV", "IGD", "SP", "n")}
        print("mode", key, Fs, sens["%s_F%.1f" % (key, Fs)]); sys.stdout.flush()
out["mode_sens"] = prev.get('mode_sens', sens)
json.dump(out, open(os.path.join(DAT, "taskC.json"), "w"), indent=1, default=float)
print("saved")
